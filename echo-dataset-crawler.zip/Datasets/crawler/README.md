# ECHO Dataset Crawler

Searches three open dataset catalogs by keyword and builds a catalog of what it finds. Small, openly licensed files come with it.

| Source | How | Key needed |
|---|---|---|
| Zenodo | `zenodo.org/api/records`, datasets only | No |
| Hugging Face | `huggingface.co/api/datasets` plus each dataset's file list | No (gated datasets are skipped) |
| data.gov | `api.gsa.gov/technology/datagov/v4/search` | Optional `DATAGOV_API_KEY` secret. Without it the crawler uses `DEMO_KEY`, which allows 30 requests an hour and 50 a day. |

It uses only official catalog APIs, so there is no page scraping. It needs only Python's standard library, so it also runs in Pydroid 3.

## What it writes (all under `Datasets/`)

```
INDEX.md                        one row per record (generated)
catalog/<source>/<id>/
  record.json                   title, links, keywords, files, provenance
  record.raw.json.gz            the catalog's own response, unaltered
files/<source>/<id>/<file>      downloaded files (small, open-licensed only)
state/seen.json                 what has been seen, for de-duplication
state/skipped.json              every file not downloaded, with the reason
state/runs.json                 summary of each run
state/probe/                    raw sample responses (probe mode)
```

Each `record.json` carries the same six provenance fields as the Datasets environment: source, version, date, license, method and checksum. All of them start **unverified**. The one exception is a downloaded file whose checksum matches the one the catalog published; that file is marked "verified against source".

## Download rules

A file is downloaded only if all of these hold:

1. The record's license is on the list in `config.json`. By default that is CC0, public domain, PDDL, CC-BY, CC-BY-SA, ODC-BY, ODbL, MIT, Apache-2.0 and BSD. Non-commercial (NC), no-derivatives (ND), GPL, unknown and missing licenses are recorded but not downloaded.
2. The file is at most **10 MB**. The cap is also enforced while streaming, so a file that turns out larger than declared is discarded.
3. All downloaded files together stay under **300 MB**. That keeps the repository well inside GitHub's recommended 1 GB.
4. If the catalog publishes a checksum, the downloaded file must match it. Otherwise the file is discarded and the mismatch is recorded.

Anything else is recorded with a link and listed in `state/skipped.json`, so you can fetch it yourself if you want it.

Downloaded files are stored as data. The crawler never opens, unzips or runs them.

## Choosing how often it runs

Edit `schedule.txt` on the Library branch. Keep one line that isn't a comment:

| Write | Runs |
|---|---|
| `every 3 hours` | About every 3 hours (any number from 1 to 168) |
| `daily` | About every 24 hours |
| `daily at 9` | Once a day, at or after 9:00 your time (0–23) |
| `weekly on monday at 6` | Once a week |
| `off` | Never on its own; "Run workflow" still works |

- **Timezone.** Set it with the `timezone:` line. The default is `America/Chicago`.
- **How the timing works.** GitHub wakes the workflow once an hour. The crawler reads `schedule.txt` and the time of the last run, then either runs or exits with "Not due".
- **Minimum interval.** The shortest real interval is 1 hour, and a run can start a few minutes late.
- **Mistakes in the file.** A mistake such as `daily at 25` makes that hourly check show as failed in the Actions tab, with the reason, so you'll notice it. Nothing runs until the file is fixed.
- **Manual runs.** These always run, whatever the schedule says.

## Choosing what to search

Edit `keywords.txt`, with one phrase per line. The `[section]` names are saved with each record, so you can tell "my keywords" from "echo study topics". The next run picks up the changes.

## Setup (one time)

1. **Put the code on the Library branch.** Commit `Datasets/crawler/` to `code-library-registry`.
2. **Put the workflow on `main`.** Commit `.github/workflows/dataset-crawler.yml` to `main`. GitHub runs scheduled workflows only from the default branch. The workflow itself checks out and commits to `code-library-registry`.
3. **Optional data.gov key.** Get a free key at api.data.gov/signup and add it as a repository secret named `DATAGOV_API_KEY` (Settings, Secrets and variables, Actions).
4. **First run: probe mode.** Go to Actions, choose "Dataset crawler", then "Run workflow", and pick mode **probe**. This saves one raw response per source to `state/probe/`. Check those three files match what the crawler expects before turning on daily runs (see "Untested" below).
5. **Second run: dry-run mode.** This builds the catalog with no downloads.
6. **After that,** it follows `schedule.txt`. The default is `daily at 4`, meaning 4 a.m. Chicago time.

## Untested

This was written in a workspace that cannot reach the three sites. It was tested end to end against sample responses (de-duplication, license filtering, size caps, mid-download cap, checksum match and mismatch, gated datasets, data.gov access pages). It has **not** been run against the live APIs. Three response details come from documentation, not from a live call:

- the Zenodo file list fields (`files[].key`, `size`, `checksum`, `links.self`)
- the Hugging Face file tree (`/tree/main?recursive=true`)
- the data.gov distribution fields (`dcat.distribution[].downloadURL` / `accessURL`)

Probe mode exists to confirm them.

## Run by hand (Pydroid 3 or a computer)

```
python3 Datasets/crawler/crawl.py --probe
python3 Datasets/crawler/crawl.py --dry-run
python3 Datasets/crawler/crawl.py --source zenodo
```
