# Handoff: storage, filing and the Cloudflare bridge

From Claude, for the `dev-suite-integration-staging` branch. Continues the storage notes Timothy relayed.

## 1. What already exists on Cloudflare (created 2026-10-05, nothing to set up)

| Resource | Name | ID |
|---|---|---|
| D1 database | `devsuite_store` | `b7760441-04b5-47b6-b3a6-abf645bf80e2` |
| KV namespace | `DEVSUITE_KV` | `982e5ab0f073465c83411abaaddcf562` |
| R2 | not available yet: R2 must be enabled once in the Cloudflare dashboard (it asks for a payment method even on the free tier) | — |

Tables in `devsuite_store` (schema in `cloudflare/schema.sql`, already applied):

| Table | Holds |
|---|---|
| `workspaces` + `workspace_chunks` | one row per Matrixed File (or the Suite), JSON stored in 400 KB chunks, versioned |
| `vocabulary` | ECHO's Vocabulary Registry, one row per word (lateral, classical, analogy strands, genus, relation…) |
| `dictionary` | the 5,000-word working dictionary, one row per sense, `rank` 1 = most general. **Empty until seeded** (step 3) |
| `registries` | named registries (glyph, Latin, symbols, grammar…) as JSON |
| `capabilities` | the Governor's permission table, **already seeded** (see below) |
| `audit_log` | every write and every denial |

The existing `echo_knowledge` database (Genesis lobby, ties, WordNet chains) is untouched and separate.

## 2. The bridge Worker (`cloudflare/`), ready to deploy

`src/index.js` is the Governor + Bridge: the token decides the **actor**, the actor's rows in `capabilities`
decide what it may do, and every write or denial is written to `audit_log`.

| Actor | Token secret | May |
|---|---|---|
| owner (Timothy) | `OWNER_TOKEN` | everything (`*`) — never stored in the page |
| echo | `ECHO_TOKEN` | storage.read, storage.write, dictionary.read; **denied** registry.write, github.*, cloudflare.admin |
| keyboard | `KEYBOARD_TOKEN` | storage.read, storage.write |

So even if code running in Pyodide reads the token it was given, it can only do what that actor is granted.
No GitHub or Cloudflare credential ever reaches the page.

Routes: `GET /health` · `GET|PUT /v1/workspaces[/:id]` (PUT takes `expect_version` → 409 on conflict) ·
`GET /v1/sync?ids=a,b` (versions from KV: cheap polling) · `GET|PUT /v1/vocab` (≤200 words per PUT) ·
`GET /v1/dict/:word`, `GET /v1/dict?from_rank=&limit=` · `GET|PUT /v1/registries/:name` · `POST /v1/governor` (capability check + audit; outside-service bridges return 501 until built).

## 3. Deploy steps

1. Repo secrets: `CLOUDFLARE_API_TOKEN` (Workers, D1, KV edit) and `CLOUDFLARE_ACCOUNT_ID`.
2. Copy `cloudflare/.github-workflow/deploy-bridge.yml` to `.github/workflows/`.
3. Push → deploys. Run the workflow manually once (**workflow_dispatch**) to load `seed/dictionary.sql` (20,392 senses, 51 statements of ≤34 KB; safe to re-run).
4. Set the three tokens: `npx wrangler secret put OWNER_TOKEN` (and ECHO_TOKEN, KEYBOARD_TOKEN) — long random strings.
5. Add the app's real origin(s) to `ALLOWED_ORIGINS` in `wrangler.toml`.

I validated the schema, seeds and the Governor query in SQLite; the Worker passes a syntax check. It has **not** been deployed or run against live D1 — please test `/health`, a workspace PUT/GET round trip, and a denied `github.read` as echo.

## 4. Client storage plan (the part you're building)

Layers: **IndexedDB is the working store** (offline, large); **Cloudflare is sync and backup**, on demand.

| Data now | Where now | Move to |
|---|---|---|
| `echo-devsuite-v1` (whole `DS` object: Suite + every Matrixed File) | localStorage | IndexedDB, **one record per file** (`suite`, `f1`, `f2`…) + `meta` (fseq, active, seeds) |
| `S.echoVocab`, `S.echoLearned` (grows to ~3 MB) | inside the Genesis file | their own IndexedDB stores; synced to D1 `vocabulary` |
| `ckt:*` (keyboard lines, links, Mine, settings) | localStorage | IndexedDB store `keyboard`; tiny UI prefs may stay in localStorage |
| `echo-canvas-v3` | legacy, migration only | read once, then ignore |

Pitfalls (from my earlier notes, still true):
1. **Startup is synchronous today; IndexedDB is async.** Await the load before `seedAll(...)`, or seeds run on empty state and duplicate.
2. **`save()` rewrites everything after each change.** Write only the changed file's record; debounce.
3. **Undo snapshots stay in memory**; don't route them through storage.
4. The keyboard runs in a **same-origin srcdoc iframe**: it can open the same IndexedDB database.
5. Pyodide can mount a persistent filesystem backed by IndexedDB (`IDBFS`) for Python modules and datasets.
6. Call `navigator.storage.persist()` once.
7. Inside published Claude artifacts, IndexedDB works (private per viewer); OPFS is unverified there — keep it optional.
8. Edit `suite/src/` and `keyboard/src/`, then `python build.py`. Never edit `dist/` by hand.

**Free-tier limits matter now:** since 2026-09-01, D1 rejects queries past the daily row read/write limits.
Sync on explicit **Save to cloud**, on file close, or every few minutes when changed — never per keystroke.
Use `GET /v1/sync` (KV) to check versions instead of reading D1.

**Inside Claude, the page can't call the Worker** (published artifacts block outside network calls). There, sync would go
through the artifact's own runtime capabilities instead; the Worker is for the GitHub Pages / standalone build.

## 5. Where things stand in the code

- Suite storage: `save()` / `load()` and the `DS` object near the top of `suite/src/app_part.html`.
- Keyboard storage: the `store` object at the top of `keyboard/src/app.js`.
- Claude will not edit these storage paths until your version is committed, to avoid conflicts.
