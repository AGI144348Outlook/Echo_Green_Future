-- already applied. The Governor's permission table: what each actor may do. ECHO never holds a service credential.
INSERT OR REPLACE INTO capabilities (actor, capability, allowed, note) VALUES
('owner','*',1,'Timothy: every capability'),
('echo','storage.read',1,'read workspaces, vocabulary, dictionary, registries'),
('echo','storage.write',1,'write his own Vocabulary Registry and workspace'),
('echo','dictionary.read',1,'the imported dictionary'),
('echo','registry.write',0,'registries are written by the developer until granted'),
('echo','github.read',0,'not yet granted: bridge pending'),
('echo','github.write',0,'not yet granted'),
('echo','cloudflare.admin',0,'never: no credentials reach ECHO'),
('keyboard','storage.read',1,'keyboard state, Mine, lines and links'),
('keyboard','storage.write',1,'keyboard state, Mine, lines and links');
