-- devsuite_store (D1, id b7760441-04b5-47b6-b3a6-abf645bf80e2) -- already applied by Claude on 2026-10-05.
CREATE TABLE IF NOT EXISTS workspaces (id TEXT PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'file', version INTEGER NOT NULL DEFAULT 1, parts INTEGER NOT NULL DEFAULT 0, bytes INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS workspace_chunks (workspace_id TEXT NOT NULL, version INTEGER NOT NULL, seq INTEGER NOT NULL, data TEXT NOT NULL, PRIMARY KEY (workspace_id, version, seq));
CREATE TABLE IF NOT EXISTS vocabulary (word TEXT PRIMARY KEY, pos TEXT, level INTEGER, definition TEXT, lateral TEXT, classical TEXT, analogy TEXT, genus TEXT, relation TEXT, main_json TEXT, into_json TEXT, occurrences INTEGER DEFAULT 0, step INTEGER, source TEXT, updated_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE INDEX IF NOT EXISTS vocabulary_genus ON vocabulary(genus);
CREATE INDEX IF NOT EXISTS vocabulary_level ON vocabulary(level);
CREATE TABLE IF NOT EXISTS dictionary (word TEXT NOT NULL, pos TEXT NOT NULL, sense INTEGER NOT NULL, definition TEXT NOT NULL, level INTEGER, rank INTEGER, PRIMARY KEY (word, pos, sense));
CREATE INDEX IF NOT EXISTS dictionary_rank ON dictionary(rank);
CREATE TABLE IF NOT EXISTS registries (name TEXT PRIMARY KEY, kind TEXT, folder TEXT, entries_json TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS capabilities (actor TEXT NOT NULL, capability TEXT NOT NULL, allowed INTEGER NOT NULL DEFAULT 0, note TEXT, PRIMARY KEY (actor, capability));
CREATE TABLE IF NOT EXISTS audit_log (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL DEFAULT (datetime('now')), actor TEXT NOT NULL, capability TEXT NOT NULL, allowed INTEGER NOT NULL, detail TEXT);
CREATE INDEX IF NOT EXISTS audit_log_at ON audit_log(at);
