// devsuite-bridge: the Governor and Bridge between the Dev Suite and Cloudflare storage.
// Every request carries a token; the token decides the actor (owner, echo, keyboard);
// the actor's capabilities in D1 decide what it may do; every write and every denial is audited.
// Service credentials (GitHub, Cloudflare) are never sent to the page or to ECHO.

const CHUNK = 400_000; // characters per stored chunk (well under D1's row limit)

const json = (data, status = 200, headers = {}) =>
  new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8", ...headers } });

function cors(env, req) {
  const origin = req.headers.get("origin") || "";
  const allowed = (env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean);
  if (!allowed.includes(origin)) return {};
  return { "access-control-allow-origin": origin, "access-control-allow-headers": "authorization, content-type",
           "access-control-allow-methods": "GET, PUT, POST, OPTIONS", vary: "origin" };
}

function actorOf(env, req) {
  const t = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!t) return null;
  if (env.OWNER_TOKEN && t === env.OWNER_TOKEN) return "owner";
  if (env.ECHO_TOKEN && t === env.ECHO_TOKEN) return "echo";
  if (env.KEYBOARD_TOKEN && t === env.KEYBOARD_TOKEN) return "keyboard";
  return null;
}

async function allowed(env, actor, capability) {
  const row = await env.DB.prepare(
    "SELECT allowed FROM capabilities WHERE actor = ?1 AND (capability = ?2 OR capability = '*') ORDER BY capability = '*' LIMIT 1"
  ).bind(actor, capability).first();
  return !!(row && row.allowed);
}

async function audit(env, actor, capability, ok, detail) {
  await env.DB.prepare("INSERT INTO audit_log (actor, capability, allowed, detail) VALUES (?1, ?2, ?3, ?4)")
    .bind(actor, capability, ok ? 1 : 0, String(detail || "").slice(0, 500)).run();
}

// The Governor: one gate in front of every operation.
async function govern(env, actor, capability, detail, isWrite) {
  const ok = await allowed(env, actor, capability);
  if (!ok || isWrite) await audit(env, actor, capability, ok, detail);
  return ok;
}

export default {
  async fetch(req, env) {
    const h = cors(env, req);
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: h });
    const url = new URL(req.url), p = url.pathname.split("/").filter(Boolean);
    try {
      if (p[0] === "health") return json({ ok: true, service: "devsuite-bridge" }, 200, h);
      const actor = actorOf(env, req);
      if (!actor) return json({ error: "unauthorized" }, 401, h);
      const deny = cap => json({ error: "denied", actor, capability: cap }, 403, h);

      // ---- workspaces: one Matrixed File (or the Suite) per row, stored in chunks
      if (p[0] === "v1" && p[1] === "workspaces") {
        if (req.method === "GET" && !p[2]) {
          if (!(await govern(env, actor, "storage.read"))) return deny("storage.read");
          const { results } = await env.DB.prepare("SELECT id, name, kind, version, bytes, updated_at FROM workspaces ORDER BY updated_at DESC").all();
          return json({ workspaces: results }, 200, h);
        }
        const id = decodeURIComponent(p[2] || "");
        if (req.method === "GET") {
          if (!(await govern(env, actor, "storage.read"))) return deny("storage.read");
          const ws = await env.DB.prepare("SELECT * FROM workspaces WHERE id = ?1").bind(id).first();
          if (!ws) return json({ error: "not found" }, 404, h);
          const { results } = await env.DB.prepare("SELECT data FROM workspace_chunks WHERE workspace_id = ?1 AND version = ?2 ORDER BY seq").bind(id, ws.version).all();
          return json({ ...ws, data: results.map(r => r.data).join("") }, 200, h);
        }
        if (req.method === "PUT") {
          if (!(await govern(env, actor, "storage.write", `workspace ${id}`, true))) return deny("storage.write");
          const body = await req.json(); const data = String(body.data || "");
          const prev = await env.DB.prepare("SELECT version FROM workspaces WHERE id = ?1").bind(id).first();
          if (body.expect_version != null && prev && prev.version !== body.expect_version)
            return json({ error: "conflict", current_version: prev.version }, 409, h);   // someone else saved first
          const version = (prev ? prev.version : 0) + 1, parts = Math.max(1, Math.ceil(data.length / CHUNK));
          const stmts = [];
          for (let i = 0; i < parts; i++)
            stmts.push(env.DB.prepare("INSERT INTO workspace_chunks (workspace_id, version, seq, data) VALUES (?1, ?2, ?3, ?4)").bind(id, version, i, data.slice(i * CHUNK, (i + 1) * CHUNK)));
          stmts.push(env.DB.prepare("INSERT INTO workspaces (id, name, kind, version, parts, bytes, updated_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, datetime('now')) " +
            "ON CONFLICT(id) DO UPDATE SET name = excluded.name, kind = excluded.kind, version = excluded.version, parts = excluded.parts, bytes = excluded.bytes, updated_at = excluded.updated_at")
            .bind(id, body.name || id, body.kind || "file", version, parts, data.length));
          stmts.push(env.DB.prepare("DELETE FROM workspace_chunks WHERE workspace_id = ?1 AND version < ?2").bind(id, version));
          await env.DB.batch(stmts);
          await env.KV.put(`version:${id}`, String(version));
          return json({ id, version, parts, bytes: data.length }, 200, h);
        }
      }

      // ---- sync check: cheap (KV), so the app can poll without reading D1
      if (p[0] === "v1" && p[1] === "sync" && req.method === "GET") {
        if (!(await govern(env, actor, "storage.read"))) return deny("storage.read");
        const ids = (url.searchParams.get("ids") || "").split(",").filter(Boolean).slice(0, 50);
        const out = {}; for (const id of ids) out[id] = Number(await env.KV.get(`version:${id}`)) || 0;
        return json({ versions: out }, 200, h);
      }

      // ---- ECHO's Vocabulary Registry: one row per word
      if (p[0] === "v1" && p[1] === "vocab") {
        if (req.method === "GET") {
          if (!(await govern(env, actor, "storage.read"))) return deny("storage.read");
          const since = Number(url.searchParams.get("since_step") || 0);
          const { results } = await env.DB.prepare("SELECT * FROM vocabulary WHERE step > ?1 ORDER BY step LIMIT 2000").bind(since).all();
          return json({ words: results }, 200, h);
        }
        if (req.method === "PUT") {
          const body = await req.json(); const words = (body.words || []).slice(0, 200);
          if (!(await govern(env, actor, "storage.write", `vocab ${words.length} words`, true))) return deny("storage.write");
          const st = env.DB.prepare("INSERT OR REPLACE INTO vocabulary (word,pos,level,definition,lateral,classical,analogy,genus,relation,main_json,into_json,occurrences,step,source,updated_at) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,datetime('now'))");
          await env.DB.batch(words.map(w => st.bind(w.word, w.pos || null, w.level ?? null, w.definition || null, w.lateral || null, w.classical || w.analog || null,
            w.analogy || null, w.genus || null, w.relation || null, JSON.stringify(w.main || []), JSON.stringify(w.into || []), w.occurrences || 0, w.step || 0, w.source || "homework")));
          return json({ saved: words.length }, 200, h);
        }
      }

      // ---- the dictionary (read only)
      if (p[0] === "v1" && p[1] === "dict" && req.method === "GET") {
        if (!(await govern(env, actor, "dictionary.read"))) return deny("dictionary.read");
        if (p[2]) { const { results } = await env.DB.prepare("SELECT pos, sense, definition, level, rank FROM dictionary WHERE word = ?1 ORDER BY pos, sense").bind(decodeURIComponent(p[2])).all();
          return json({ word: decodeURIComponent(p[2]), senses: results }, 200, h); }
        const from = Number(url.searchParams.get("from_rank") || 1), limit = Math.min(500, Number(url.searchParams.get("limit") || 100));
        const { results } = await env.DB.prepare("SELECT word, pos, sense, definition, level, rank FROM dictionary WHERE rank >= ?1 AND rank < ?2 ORDER BY rank, pos, sense").bind(from, from + limit).all();
        return json({ entries: results }, 200, h);
      }

      // ---- registries
      if (p[0] === "v1" && p[1] === "registries" && p[2]) {
        const name = decodeURIComponent(p[2]);
        if (req.method === "GET") {
          if (!(await govern(env, actor, "storage.read"))) return deny("storage.read");
          const r = await env.DB.prepare("SELECT * FROM registries WHERE name = ?1").bind(name).first();
          return r ? json({ ...r, entries: JSON.parse(r.entries_json) }, 200, h) : json({ error: "not found" }, 404, h);
        }
        if (req.method === "PUT") {
          if (!(await govern(env, actor, "registry.write", `registry ${name}`, true))) return deny("registry.write");
          const b = await req.json();
          await env.DB.prepare("INSERT OR REPLACE INTO registries (name, kind, folder, entries_json, updated_at) VALUES (?1, ?2, ?3, ?4, datetime('now'))")
            .bind(name, b.kind || "registry", b.folder || null, JSON.stringify(b.entries || [])).run();
          return json({ saved: name }, 200, h);
        }
      }

      // ---- the Governor endpoint: ask before acting on outside services
      if (p[0] === "v1" && p[1] === "governor" && req.method === "POST") {
        const b = await req.json(); const cap = String(b.capability || "");
        const ok = await govern(env, actor, cap, JSON.stringify(b.args || {}).slice(0, 300), true);
        if (!ok) return deny(cap);
        return json({ granted: cap, note: "granted, but no bridge for this capability is installed yet" }, 501, h);
      }

      return json({ error: "no such route" }, 404, h);
    } catch (e) {
      return json({ error: "server", detail: String(e && e.message || e) }, 500, h);
    }
  }
};
