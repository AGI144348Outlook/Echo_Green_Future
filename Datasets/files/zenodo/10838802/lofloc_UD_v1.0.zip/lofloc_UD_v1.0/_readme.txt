LOFLOC -- Lexic obèrt flechit Occitan (Open Inflected Lexicon of Occitan)

Loflòc is a morphological lexicon for Occitan, a Romance language spoken in the south of France and in parts of Italy and Spain. Occitan is not recognized as an official language in France and no standard variety is shared across the linguistic area. To the best of our knowledge, Loflòc is the first publicly available lexicon for Occitan. It contains 650 thousand entries for 57 thousand lemmas. Each entry contains an inflected form, its lemma and its part-of-speech tag according to the Universal Dependencies guidelines. Currently, the lexicon only contains the Lengadocian variety and the classical spelling norm. Nevertheless, it has been shown to be useful even for processing texts from other varieties (for more details, see Vergez-Couret et al., 2024; full reference below).

Format: tab-separated, one entry per line with the following structure: [inflected form]\t[lemma]\t[UPOS]\n

Authors: Marianne Vergez-Couret, Myriam Bras, Aleksandra Miletić and Clamença Poujade

License: The lexicon is available for non-commercial purposes under the CC BY-NC-SA 4.0 license (full text here: https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode.en). 

Contact: marianne.vergez.couret [at] univ-poitiers [dot] fr

Citing: If you use this version of Loflòc in your own work, please cite the following paper:
Marianne Vergez-Couret, Myriam Bras, Aleksandra Miletić, and Clamença Poujade. 2024. Loflòc: A Morphological Lexicon for Occitan using Universal Dependencies. In Proceedings of the 2024 Joint International Conference on Computational Linguistics, Language Resources and Evaluation (LREC-COLING 2024), pages 10716–10724, Torino, Italia. ELRA and ICCL.
