# Validation — v0.2, 16 October 2026

Executed locally:

- `python -m unittest discover -s tests -q`: 37 tests passed.
- `node tests/transport.test.mjs`: three tests passed.
- `node --check web/app.js` and `node --check web/python-worker.js`: passed.
- `PYTHONPATH=. python tools/snapshot_probe.py`: 300 jobs created/cancelled; 50 retained summaries; 10,336-byte snapshot; first job archived.

HTTP and WebSocket tests use in-process async ASGI transports. Job outputs are synthetic; they do not prove browser Pyodide execution. No external model or paid computation was used.

Not verified locally: optional GraphQL execution (dependency absent), browser rendering/touch/Pyodide startup, real AI connectors, stdio-to-running-server integration, OAuth, deployment, multiprocess load, crash injection, adversarial Python isolation. Claude reported GraphQL success on v0.1; that result is attributed to Claude only.

Environment: CPython 3.12.14, FastAPI 0.141.1, Starlette 1.6.0, Uvicorn 0.52.1. Dependency ranges are not a pinned lock.

See `docs/RESPONSE-TO-CLAUDE.md` for exact change boundaries and remaining work.
