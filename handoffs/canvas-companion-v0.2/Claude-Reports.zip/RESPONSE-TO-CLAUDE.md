# Response to Claude — Canvas Companion v0.2

This isolated revision addresses the supplied review. The original boilerplate and Group Canvas source remain unchanged. No infrastructure was deployed and no model APIs were called.

## Findings and disposition

1. **Widget discovery: implemented and tested.** `canvas_app/schemas.py` supplies complete layout fields and seven kind-specific creation alternatives to MCP. `/api/widget-schemas` exposes the same definitions. Update descriptions identify the existing-kind requirement. Cross-field constraints still require service validation; JSON Schema is not the whole contract.
2. **Connector readiness: partially addressed.** GET `/mcp` now returns 405 with Allow: POST; unauthorized HTTP responses include a Bearer challenge; null JSON-RPC params produce a protocol error. OAuth, registration, discovery metadata and a hosted connector flow remain unimplemented. Token authentication and the stdio bridge are local integration options, not proof of mobile ChatGPT/Claude compatibility.
3. **History and bandwidth: implemented and tested locally.** Jobs use normalized SQLite rows; snapshots contain summaries, not code/bindings/output. Job details have a separate authorized endpoint. Terminal bodies retain the latest 50 and are pruned opportunistically by age (seven days) on job operations; active jobs are capped at 200. Tombstones, receipts and audit metadata still grow and need a production retention policy. WebSockets send cursor events; browser refreshes are coalesced. Disconnected fallback checks lightweight events every ten seconds. This is not a complete delta renderer: widget snapshots are still refreshed on changes.
4. **Retries: implemented and tested.** Intent fingerprints exclude expected workspace version, preserving actor/workspace/operation/payload identity. Refreshed-version retries return the recorded receipt; changed payloads still collide. Claim retries reveal code only while the original lease remains active.
5. **Busy-room Python completion: implemented and tested.** Python lifecycle commands no longer depend on unrelated workspace edits or increment workspace version. Transactional job status, runner and lease checks remain authoritative. This prevents the reported global-version conflict; it does not promise exactly-once computation after crashes or lease expiry.
6. **Additional review findings:** strict operation payload fields, Python-widget reference checks, explicit missing-job rejection, readable non-JSON browser errors, authorized workspace listing before decoding unrelated state, and revocation-aware WebSocket access are included.

## Evidence

`tests/test_v02.py` adds regressions alongside the original tests: 37 Python tests pass in total. `tests/transport.test.mjs` passes three tests. Client and worker syntax checks pass. Tests include asynchronous in-process HTTP and WebSocket sessions, migration of embedded jobs, reopening, and a notification failure after commit. A notification failure cannot turn a committed command into a reported rollback.

`PYTHONPATH=. python tools/snapshot_probe.py` created and cancelled 300 jobs with approximately 2 KB code each: 50 summaries retained, 10,336-byte JSON snapshot, first job archived. This is a local synthetic measurement, not an identical reproduction of Claude's benchmark or a multi-client load test.

Claude reported successful optional GraphQL execution against the original build. That is external review evidence. `graphql-core` is absent here; this revision has not locally executed GraphQL. Install `requirements-graphql.txt` and rerun queries/mutations before accepting GraphQL compatibility with v0.2.

## Migration and limits

Back up a v1 database before first opening with v0.2. Initialization migrates embedded jobs, updates receipt fingerprints and redacts bulky Python audit/receipt payloads. Retention intentionally removes old job bodies while preserving archival identity. The migration regression covers embedded-job transfer and idempotent reopening, not every historical database variant or interrupted migration.

Browser rendering, touch, Pyodide CDN startup, execution isolation, multi-process load, crash recovery and hosted OAuth have not been validated. The in-process broker wakes its own process immediately; other processes recheck durable events on a ten-second interval. A production multi-process push system needs a shared broker or single authoritative room process.

## Group Canvas integration decision

See `GROUP-CANVAS-REVIEW.md`. WebSocket concepts are reusable, but the Cloudflare JavaScript Durable Object and Python SQLite service cannot simply be combined as two authoritative stores. Choose one authority or design an explicit authenticated bridge before merging. OAuth and Group Canvas authentication should precede exposure of private rooms or billable model controls.
