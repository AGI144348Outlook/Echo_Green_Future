# Canvas Companion — inspection findings (Claude, 16 Oct 2026)

Scope: every file in `canvas-companion-boilerplate.zip`, following `docs/CLAUDE-REVIEW.md`.
No repository files were changed. Probes ran against an in-process ASGI client
(`httpx.ASGITransport`), CPython 3.12, with `graphql-core` installed.

## Re-run results
- Full suite: **22/22 tests pass.**
- **GraphQL now verified**: with `requirements-graphql.txt` installed, `createWorkspace`
  and `query { workspaces { id title version } }` both returned correct data. This closes
  one "not verified" item in `VALIDATION.md`.

## Confirmed sound
- Actor comes only from the bearer token (`server.py:30-38`, constant-time compare);
  `actor` cannot be injected (`service.py:195-196`).
- Viewer write denial, owner-only persona/share (`service.py:154-156, 269, 283`).
- `BEGIN IMMEDIATE` + rollback on any exception; receipt checked before the version
  check, so exact replays are idempotent (`service.py:209-238`).
- Renderers use `textContent` / `setAttribute`; avatar color is hex-validated
  (`app.js:96-104`, `service.py:79-81`). No HTML-injection path found.
- Stale/cancelled Python completions rejected by runner + lease + expiry (`service.py:316-318`).

## Defects

### 1. MCP tool schemas don't tell an AI how to build a valid widget — HIGH
`mcp.py:22-24` publishes `layout` and `spec` as bare `{"type": "object"}`.
`service.py:60-65` requires exactly `x, y, width, height, collapsed` with width ≥ 180
and height ≥ 100, and each `kind` has its own allowed spec fields.

Repro: `tools/call widget_create` with `layout: {x:10, y:10, width:120, height:120}`
→ `"Layout requires x, y, width, height and collapsed"`. An assistant's natural first
call fails, and it can't learn the size minimums or per-kind spec fields from the schema.

Fix: full `layout` schema (`required` all five, `minimum` 180/100), and per-kind spec
documentation (a `oneOf` keyed by `kind`, or field lists in the description).

### 2. Not reachable as a remote connector yet — HIGH (for the stated goal)
- `GET /mcp` returns **404** from the static mount (`server.py:128`). Streamable HTTP
  expects **405** when no SSE stream is offered; some clients treat 404 as a dead endpoint.
- No OAuth / protected-resource metadata or `WWW-Authenticate` header on 401, so hosted
  assistants (Claude, ChatGPT) can't complete a connector sign-in with the static tokens.
- `mcp_stdio.py` only helps desktop hosts on the same machine.

Fix: explicit `@app.get("/mcp")` → 405; an OAuth layer before public deployment.

### 3. Jobs grow forever and the whole state is polled every 1.2 s — MEDIUM
Job code/output lives inside the single workspace JSON (`service.py:300-303`), is never
pruned, and every command rewrites the whole JSON (`service.py:227`). The client fetches
the full snapshot every 1.2 s per tab (`app.js:17, 125`).

Repro: 300 queued+cancelled jobs (2 KB code each) → **643 KiB snapshot per poll per tab.**
That's heavy for a phone on mobile data.

Fix: separate `jobs` table; prune or summarize terminal jobs; poll
`/api/workspaces/{id}/events?after=` (already implemented server-side, unused by the client)
instead of the full snapshot.

### 4. Idempotent retry breaks after a refresh — MEDIUM
The receipt fingerprint covers the whole command record including `expected_version`
(`service.py:206-208`). A client whose response was lost, which then refreshes and
retries the same command ID with the new version, gets **"Command ID collision"**.

Repro: submit `dup` at version 0 (accepted), resend `dup` at version 1 → 400 collision.
An MCP assistant that re-inspects before retrying will hit this.

Fix: fingerprint `operation + payload` only, or return the stored receipt whenever the
ID matches and the payload matches.

### 5. Python runner ops share the workspace-wide version lock — MEDIUM
`python.claim` / `python.complete` require `expectedVersion` like any edit. Any edit
between claim and complete → 409.

Repro: claim, then a persona edit, then complete with the claim-time version → 409.
`app.js:24-29` retries once; in a busy room (several people or an AI editing) the retry
can also lose, the job stays `running` until the 40 s lease expires, and it's re-run.

Fix: exempt `python.claim/complete/cancel` from the workspace version check; their
lease/runner/status guards already protect them.

### 6. Low-severity
- `server.py:106` — `"params": null` on `initialize` raises `AttributeError` → HTTP 500.
  Same pattern at `server.py:116`. Validate `params` is an object.
- `mcp.py:75` — unknown `jobId` returns the bare text `'jobId'`; return "Job not found".
- `app.js:12` — `r.json()` on a non-JSON error body (e.g. a 500) throws `SyntaxError`,
  hiding the real status.
- `service.py:177-181` — `list()` parses every workspace in the database per call.
- `service.py:250-266` — update/delete silently ignore unknown payload keys while create
  is strict; `widgetId` in `python.queue` (`service.py:303`) is stored unvalidated.
- `server.py:107` — clients asking for `2025-11-25` are negotiated down to `2025-03-26`.
  Valid behavior, but worth adding newer versions once tested.

## Still unverified (unchanged from VALIDATION.md)
Browser rendering and touch, real Pyodide execution, a real assistant connection, public
hosting/OAuth, Python isolation, and multi-process load.
