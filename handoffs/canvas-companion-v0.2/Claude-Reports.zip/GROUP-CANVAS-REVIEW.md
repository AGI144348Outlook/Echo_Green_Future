# Group Canvas source review

Read-only source review of the supplied Group Canvas archive. Findings below are source observations, not deployed exploit tests. No model requests were made. Paths refer to the included `group-canvas-source/` copy.

- `src/room.js`, `fetch` and `onJoin`: the WebSocket join path has no verified principal. `onJoin` accepts an existing seatId and attaches the socket to that seat, without a credential or human/AI kind check. Public snapshots expose seat identifiers. A claimed seat controls visibility in `snapshotFor`; possession of a public identifier must not authorize private-thread access.
- `src/room.js`, message dispatch and `onAddAI`: joined participants can reach AI addition/removal and shared-room operations without owner/editor roles. Establish authorization before exposing billable model choices or destructive operations.
- `src/room.js`, `runAITurn`: the AI-call budget is held in process memory and fetch has no explicit timeout. Persistence/restart-aware budgets, cancellation and stale-seat checks are needed. In-flight responses must be reauthorized against current membership before publishing.
- `src/room.js`, model-reply processing: parsed model output needs typed validation before iterating canvas operations. A JSON object alone is insufficient. Explicitly distinguish private dialogue from permission to publish canvas changes.

The Durable Object offers a useful single-room authority and push model. This v0.2 package implements its own authenticated WebSocket event channel; it does not import or merge Group Canvas. GraphQL remains an optional structured interface over the Python authority.

Two viable future approaches: (1) retain Python/SQLite as authority and connect authenticated room/model adapters to its commands/events; (2) port the command, lease, permission and receipt contract to a Durable Object and validate it there. In either case, avoid independently writable unsynchronized copies of entity state.
