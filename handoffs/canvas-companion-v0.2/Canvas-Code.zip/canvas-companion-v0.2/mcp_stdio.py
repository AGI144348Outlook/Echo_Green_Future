"""Optional local stdio-to-HTTP bridge for assistant hosts supporting local MCP.

CANVAS_URL points to the running server. CANVAS_ACCESS_TOKEN is kept out of argv.
No assistant provider account or LLM API key is used by this bridge.
"""
import json
import os
import sys
import urllib.error
import urllib.request


def main():
    endpoint = os.environ.get("CANVAS_URL", "http://127.0.0.1:8000").rstrip("/") + "/mcp"
    token = os.environ.get("CANVAS_ACCESS_TOKEN")
    if not token:
        print("CANVAS_ACCESS_TOKEN is required.", file=sys.stderr)
        raise SystemExit(2)
    for line in sys.stdin:
        if not line.strip():
            continue
        rid = None
        notification = False
        try:
            message = json.loads(line)
            notification = "id" not in message
            rid = message.get("id")
            request = urllib.request.Request(endpoint, data=json.dumps(message).encode(), headers={
                "Content-Type": "application/json", "Accept": "application/json, text/event-stream",
                "Authorization": "Bearer " + token,
            })
            with urllib.request.urlopen(request, timeout=30) as response:
                raw = response.read()
            if raw and not notification:
                print(raw.decode(), flush=True)
        except (ValueError, urllib.error.URLError, OSError):
            if not notification:
                print(json.dumps({"jsonrpc": "2.0", "id": rid,
                    "error": {"code": -32000, "message": "Local Canvas bridge request failed; check the server and access configuration."}}), flush=True)


if __name__ == "__main__":
    main()
