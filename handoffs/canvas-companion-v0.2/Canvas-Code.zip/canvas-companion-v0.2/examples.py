"""HTTP client and optional example creator. No network request occurs on import."""
import json
import os
import urllib.request
from uuid import uuid4


class CanvasClient:
    def __init__(self, url, token):
        self.url, self.token = url.rstrip("/"), token

    def request(self, path, data=None):
        req = urllib.request.Request(self.url + path,
            data=None if data is None else json.dumps(data, ensure_ascii=False).encode(),
            headers={"Authorization": "Bearer " + self.token, "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=20) as response:
            return json.load(response)

    def inspect(self, workspace_id):
        return self.request("/api/workspaces/" + workspace_id)

    def command(self, workspace_id, operation, payload):
        state = self.inspect(workspace_id)
        # A concurrent edit returns a conflict; this client does not overwrite/retry silently.
        return self.request(f"/api/workspaces/{workspace_id}/commands", {
            "id": str(uuid4()), "expectedVersion": state["version"],
            "operation": operation, "payload": payload,
        })


def main():
    client = CanvasClient(os.environ.get("CANVAS_URL", "http://127.0.0.1:8000"),
                          os.environ["CANVAS_ACCESS_TOKEN"])
    workspace = client.request("/api/workspaces", {"title": "Companion example"})
    print(client.command(workspace["id"], "widget.create", {
        "id": "local-avatar", "kind": "avatar", "title": "A little companion",
        "spec": {"glyph": "ג", "color": "#49664e", "message": "Let's try an idea together."},
        "layout": {"x": 40, "y": 40, "width": 320, "height": 300, "collapsed": False},
    }))
    print("Workspace:", workspace["id"])


if __name__ == "__main__":
    main()
