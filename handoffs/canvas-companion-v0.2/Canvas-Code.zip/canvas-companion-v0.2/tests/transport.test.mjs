import test from "node:test";
import assert from "node:assert/strict";
import {readResponse} from "../web/transport.mjs";

test("non-JSON 500 retains its status and readable error",async()=>{
  await assert.rejects(()=>readResponse(new Response("upstream failed",{status:500})),e=>e.status===500&&e.message==="upstream failed");
});
test("JSON conflicts retain structured reason",async()=>{
  await assert.rejects(()=>readResponse(new Response(JSON.stringify({reason:"stale version"}),{status:409})),e=>e.status===409&&e.message==="stale version");
});
test("valid JSON responses remain objects",async()=>{
  assert.deepEqual(await readResponse(new Response('{"version":2}')),{version:2});
});
