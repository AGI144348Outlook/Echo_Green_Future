from pathlib import Path
import tempfile
import unittest

import httpx
from canvas_app.server import create_app

TOKEN="synthetic-test-token-alice"
BOB="synthetic-test-token-bob"


class HTTPTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.app=create_app(str(Path(self.tmp.name)/"db.sqlite3"),{TOKEN:"alice",BOB:"bob"})
        self.client=httpx.AsyncClient(transport=httpx.ASGITransport(app=self.app),base_url="http://test")
        self.headers={"Authorization":"Bearer "+TOKEN}

    async def asyncTearDown(self):
        await self.client.aclose();self.tmp.cleanup()

    async def rpc(self,method,params=None,headers=None):
        return await self.client.post("/mcp",headers=headers or {},json={"jsonrpc":"2.0","id":1,"method":method,"params":params or {}})

    async def test_static_client_and_no_token_access(self):
        self.assertTrue((Path(__file__).resolve().parent.parent/"web/index.html").is_file())
        self.assertTrue((Path(__file__).resolve().parent.parent/"web/app.js").is_file())
        self.assertEqual((await self.client.get("/api/workspaces")).status_code,401)

    async def test_mcp_initialization_and_discovery_without_private_data(self):
        result=(await self.rpc("initialize",{"protocolVersion":"2025-03-26"})).json()["result"]
        self.assertEqual(result["protocolVersion"],"2025-03-26")
        tools=(await self.rpc("tools/list")).json()["result"]["tools"]
        self.assertIn("widget_create",{t["name"] for t in tools})
        self.assertEqual((await self.rpc("tools/call",{"name":"workspace_list"})).status_code,401)

    async def test_real_mcp_create_and_inspect_share_the_http_store(self):
        response=await self.rpc("tools/call",{"name":"workspace_create","arguments":{"title":"MCP room"}},self.headers)
        wid=response.json()["result"]["structuredContent"]["result"]["id"]
        state=(await self.client.get("/api/workspaces/"+wid,headers=self.headers)).json()
        self.assertEqual(state["title"],"MCP room")
        command={"workspaceId":wid,"commandId":"create-widget","expectedVersion":0,
                 "payload":{"id":"avatar","kind":"avatar","title":"Little companion","spec":{"glyph":"ג"},
                            "layout":{"x":0,"y":0,"width":300,"height":240,"collapsed":False}}}
        tool=(await self.rpc("tools/call",{"name":"widget_create","arguments":command},self.headers)).json()["result"]
        self.assertFalse(tool["isError"])
        self.assertEqual((await self.client.get("/api/workspaces/"+wid,headers=self.headers)).json()["widgets"]["avatar"]["spec"]["glyph"],"ג")
        forbidden=await self.client.get("/api/workspaces/"+wid,headers={"Authorization":"Bearer "+BOB})
        self.assertEqual(forbidden.status_code,403)

    async def test_mcp_tool_failure_is_explicit(self):
        result=(await self.rpc("tools/call",{"name":"workspace_inspect","arguments":{"workspaceId":"missing"}},self.headers)).json()["result"]
        self.assertTrue(result["isError"])

    async def test_notification_and_unknown_method(self):
        self.assertEqual((await self.client.post("/mcp",json={"jsonrpc":"2.0","method":"notifications/initialized"})).status_code,202)
        self.assertEqual((await self.rpc("no-such-method")).json()["error"]["code"],-32601)

    async def test_finite_json_object_required(self):
        self.assertEqual((await self.client.post("/api/workspaces",headers=self.headers,content='{"title": NaN}')).status_code,400)

    async def test_graphql_is_explicitly_optional(self):
        ready=(await self.client.get("/api/info")).json()["graphql"]
        result=await self.client.post("/graphql",headers=self.headers,json={"query":"{ workspaces { id title } }"})
        if ready:
            self.assertEqual(result.status_code,200)
            self.assertIn("data",result.json())
        else:
            self.assertEqual(result.status_code,501)


if __name__ == "__main__": unittest.main()
