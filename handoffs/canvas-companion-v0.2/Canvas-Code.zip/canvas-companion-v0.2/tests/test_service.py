import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from canvas_app.service import Service, Rejected, Forbidden, Conflict


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.tmp.name)/"data.sqlite3")
        self.service = Service(self.path)
        self.ws = self.service.create("alice", "A shared room")["id"]
        self.seq = 0

    def tearDown(self):
        self.tmp.cleanup()

    def cmd(self, op, payload, actor="alice", version=None, rid=None):
        self.seq += 1
        return self.service.submit(actor, self.ws, {"id": rid or str(self.seq),
            "expectedVersion": self.service.get(actor, self.ws)["version"] if version is None else version,
            "operation": op, "payload": payload})

    def widget(self, kind="note", wid="w"):
        return self.cmd("widget.create", {"id": wid, "kind": kind, "title": "A widget",
            "spec": {"glyph": "ג"} if kind == "avatar" else {"text": "X × Ø 0 … ... י ם"},
            "layout": {"x": 20, "y": 30, "width": 300, "height": 200, "collapsed": False}})

    def job(self, jid="j"):
        return self.cmd("python.queue", {"id": jid, "code": "result = 2 + 2"})

    def test_unknown_workspace_and_other_owner_are_denied(self):
        with self.assertRaises(Forbidden): self.service.get("bob", self.ws)
        with self.assertRaises(Forbidden): self.service.get("alice", "missing")
        self.assertEqual(self.service.list("bob"), [])

    def test_viewer_reads_but_cannot_write(self):
        self.cmd("workspace.share", {"principal": "bob", "role": "viewer"})
        self.assertEqual(self.service.get("bob", self.ws)["title"], "A shared room")
        with self.assertRaises(Forbidden): self.cmd("python.queue", {"id":"j","code":"pass"}, actor="bob")

    def test_editor_cannot_edit_persona_or_share(self):
        self.cmd("workspace.share", {"principal": "bob", "role": "editor"})
        self.cmd("python.queue", {"id":"j","code":"pass"}, actor="bob")
        with self.assertRaises(Rejected): self.cmd("persona.update", {"name":"New"}, actor="bob")
        with self.assertRaises(Rejected): self.cmd("workspace.share", {"principal":"eve","role":"editor"}, actor="bob")

    def test_access_revocation_is_effective(self):
        self.cmd("workspace.share", {"principal":"bob","role":"viewer"})
        self.cmd("workspace.share", {"principal":"bob","role":"remove"})
        with self.assertRaises(Forbidden): self.service.get("bob", self.ws)

    def test_duplicate_command_is_not_reapplied(self):
        body={"id":"same","expectedVersion":0,"operation":"persona.update","payload":{"name":"A"}}
        a=self.service.submit("alice",self.ws,body)
        self.assertEqual(self.service.submit("alice",self.ws,body),a)
        self.assertEqual(len(self.service.changes("alice",self.ws)),1)
        body["payload"]={"name":"B"}
        with self.assertRaises(Rejected): self.service.submit("alice",self.ws,body)

    def test_stale_workspace_and_widget_versions(self):
        self.widget()
        with self.assertRaises(Conflict): self.cmd("persona.update",{"name":"A"},version=0)
        with self.assertRaises(Conflict): self.cmd("widget.update",{"id":"w","expectedWidgetVersion":0,"title":"B"})

    def test_failed_validation_has_no_partial_write_or_event(self):
        self.widget()
        before=self.service.get("alice",self.ws)
        with self.assertRaises(Rejected):
            self.cmd("widget.update",{"id":"w","expectedWidgetVersion":1,"title":"Changed","layout":{}})
        self.assertEqual(before,self.service.get("alice",self.ws))
        self.assertEqual(len(self.service.changes("alice",self.ws)),1)

    def test_avatar_deletion_retains_persona(self):
        self.cmd("persona.update",{"name":"Moss","examples":["Let's try together."]})
        self.widget("avatar")
        self.cmd("widget.delete",{"id":"w","expectedWidgetVersion":1})
        state=self.service.get("alice",self.ws)
        self.assertEqual(state["widgets"],{})
        self.assertEqual(state["persona"]["name"],"Moss")

    def test_snapshot_defensive_copy_and_persistent_unicode(self):
        self.widget()
        state=self.service.get("alice",self.ws)
        state["widgets"]["w"]["spec"]["text"]="changed"
        restarted=Service(self.path)
        self.assertEqual(restarted.get("alice",self.ws)["widgets"]["w"]["spec"]["text"],"X × Ø 0 … ... י ם")

    def test_actor_cannot_be_injected_in_command(self):
        with self.assertRaises(Rejected):
            self.service.submit("alice",self.ws,{"id":"x","actor":"bob","expectedVersion":0,"operation":"persona.update","payload":{}})

    def test_queue_is_not_execution(self):
        result=self.job()["outcome"]
        self.assertEqual(result["status"],"queued")
        self.assertIsNone(self.service.job("alice",self.ws,"j")["output"])

    def test_job_claim_completion_and_duplicate_prevention(self):
        self.job()
        claim=self.cmd("python.claim",{"id":"j","runner":"tab"})["outcome"]
        with self.assertRaises(Rejected): self.cmd("python.claim",{"id":"j","runner":"other"})
        self.cmd("python.complete",{"id":"j","runner":"tab","lease":claim["lease"],"status":"succeeded","output":{"result":4,"runtime":"synthetic test runner"}})
        with self.assertRaises(Rejected):
            self.cmd("python.complete",{"id":"j","runner":"tab","lease":claim["lease"],"status":"succeeded","output":{"result":5}})
        self.assertEqual(self.service.job("alice",self.ws,"j")["output"]["result"],4)

    def test_expired_job_claim_invalidates_old_completion(self):
        with patch("canvas_app.service.time.time",return_value=100):
            self.job(); old=self.cmd("python.claim",{"id":"j","runner":"old"})["outcome"]
        with patch("canvas_app.service.time.time",return_value=141):
            new=self.cmd("python.claim",{"id":"j","runner":"new"})["outcome"]
            self.assertNotEqual(new["lease"],old["lease"])
            with self.assertRaises(Rejected):
                self.cmd("python.complete",{"id":"j","runner":"old","lease":old["lease"],"status":"succeeded","output":{}})

    def test_cancellation_rejects_late_result(self):
        self.job();claim=self.cmd("python.claim",{"id":"j","runner":"tab"})["outcome"]
        self.cmd("python.cancel",{"id":"j"})
        with self.assertRaises(Rejected):
            self.cmd("python.complete",{"id":"j","runner":"tab","lease":claim["lease"],"status":"succeeded","output":{}})

    def test_invalid_widget_specs_are_rejected(self):
        for kind,spec in [("avatar",{"glyph":"ג","color":"url(x)"}),
                          ("quiz",{"question":"q","options":["a","b"],"answerIndex":9}),
                          ("table",{"columns":["a"],"rows":[[1,2]]})]:
            with self.assertRaises(Rejected):
                self.cmd("widget.create",{"id":kind,"kind":kind,"title":"bad","spec":spec,
                    "layout":{"x":0,"y":0,"width":300,"height":200,"collapsed":False}})
        self.assertEqual(self.service.get("alice",self.ws)["version"],0)


if __name__ == "__main__": unittest.main()
