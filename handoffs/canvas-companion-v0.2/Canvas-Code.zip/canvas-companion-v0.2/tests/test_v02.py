"""Regression probes for Claude's concrete findings; no model/API calls."""
import asyncio
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import httpx
from jsonschema import validate,ValidationError
from canvas_app.service import Service,Rejected,Conflict
from canvas_app.server import create_app
from canvas_app.mcp import tool_list


class V02ServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.path=str(Path(self.tmp.name)/"db.sqlite3")
        self.s=Service(self.path,terminal_keep=3)
        self.w=self.s.create("alice","Review room")["id"]
        self.seq=0

    def tearDown(self):self.tmp.cleanup()

    def cmd(self,op,p,version=None,rid=None):
        self.seq+=1
        return self.s.submit("alice",self.w,{"id":rid or str(self.seq),"operation":op,"payload":p,
            "expectedVersion":self.s.get("alice",self.w)["version"] if version is None else version})

    def test_notification_failure_does_not_report_committed_command_as_failed(self):
        def fail():raise RuntimeError("synthetic notification failure")
        self.s.on_commit=fail
        with self.assertLogs("canvas_app.service",level="ERROR"):
            result=self.cmd("persona.update",{"name":"Committed"},rid="notify")
        self.assertEqual(result["status"],"accepted")
        self.assertEqual(self.s.get("alice",self.w)["persona"]["name"],"Committed")
        self.assertEqual(self.cmd("persona.update",{"name":"Committed"},rid="notify"),result)

    def test_legacy_embedded_jobs_migrate_and_reopen_without_duplication(self):
        self.cmd("python.queue",{"id":"legacy","code":"result=9"})
        job=self.s.job("alice",self.w,"legacy")
        with self.s.connect() as db:
            row=db.execute("SELECT state FROM workspaces WHERE id=?",(self.w,)).fetchone()
            state=json.loads(row["state"]);state["jobs"]={"legacy":job}
            db.execute("UPDATE workspaces SET state=? WHERE id=?",(json.dumps(state),self.w))
            db.execute("DELETE FROM jobs WHERE workspace=?",(self.w,))
        reopened=Service(self.path)
        self.assertEqual(reopened.job("alice",self.w,"legacy")["code"],"result=9")
        Service(self.path)
        with reopened.connect() as db:
            self.assertEqual(db.execute("SELECT COUNT(*) FROM jobs WHERE workspace=?",(self.w,)).fetchone()[0],1)
            self.assertNotIn("jobs",json.loads(db.execute("SELECT state FROM workspaces WHERE id=?",(self.w,)).fetchone()[0]))

    def test_retry_after_refresh_returns_stored_receipt(self):
        first=self.cmd("persona.update",{"name":"Moss"},version=0,rid="retry")
        self.cmd("persona.update",{"tone":"Playful"})
        self.assertEqual(self.cmd("persona.update",{"name":"Moss"},rid="retry"),first)
        with self.assertRaises(Rejected):self.cmd("persona.update",{"name":"Different"},rid="retry")

    def test_completion_survives_unrelated_edits_and_does_not_bump_widget_version(self):
        self.cmd("python.queue",{"id":"job","code":"result=4"},version=0)
        claim=self.cmd("python.claim",{"id":"job","runner":"tab"},version=0)["outcome"]
        for n in range(10):self.cmd("persona.update",{"name":f"Companion {n}"})
        self.cmd("python.complete",{"id":"job","runner":"tab","lease":claim["lease"],
            "status":"succeeded","output":{"result":4}},version=0)
        self.assertEqual(self.s.job("alice",self.w,"job")["output"]["result"],4)
        self.assertEqual(self.s.get("alice",self.w)["version"],10)

    def test_claim_retry_rehydrates_only_an_active_lease(self):
        self.cmd("python.queue",{"id":"job","code":"result=4"})
        first=self.cmd("python.claim",{"id":"job","runner":"tab"},rid="claim")["outcome"]
        second=self.cmd("python.claim",{"id":"job","runner":"tab"},rid="claim")["outcome"]
        self.assertEqual(first["lease"],second["lease"])
        self.assertEqual(second["code"],"result=4")
        self.cmd("python.cancel",{"id":"job"})
        old=self.cmd("python.claim",{"id":"job","runner":"tab"},rid="claim")["outcome"]
        self.assertTrue(old["claimExpired"]);self.assertNotIn("code",old)

    def test_pruning_preserves_idempotency_and_archived_status_without_payload(self):
        for i in range(6):
            self.cmd("python.queue",{"id":f"j{i}","code":"# secret input\npass"},rid=f"q{i}")
            self.cmd("python.cancel",{"id":f"j{i}"})
        self.assertEqual(len(self.s.get("alice",self.w)["jobs"]),3)
        archived=self.s.job("alice",self.w,"j0")
        self.assertTrue(archived["archived"]);self.assertNotIn("code",archived)
        self.cmd("python.queue",{"id":"j0","code":"# secret input\npass"},rid="q0")
        with self.assertRaises(Rejected):self.cmd("python.queue",{"id":"j0","code":"pass"})
        with self.s.connect() as db:
            state=db.execute("SELECT state FROM workspaces").fetchone()[0]
            events="".join(r[0] for r in db.execute("SELECT command FROM events"))
            receipts="".join(r[0] for r in db.execute("SELECT response FROM receipts"))
        self.assertNotIn('"jobs"',state)
        self.assertNotIn("secret input",events+receipts)

    def test_snapshot_and_event_feed_do_not_include_job_bodies(self):
        self.cmd("python.queue",{"id":"j","code":"# UNIQUE_CODE_MARKER\npass"})
        self.assertNotIn("UNIQUE_CODE_MARKER",json.dumps(self.s.get("alice",self.w)))
        self.assertNotIn("UNIQUE_CODE_MARKER",json.dumps(self.s.changes("alice",self.w)))
        self.assertIn("UNIQUE_CODE_MARKER",self.s.job("alice",self.w,"j")["code"])

    def test_unknown_fields_and_invalid_widget_reference_rejected(self):
        for op,payload in [("widget.delete",{"id":"x","expectedWidgetVersion":1,"unknown":1}),
                           ("python.queue",{"id":"j","code":"pass","widgetId":"missing"})]:
            with self.assertRaises(Rejected):self.cmd(op,payload)
        self.assertEqual(self.s.get("alice",self.w)["eventCursor"],0)

    def test_list_does_not_parse_other_owners_state(self):
        with self.s.connect() as db:db.execute("INSERT INTO workspaces VALUES(?,?,?)",("other","bob","not JSON"))
        self.assertEqual([w["id"] for w in self.s.list("alice")],[self.w])

    def test_schema_describes_valid_creations_and_invalid_layout(self):
        schema=next(t for t in tool_list() if t["name"]=="widget_create")["inputSchema"]
        specs={"note":{"text":"hello"},"avatar":{"glyph":"ג","color":"#49664e"},
               "python":{"code":"result=4"},"table":{"columns":["n"],"rows":[[1]]},
               "chart":{"labels":["a"],"values":[1]},"drawing":{"shapes":[]},
               "quiz":{"question":"q","options":["a","b"],"answerIndex":0}}
        for kind,spec in specs.items():
            p={"id":kind,"kind":kind,"title":kind,"spec":spec,
               "layout":{"x":10,"y":10,"width":200,"height":120,"collapsed":False}}
            args={"workspaceId":self.w,"commandId":kind,"expectedVersion":0,"payload":p}
            validate(args,schema);self.cmd("widget.create",p)
        args["payload"]["layout"]["width"]=120
        with self.assertRaises(ValidationError):validate(args,schema)
        del args["payload"]["layout"]["collapsed"]
        with self.assertRaises(ValidationError):validate(args,schema)

    def test_missing_job_has_a_readable_error(self):
        with self.assertRaisesRegex(Rejected,"Job not found"):self.s.job("alice",self.w,"missing")


class V02HTTPTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.token="synthetic-token-alice-123"
        self.app=create_app(str(Path(self.tmp.name)/"db.sqlite3"),{self.token:"alice","synthetic-token-bob-123":"bob"})
        self.client=httpx.AsyncClient(transport=httpx.ASGITransport(app=self.app),base_url="http://test")
        self.h={"Authorization":"Bearer "+self.token}

    async def asyncTearDown(self):await self.client.aclose();self.tmp.cleanup()

    async def test_mcp_get_is_405_and_unauthorized_has_challenge(self):
        r=await self.client.get("/mcp");self.assertEqual(r.status_code,405);self.assertEqual(r.headers["allow"],"POST")
        r=await self.client.get("/api/workspaces");self.assertEqual(r.status_code,401)
        self.assertIn("Bearer",r.headers["www-authenticate"])
        self.assertFalse((await self.client.get("/api/info")).json()["oauth"])

    async def test_null_params_are_rpc_errors_not_server_errors(self):
        for method in ("initialize","tools/call"):
            r=await self.client.post("/mcp",json={"jsonrpc":"2.0","id":1,"method":method,"params":None})
            self.assertEqual(r.status_code,200);self.assertEqual(r.json()["error"]["code"],-32602)

    async def open_socket(self,workspace,token,after):
        incoming,outgoing=asyncio.Queue(),asyncio.Queue()
        scope={"type":"websocket","asgi":{"version":"3.0","spec_version":"2.4"},
            "scheme":"ws","path":f"/api/workspaces/{workspace}/ws","raw_path":f"/api/workspaces/{workspace}/ws".encode(),
            "root_path":"","query_string":b"","headers":[(b"host",b"test"),(b"origin",b"http://test")],
            "client":("127.0.0.1",123),"server":("test",80),"subprotocols":[]}
        await incoming.put({"type":"websocket.connect"})
        await incoming.put({"type":"websocket.receive","text":json.dumps({"token":token,"after":after})})
        task=asyncio.create_task(self.app(scope,incoming.get,outgoing.put))
        async def read():return await asyncio.wait_for(outgoing.get(),2)
        self.assertEqual((await read())["type"],"websocket.accept")
        return task,read

    async def stop_task(self,task):
        task.cancel()
        try:await task
        except asyncio.CancelledError:pass

    async def test_websocket_pushes_cursor_events_and_blocks_revoked_member(self):
        s=self.app.state.service;w=s.create("alice","Room")["id"]
        s.submit("alice",w,{"id":"share","expectedVersion":0,"operation":"workspace.share","payload":{"principal":"bob","role":"viewer"}})
        task,read=await self.open_socket(w,"synthetic-token-bob-123",1)
        try:
            self.assertEqual(json.loads((await read())["text"])["type"],"ready")
            self.assertEqual(json.loads((await read())["text"])["type"],"heartbeat")
            s.submit("alice",w,{"id":"edit","expectedVersion":1,"operation":"persona.update","payload":{"name":"Moss"}})
            event=json.loads((await read())["text"])
            self.assertEqual(event["type"],"event");self.assertEqual(event["event"]["operation"],"persona.update")
            self.assertNotIn("command",event["event"])
            await read() # heartbeat
            s.submit("alice",w,{"id":"remove","expectedVersion":2,"operation":"workspace.share","payload":{"principal":"bob","role":"remove"}})
            close=await read();self.assertEqual(close["type"],"websocket.close");self.assertEqual(close["code"],1008)
        finally:await self.stop_task(task)

    async def test_websocket_invalid_token_sees_no_workspace_data(self):
        s=self.app.state.service;w=s.create("alice","Room")["id"]
        task,read=await self.open_socket(w,"invalid",0)
        try:self.assertEqual((await read())["type"],"websocket.close")
        finally:await self.stop_task(task)


if __name__=="__main__":unittest.main()
