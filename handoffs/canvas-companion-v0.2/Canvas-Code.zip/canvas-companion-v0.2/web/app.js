import {readResponse} from "/transport.mjs";
const $ = id => document.getElementById(id);
let token = sessionStorage.getItem("canvas-token") || "", state = null, busy = false;
let worker = null, ready = false, activeJob = null, timeout = null, bootTimer = null, pollBusy = false;
let dragging = false, lastRenderVersion = -1;
let socket=null,socketLive=false,socketGeneration=0,reconnectTimer=null,refreshTimer=null,lastFallback=0;
const runner = crypto.randomUUID();
const canvas = $("canvas"), NS = "http://www.w3.org/2000/svg";
const id = () => crypto.randomUUID();
function node(tag, text, cls) { const n=document.createElement(tag); if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n; }
function toast(message) { $("toast").textContent=message;$("toast").hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$("toast").hidden=true,6000); }
async function api(path, data) {
  const r = await fetch(path,{method:data===undefined?"GET":"POST",headers:{"Authorization":`Bearer ${token}`,"Content-Type":"application/json"},body:data===undefined?undefined:JSON.stringify(data)});
  return readResponse(r);
}
async function refresh() {
  if(!state)return;
  const wid=state.id;
  const fresh=await api(`/api/workspaces/${wid}`);
  if(!state||state.id!==wid)return;
  if((fresh.eventCursor||0)<(state.eventCursor||0))return;
  state=fresh;
  if(!dragging && state.version!==lastRenderVersion)render();
  else renderJobs();
  if(activeJob && state.jobs[activeJob.id]?.status==="cancelled")stopWorker("Job cancelled by a workspace participant.");
}
async function command(operation,payload) {
  if(!state)throw new Error("Open a workspace first.");
  const wid=state.id, commandId=id();
  for(let attempt=0;attempt<2;attempt++){
    try{
      const result=await api(`/api/workspaces/${wid}/commands`,{id:commandId,expectedVersion:state.version,operation,payload});
      await refresh();return result.outcome;
    }catch(error){if(error.status!==409||attempt)throw error;await refresh();}
  }
}
function openForm(title, fields, save, button="Save") {
  $("editor-title").textContent=title;$("editor-fields").replaceChildren();
  const inputs={};
  for(const field of fields){const label=node("label",undefined,"field");label.append(node("span",field.label));const input=node(field.multiline?"textarea":"input");input.value=field.value||"";if(field.secret)input.type="password";label.append(input);inputs[field.key]=input;$("editor-fields").append(label);}
  $("editor-form").querySelector('[type="submit"]').textContent=button;
  $("editor-form").onsubmit=async event=>{event.preventDefault();try{await save(Object.fromEntries(Object.entries(inputs).map(([k,v])=>[k,v.value])));$("editor").close();}catch(error){toast(error.message);}};
  $("editor").showModal();
}
$("editor-close").onclick=()=>$("editor").close();
async function connect() {
  const list=await api("/api/workspaces");
  $("workspaces").replaceChildren();
  for(const ws of list){const option=node("option",ws.title);option.value=ws.id;$("workspaces").append(option);}
  $("status").textContent="API connected";
  if(list.length){const remembered=sessionStorage.getItem("canvas-workspace");await selectWorkspace(list.some(w=>w.id===remembered)?remembered:list[0].id);}
  else{state=null;toast("Connected. Create your first workspace.");}
}
async function selectWorkspace(wid) {
  if(activeJob)throw new Error("Finish or stop this tab's Python job before switching workspace.");
  stopSocket();
  state=await api(`/api/workspaces/${wid}`);lastRenderVersion=-1;sessionStorage.setItem("canvas-workspace",wid);$("workspaces").value=wid;render();startSocket();
}
function stopSocket(){socketGeneration++;clearTimeout(reconnectTimer);clearTimeout(refreshTimer);refreshTimer=null;if(socket)socket.close();socket=null;socketLive=false;}
function scheduleRefresh(){if(refreshTimer!==null)return;refreshTimer=setTimeout(()=>{refreshTimer=null;refresh().catch(e=>toast(e.message));},120);}
function startSocket(){
  if(!state)return;
  const generation=socketGeneration,wid=state.id;
  const ws=new WebSocket(`${location.protocol==="https:"?"wss":"ws"}://${location.host}/api/workspaces/${wid}/ws`);
  socket=ws;
  ws.onopen=()=>ws.send(JSON.stringify({token,after:state.eventCursor||0}));
  ws.onmessage=({data})=>{if(generation!==socketGeneration||!state||state.id!==wid)return;
    let message;try{message=JSON.parse(data);}catch{return;}
    if(message.type==="ready"){socketLive=true;$("status").textContent="Live workspace connected";}
    if(message.type==="event")scheduleRefresh();
  };
  ws.onclose=event=>{if(generation!==socketGeneration)return;socketLive=false;
    $("status").textContent=event.code===1008?"Workspace access denied or revoked":"Reconnecting live workspace…";
    if(event.code===1008){stopWorker("Runner stopped: workspace access changed.");return;}
    reconnectTimer=setTimeout(()=>{if(state?.id===wid&&generation===socketGeneration)startSocket();},1500+Math.random()*1000);
  };
  ws.onerror=()=>{socketLive=false;};
}
$("connect").onclick=()=>openForm("Connect to the local service",[{key:"token",label:"Access token configured by the server owner",value:token,secret:true}],async v=>{token=v.token;await connect();sessionStorage.setItem("canvas-token",token);},"Connect");
$("new-workspace").onclick=()=>openForm("A new shared space",[{key:"title",label:"Name",value:"Our little workshop"}],async v=>{const ws=await api("/api/workspaces",v);sessionStorage.setItem("canvas-workspace",ws.id);await connect();});
$("workspaces").onchange=()=>selectWorkspace($("workspaces").value).catch(e=>toast(e.message));
$("edit-persona").onclick=()=>{if(!state)return toast("Open a workspace first.");const p=state.persona;openForm("The personality you choose to share",[
  {key:"name",label:"Companion name",value:p.name},{key:"tone",label:"Voice and manner",value:p.tone,multiline:true},
  {key:"greeting",label:"A welcoming greeting",value:p.greeting,multiline:true},{key:"examples",label:"Example phrases · one per line",value:p.examples.join("\n"),multiline:true},
  {key:"sharedFacts",label:"Facts you explicitly want to share · one per line",value:p.sharedFacts.join("\n"),multiline:true}],
  v=>command("persona.update",{...v,examples:v.examples.split("\n").filter(Boolean),sharedFacts:v.sharedFacts.split("\n").filter(Boolean)}));};
$("share").onclick=()=>openForm("Share this space",[{key:"principal",label:"Recipient's configured principal name"},{key:"role",label:"Role: viewer, editor, or remove",value:"editor"}],v=>command("workspace.share",v));
$("interface").onclick=()=>{openForm("Agent interface",[{key:"instructions",label:"Connection details · MCP host configuration varies",multiline:true,value:`MCP: ${location.origin}/mcp\nCommand/query API: ${location.origin}/api/workspaces\nOptional GraphQL: ${location.origin}/graphql\n\nUse your configured bearer token. A local URL is reachable only from clients with access to this machine. Publishing and OAuth are separate integration steps.\n\nAsk the assistant to call workspace_inspect, read persona, then create or update a widget. No model is built into this page.`}],async()=>{},"Close");};
$("export").onclick=()=>{if(!state)return;const blob=new Blob([JSON.stringify({format:"canvas-companion-export/v1",workspace:state},null,2)],{type:"application/json"});const a=node("a");a.href=URL.createObjectURL(blob);a.download="canvas-workspace.json";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);};
const sampleCode="result = {\n    'columns': ['n', 'n squared'],\n    'rows': [[n, n*n] for n in range(1, 11)]\n}\nprint('Ten squares, computed in Python.')";
function defaults(kind){return {
  note:{text:"An idea to explore together…"},avatar:{glyph:"ג",color:"#49664e",message:""},python:{code:sampleCode},
  quiz:{question:"Which number is a square?",options:["12","16","18"],answerIndex:1,explanation:"4 × 4 = 16. Want to make a different question? Ask your connected assistant."}
}[kind];}
async function add(kind,spec=defaults(kind),title){if(!state)return toast("Open a workspace first.");const count=Object.keys(state.widgets).length;await command("widget.create",{id:id(),kind,title:title||({note:"A little thought",avatar:state.persona.name,python:"Python workshop",quiz:"Sample square-number quiz"}[kind]||kind),spec,layout:{x:40+(count%3)*350,y:35+Math.floor(count/3)*300,width:320,height:kind==="avatar"?300:260,collapsed:false}});}
document.querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>add(b.dataset.add).catch(e=>toast(e.message)));
function edit(w){const jsonMode=!["note","avatar","python"].includes(w.kind);let fields=[{key:"title",label:"Title",value:w.title}];
  if(w.kind==="note")fields.push({key:"text",label:"Note",value:w.spec.text,multiline:true});
  if(w.kind==="python")fields.push({key:"code",label:"Python · assign a JSON-compatible value to result",value:w.spec.code,multiline:true});
  if(w.kind==="avatar")fields.push({key:"glyph",label:"Avatar glyph",value:w.spec.glyph||"ג"},{key:"color",label:"Color (#rrggbb)",value:w.spec.color||"#49664e"},{key:"message",label:"Message · blank uses the shared greeting",value:w.spec.message,multiline:true});
  if(jsonMode)fields.push({key:"spec",label:"Advanced widget descriptor (JSON)",value:JSON.stringify(w.spec,null,2),multiline:true});
  openForm("Edit widget",fields, v=>{const {title,...rest}=v;return command("widget.update",{id:w.id,expectedWidgetVersion:w.version,title,spec:jsonMode?JSON.parse(v.spec):rest});});
}
function button(text,fn){const b=node("button",text);b.onclick=event=>{event.stopPropagation();Promise.resolve().then(fn).catch(e=>toast(e.message));};return b;}
function render(){
  if(!state)return;lastRenderVersion=state.version;
  $("workspace-title").textContent=state.title;$("persona-name").textContent=state.persona.name;$("persona-tone").textContent=state.persona.tone;
  canvas.querySelectorAll(".widget").forEach(n=>n.remove());$("empty").hidden=Object.keys(state.widgets).length>0;
  let right=1250,bottom=900;
  for(const w of Object.values(state.widgets)){
    const el=node("section",undefined,"widget"+(w.layout.collapsed?" collapsed":""));el.dataset.id=w.id;el.setAttribute("aria-label",w.title);Object.assign(el.style,{left:w.layout.x+"px",top:w.layout.y+"px",width:w.layout.width+"px",height:w.layout.height+"px"});
    const head=node("div",undefined,"widget-head");head.append(node("strong",w.title));head.append(button("✎",()=>edit(w)),button(w.layout.collapsed?"＋":"−",()=>command("widget.update",{id:w.id,expectedWidgetVersion:w.version,layout:{...w.layout,collapsed:!w.layout.collapsed}})),button("×",()=>command("widget.delete",{id:w.id,expectedWidgetVersion:w.version})));
    const body=node("div",undefined,"widget-body");paint(body,w);el.append(head,body);
    const resize=node("div",undefined,"resize");resize.setAttribute("aria-hidden","true");el.append(resize);canvas.append(el);
    manipulate(head,el,w,false);manipulate(resize,el,w,true);
    right=Math.max(right,w.layout.x+w.layout.width+50);bottom=Math.max(bottom,w.layout.y+w.layout.height+50);
  }
  canvas.style.minWidth=right+"px";canvas.style.minHeight=bottom+"px";renderJobs();
}
function manipulate(handle,el,w,resizing){handle.onpointerdown=e=>{if(e.target.closest("button"))return;e.preventDefault();dragging=true;handle.setPointerCapture(e.pointerId);const start={x:e.clientX,y:e.clientY}, next={...w.layout};handle.onpointermove=event=>{if(resizing){next.width=Math.max(180,w.layout.width+event.clientX-start.x);next.height=Math.max(100,w.layout.height+event.clientY-start.y);el.style.width=next.width+"px";el.style.height=next.height+"px";}else{next.x=Math.max(0,w.layout.x+event.clientX-start.x);next.y=Math.max(0,w.layout.y+event.clientY-start.y);el.style.left=next.x+"px";el.style.top=next.y+"px";}};
  const finish=async event=>{handle.onpointermove=null;handle.onpointerup=null;handle.onpointercancel=null;dragging=false;if(event.type==="pointercancel"){render();return;}try{await command("widget.update",{id:w.id,expectedWidgetVersion:w.version,layout:next});}catch(error){toast(error.message);await refresh();render();}};handle.onpointerup=finish;handle.onpointercancel=finish;};}
function svgNode(tag,attrs,text){const n=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,String(v));if(text!==undefined)n.textContent=text;return n;}
function paint(body,w){const s=w.spec;
  if(w.kind==="note"){body.append(node("div",s.text||"","long"));}
  if(w.kind==="avatar"){const room=node("div",undefined,"avatar-room"),a=node("div",s.glyph||"ג","avatar");a.style.background=s.color||"#49664e";room.append(a,node("p",s.message||state.persona.greeting));body.append(room,node("div","A shared personality, expressed through a local avatar.","quiet"));}
  if(w.kind==="python"){body.append(node("pre",s.code||""),button("Run in this tab",async()=>{if(!$("enable-python").checked)throw new Error("Enable Python in this tab first.");await command("python.queue",{id:id(),code:s.code,bindings:{},widgetId:w.id});}));}
  if(w.kind==="table"){const table=node("table"),head=node("tr");for(const c of s.columns||[])head.append(node("th",c));table.append(head);for(const row of s.rows||[]){const tr=node("tr");for(const value of row)tr.append(node("td",typeof value==="object"?JSON.stringify(value):String(value)));table.append(tr);}body.append(table);}
  if(w.kind==="chart"){const svg=svgNode("svg",{viewBox:"0 0 360 220",role:"img","aria-label":w.title});const vals=s.values||[],max=Math.max(1,...vals.map(Math.abs));svg.append(svgNode("line",{x1:15,x2:345,y1:110,y2:110,stroke:"#b8c5b0"}));vals.forEach((v,i)=>{const x=20+i*(320/vals.length);svg.append(svgNode("rect",{x,y:110-Math.max(0,v)/max*85,width:Math.max(2,260/vals.length),height:Math.abs(v)/max*85,fill:"#769369"}));svg.append(svgNode("text",{x,y:215,"font-size":10},s.labels[i]));});body.append(svg);}
  if(w.kind==="drawing"){const svg=svgNode("svg",{viewBox:"0 0 360 240",role:"img","aria-label":w.title});for(const shape of s.shapes||[]){const size=shape.size||20,x=shape.x||20,y=shape.y||20;svg.append(svgNode(shape.type==="circle"?"circle":"rect",shape.type==="circle"?{cx:x,cy:y,r:size,fill:"#a8bc9a"}:{x,y,width:size,height:size,fill:"#78946d"}));if(shape.label)svg.append(svgNode("text",{x,y,"font-size":12},shape.label));}body.append(svg);}
  if(w.kind==="quiz"){body.append(node("p",s.question));const options=node("div",undefined,"quiz-options"),feedback=node("div","Choose an answer.","feedback");s.options.forEach((option,i)=>options.append(button(option,()=>{feedback.textContent=i===s.answerIndex?`Yes! ${s.explanation||""}`:"Try another possibility. No points lost.";})));body.append(options,feedback,node("small","Answer feedback is local to this view.","quiet"));}
}
async function jobDetail(job){return api(`/api/workspaces/${state.id}/jobs/${encodeURIComponent(job.id)}`);}
function renderJobs(){$("jobs").replaceChildren();const jobs=Object.values(state.jobs);if(!jobs.length)$("jobs").textContent="No Python jobs yet.";for(const job of jobs.slice(0,10)){const div=node("div",undefined,"job");div.append(node("span",`${job.id.slice(0,8)} · ${job.status}`));div.append(button("Inspect",async()=>{const full=await jobDetail(job);openForm("Recorded Python job",[{key:"job",label:"Status and actual recorded output",value:JSON.stringify(full,null,2),multiline:true}],async()=>{},"Close");}));
  if(["queued","running"].includes(job.status))div.append(button("Cancel",()=>command("python.cancel",{id:job.id})));
  if(job.status==="succeeded"&&job.hasOutput)div.append(button("Make table",async()=>{const full=await jobDetail(job),result=full.output?.result;if(!result||!Array.isArray(result.columns)||!Array.isArray(result.rows))return toast("This result is not a table, or its retained details have expired.");await add("table",{columns:result.columns,rows:result.rows,jobId:job.id},"Python result");}));
  $("jobs").append(div);}}
function stopWorker(reason){if(worker)worker.terminate();worker=null;ready=false;clearTimeout(timeout);clearTimeout(bootTimer);activeJob=null;$("enable-python").checked=false;$("runtime-state").textContent=reason;}
$("enable-python").onchange=()=>{if(!$("enable-python").checked){const job=activeJob;stopWorker("Runner off. Queued jobs will wait.");if(job)command("python.cancel",{id:job.id}).catch(e=>toast(e.message));return;}
  $("runtime-state").textContent="Loading Pyodide…";worker=new Worker("/python-worker.js");
  const runtimeURL=new URL("pyodide/pyodide.js",location.href).href;
  // Default CDN, or supply a same-origin runtime using ?runtime=local.
  const url=new URLSearchParams(location.search).get("runtime")==="local"?runtimeURL:"https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js";
  bootTimer=setTimeout(()=>stopWorker("Runtime loading timed out."),90000);
  worker.onerror=event=>{clearTimeout(bootTimer);stopWorker(`Worker error: ${event.message}`);};
  worker.onmessage=async({data})=>{if(data.type==="ready"){clearTimeout(bootTimer);ready=true;$("runtime-state").textContent=`Pyodide ${data.version} · ready`;return;}
    if(data.type==="init-error"){clearTimeout(bootTimer);stopWorker(data.error);return;}
    if(data.type==="completed"&&activeJob&&data.id===activeJob.id&&data.lease===activeJob.lease){clearTimeout(timeout);const job=activeJob;try{await command("python.complete",{id:job.id,runner,lease:job.lease,status:data.status,output:data.output});}catch(error){toast(error.message);}finally{activeJob=null;}}};
  worker.postMessage({type:"init",runtimeURL:url});};
async function pump(){if(!ready||!worker||activeJob||!state)return;const now=Date.now()/1000;const job=Object.values(state.jobs).find(j=>j.status==="queued"||(j.status==="running"&&j.expires<now));if(!job)return;
  const claimed=await command("python.claim",{id:job.id,runner});activeJob=claimed;worker.postMessage({type:"run",id:claimed.id,lease:claimed.lease,code:claimed.code,bindings:claimed.bindings});
  timeout=setTimeout(async()=>{const stalled=activeJob;if(!stalled)return;stopWorker("Python time limit reached. Re-enable the runner to continue.");try{await command("python.complete",{id:stalled.id,runner,lease:stalled.lease,status:"failed",output:{error:"Worker terminated after 15 seconds",runtime:"browser worker timeout"}});}catch(error){toast(error.message);}},15000);
}
// No periodic full-snapshot download. A lightweight event fallback is used only
// while WebSocket push is unavailable. Local runner scheduling remains periodic.
setInterval(async()=>{if(pollBusy||!state||dragging)return;pollBusy=true;try{
  if(!socketLive&&Date.now()-lastFallback>10000){lastFallback=Date.now();const events=await api(`/api/workspaces/${state.id}/events?after=${state.eventCursor||0}`);if(events.length)await refresh();}
  await pump();
}catch(error){$("status").textContent=error.message;}finally{pollBusy=false;}},1000);
if(token)connect().catch(e=>{$("status").textContent=e.message;});
