/* This worker never receives the server access token. Runtime code is supplied
 * by the workspace's authorized participants; this is not a hostile-code sandbox.
 */
let py;
self.onmessage = async ({data}) => {
  if (data.type === "init") {
    try {
      importScripts(data.runtimeURL);
      py = await loadPyodide({indexURL: new URL(".", data.runtimeURL).href});
      self.postMessage({type:"ready", version:py.version});
    } catch (error) { self.postMessage({type:"init-error", error:String(error)}); }
    return;
  }
  if (data.type !== "run" || !py) return;
  let stdout = "", stderr = "", ns;
  py.setStdout({batched: value => {stdout = (stdout + value + "\n").slice(0,8000);}});
  py.setStderr({batched: value => {stderr = (stderr + value + "\n").slice(0,8000);}});
  try {
    ns = py.toPy({__name__: "__main__", bindings:data.bindings || {}});
    await py.runPythonAsync(data.code, {globals:ns});
    py.globals.set("_job_namespace", ns);
    const raw = py.runPython("__import__('json').dumps(_job_namespace.get('result'), ensure_ascii=False, allow_nan=False)");
    const result = JSON.parse(raw);
    const output = {stdout, stderr, result, runtime:`Pyodide ${py.version}`};
    if (new TextEncoder().encode(JSON.stringify(output)).length > 200000) throw new Error("Result too large; return a smaller JSON value.");
    self.postMessage({type:"completed", id:data.id, lease:data.lease, status:"succeeded", output});
  } catch (error) {
    self.postMessage({type:"completed", id:data.id, lease:data.lease, status:"failed",
      output:{stdout, stderr, error:String(error).slice(0,8000), runtime:`Pyodide ${py.version}`}});
  } finally {
    if (py.globals.has("_job_namespace")) py.globals.delete("_job_namespace");
    if (ns) ns.destroy();
  }
};
