/** Preserve HTTP status when a reverse proxy/server sends a non-JSON error. */
export async function readResponse(response) {
  const raw=await response.text();
  let body;
  try{body=JSON.parse(raw);}catch{body={detail:raw.slice(0,500)||`HTTP ${response.status}`};}
  if(!response.ok){const error=new Error(body.reason||body.detail||`HTTP ${response.status}`);error.status=response.status;throw error;}
  return body;
}
