"""Local bounded-history probe; no Python evaluation or network requests."""
import json,tempfile
from pathlib import Path
from canvas_app.service import Service
with tempfile.TemporaryDirectory() as d:
 s=Service(Path(d)/'probe.db');w=s.create('owner','Probe')['id']
 for i in range(300):
  for op,p in [('python.queue',{'id':f'j{i}','code':'#'+'x'*2048}),('python.cancel',{'id':f'j{i}'})]:
   s.submit('owner',w,{'id':f'{op}{i}','operation':op,'expectedVersion':0,'payload':p})
 state=s.get('owner',w)
 print(json.dumps({'jobs_created':300,'retained_job_summaries':len(state['jobs']),'snapshot_utf8_bytes':len(json.dumps(state,ensure_ascii=False).encode()),'archived_first_job':s.job('owner',w,'j0')['archived']}))
