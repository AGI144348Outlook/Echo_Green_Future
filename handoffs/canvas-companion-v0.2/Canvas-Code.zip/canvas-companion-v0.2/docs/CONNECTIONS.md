# Connection and inspection guide

## Local companion + API

1. Start the local server using README instructions.
2. Open the browser and connect using a configured token.
3. Create a workspace, copy its ID from the export or inspect it with `workspace_list`.
4. Give your local assistant host access to the MCP bridge or write an HTTP client.
5. Call `workspace_inspect`; read the selected personality and widget versions.
6. Create an avatar/note/quiz through `widget_create`.
7. Refresh/poll the same workspace in the browser and verify the saved IDs.
8. Enable the browser Python runner before expecting Python job results.

Local stdio host configuration varies. A typical shape is:

```json
{
  "mcpServers": {
    "canvas-companion": {
      "command": "/absolute/path/to/.venv/bin/python",
      "args": ["/absolute/path/to/canvas-companion-boilerplate/mcp_stdio.py"],
      "env": {
        "CANVAS_URL": "http://127.0.0.1:8000",
        "CANVAS_ACCESS_TOKEN": "YOUR_CONFIGURED_TOKEN"
      }
    }
  }
}
```

Configure secrets using the host's supported secret facilities where available. Do not commit real tokens. There is no automatic connector installation in this project, and no external assistant is claimed connected just because MCP test requests succeed.

## Personality and avatar

The shared personality is an authored profile. An AI caller can consult it before generating widget content. The avatar is an ordinary editable widget bound to that workspace's profile. It is not the model itself, and its animation or message does not prove an AI is presently connected. The sample scene can be created by a human or an API client.

## Review request

Review only until implementation changes are separately authorized. Inspect command/query reuse, authorization, durable transactions, idempotency, stale writes, lease ownership/cancellation, markup handling and the separation of profile identity from avatar presentation.

Check `VALIDATION.md` before treating a path as verified. Particularly inspect actual Pyodide startup/cancellation in a browser, provider-specific MCP compatibility, the optional GraphQL extra, and concurrent browser edits. The first renderer set is intentionally bounded; propose an isolated extension protocol before adding executable user HTML.

The source is local-only boilerplate. Do not deploy it publicly, add external service keys, or replace Echo repository files as part of inspection.
