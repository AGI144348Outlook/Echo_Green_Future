// Group Canvas client: avatars, side-conversation links, speech bubbles,
// shared drawing, and a thread panel. Talks to the room over one WebSocket.

const $ = (s) => document.querySelector(s);
const canvas = $("#canvas");
const ctx = canvas.getContext("2d");

const S = {
  ws: null, room: "lobby", me: null,
  seats: {}, threads: {}, objects: [],
  activeThread: "main",
  unread: new Set(),
  bubbles: {},          // seatId -> {text, at}
  typing: {},           // seatId -> at
  tool: "move",
  view: { x: 0, y: 0 }, // pan offset
};

// ---------- connection ----------

$("#joinForm").addEventListener("submit", (e) => {
  e.preventDefault();
  S.room = ($("#roomInput").value || "lobby").trim();
  const name = $("#nameInput").value.trim();
  try { localStorage.setItem("gc-name", name); } catch {}
  connect(name);
  $("#join").remove();
});
try { $("#nameInput").value = localStorage.getItem("gc-name") || ""; } catch {}

function connect(name) {
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/room/${encodeURIComponent(S.room)}/ws`);
  S.ws = ws;
  let savedSeat = null;
  try { savedSeat = localStorage.getItem(`gc-seat-${S.room}`); } catch {}
  ws.onopen = () => send({ type: "join", name, seatId: savedSeat });
  ws.onmessage = (e) => onServer(JSON.parse(e.data));
  ws.onclose = () => setTimeout(() => connect(name), 1500); // simple reconnect
}

function send(obj) {
  if (S.ws?.readyState === 1) S.ws.send(JSON.stringify(obj));
}

function onServer(m) {
  switch (m.type) {
    case "welcome":
      S.me = m.seatId;
      try { localStorage.setItem(`gc-seat-${S.room}`, m.seatId); } catch {}
      break;
    case "snapshot":
      S.seats = Object.fromEntries(m.seats.map((s) => [s.id, s]));
      S.threads = Object.fromEntries(m.threads.map((t) => [t.id, t]));
      S.objects = m.canvas;
      if (!S.threads[S.activeThread]) S.activeThread = "main";
      renderPanel();
      break;
    case "message": {
      const t = S.threads[m.message.threadId];
      if (!t) break;
      t.messages.push(m.message);
      t.lastAt = m.message.at;
      delete S.typing[m.message.from];
      S.bubbles[m.message.from] = { text: m.message.text, at: Date.now() };
      if (m.message.threadId !== S.activeThread) S.unread.add(m.message.threadId);
      renderPanel();
      break;
    }
    case "activity": {
      // Someone spoke in a thread. If we can't read it, show "…" over them.
      const t = S.threads[m.threadId];
      if (t) t.lastAt = m.at;
      if (t?.private) S.bubbles[m.seatId] = { text: "…", at: Date.now() };
      break;
    }
    case "typing": S.typing[m.seatId] = Date.now(); break;
    case "seat_moved":
      if (S.seats[m.seatId]) Object.assign(S.seats[m.seatId], { x: m.x, y: m.y });
      break;
    case "canvas": S.objects = m.canvas; break;
    case "thread_opened": selectThread(m.threadId); break;
    case "error": console.warn(m.error); break;
  }
}

// ---------- panel ----------

function threadLabel(t) {
  if (t.id === "main") return "Room";
  if (t.title) return t.title;
  const names = (t.members || []).filter((id) => id !== S.me).map((id) => S.seats[id]?.name || "?");
  return (t.private ? "🔒 " : "💬 ") + names.join(" + ");
}

function renderPanel() {
  const tabs = $("#tabs");
  tabs.innerHTML = "";
  const list = Object.values(S.threads)
    .filter((t) => !t.private)
    .sort((a, b) => (a.id === "main" ? -1 : b.id === "main" ? 1 : b.lastAt - a.lastAt));
  for (const t of list) {
    const b = document.createElement("button");
    b.className = "tab" + (t.id === S.activeThread ? " active" : "");
    b.textContent = threadLabel(t);
    if (S.unread.has(t.id)) b.appendChild(Object.assign(document.createElement("span"), { className: "dot" }));
    b.onclick = () => selectThread(t.id);
    tabs.appendChild(b);
  }

  const box = $("#messages");
  const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 60;
  box.innerHTML = "";
  for (const m of S.threads[S.activeThread]?.messages || []) {
    const div = document.createElement("div");
    if (m.from === "system") {
      div.className = "msg system";
      div.textContent = m.text;
    } else {
      const seat = S.seats[m.from];
      div.className = "msg";
      const who = Object.assign(document.createElement("div"), { className: "who", textContent: seat?.name || "?" });
      who.style.color = seat?.color || "inherit";
      div.append(who, document.createTextNode(m.text));
    }
    box.appendChild(div);
  }
  if (nearBottom) box.scrollTop = box.scrollHeight;
}

function selectThread(id) {
  S.activeThread = id;
  S.unread.delete(id);
  renderPanel();
  $("#messages").scrollTop = 1e9;
}

$("#composer").addEventListener("submit", (e) => {
  e.preventDefault();
  const text = $("#input").value.trim();
  if (!text) return;
  send({ type: "say", threadId: S.activeThread, text });
  $("#input").value = "";
});

// ---------- tools ----------

document.querySelectorAll("#tools [data-tool]").forEach((b) => {
  b.onclick = () => {
    S.tool = b.dataset.tool;
    document.querySelectorAll("#tools [data-tool]").forEach((x) => x.classList.toggle("on", x === b));
  };
});

$("#addAi").onclick = () => {
  const name = prompt("AI name (no spaces, used for @mentions):", "Nova");
  if (!name) return;
  const model = prompt("OpenRouter model id (blank = default):", "") || undefined;
  const persona = prompt("Persona / role:", "A playful artist who loves drawing on the canvas.") || undefined;
  send({ type: "add_ai", name: name.replace(/\s+/g, ""), model, persona });
};

$("#clear").onclick = () => {
  if (confirm("Clear the shared canvas for everyone?")) send({ type: "canvas", op: { kind: "clear" } });
};

// ---------- canvas input ----------

const AVATAR_R = 22;
let drag = null;

function toWorld(e) {
  const r = canvas.getBoundingClientRect();
  return { x: e.clientX - r.left - S.view.x, y: e.clientY - r.top - S.view.y };
}

function seatAt(p) {
  return Object.values(S.seats).reverse()
    .find((s) => Math.hypot(s.x - p.x, s.y - p.y) <= AVATAR_R + 6);
}

canvas.addEventListener("pointerdown", (e) => {
  canvas.setPointerCapture(e.pointerId);
  const p = toWorld(e);
  const seat = seatAt(p);
  if (S.tool === "move") {
    if (seat && seat.id === S.me) drag = { kind: "self", moved: false };
    else if (seat) drag = { kind: "tapSeat", seat };
    else drag = { kind: "pan", sx: e.clientX, sy: e.clientY, vx: S.view.x, vy: S.view.y };
    return;
  }
  const color = S.seats[S.me]?.color || "#888";
  if (S.tool === "text") {
    const text = prompt("Text:");
    if (text) send({ type: "canvas", op: { kind: "add", shape: "text", x: p.x, y: p.y, text, color } });
  } else {
    send({ type: "canvas", op: { kind: "add", shape: S.tool, x: p.x - 30, y: p.y - 30, w: 60, h: 60, r: 30, color } });
  }
});

canvas.addEventListener("pointermove", (e) => {
  if (!drag) return;
  if (drag.kind === "self") {
    const p = toWorld(e);
    Object.assign(S.seats[S.me], { x: p.x, y: p.y });
    drag.moved = true;
  } else if (drag.kind === "pan") {
    S.view.x = drag.vx + (e.clientX - drag.sx);
    S.view.y = drag.vy + (e.clientY - drag.sy);
  }
});

canvas.addEventListener("pointerup", () => {
  if (drag?.kind === "self" && drag.moved) {
    const me = S.seats[S.me];
    send({ type: "move", x: me.x, y: me.y });
  } else if (drag?.kind === "tapSeat") {
    // Tap another avatar: open (or reuse) a side conversation with them.
    send({ type: "open_thread", with: [drag.seat.id] });
  }
  drag = null;
});

// ---------- drawing ----------

function resize() {
  const dpr = window.devicePixelRatio || 1;
  canvas.width = canvas.clientWidth * dpr;
  canvas.height = canvas.clientHeight * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
window.addEventListener("resize", resize);
resize();

const css = (v) => getComputedStyle(document.documentElement).getPropertyValue(v).trim();

function draw() {
  const W = canvas.clientWidth, H = canvas.clientHeight;
  ctx.clearRect(0, 0, W, H);
  ctx.save();
  ctx.translate(S.view.x, S.view.y);

  // Shared drawing layer
  for (const o of S.objects) {
    ctx.fillStyle = o.color; ctx.strokeStyle = o.color; ctx.lineWidth = 3;
    if (o.shape === "rect") ctx.fillRect(o.x, o.y, o.w, o.h);
    else if (o.shape === "circle") { ctx.beginPath(); ctx.arc(o.x + o.r, o.y + o.r, o.r, 0, 7); ctx.fill(); }
    else if (o.shape === "line") { ctx.beginPath(); ctx.moveTo(o.x, o.y); ctx.lineTo(o.x2, o.y2); ctx.stroke(); }
    else if (o.shape === "text") { ctx.font = "16px system-ui"; ctx.fillText(o.text, o.x, o.y); }
  }

  // Side conversations: dashed links between members, brighter when recent
  const now = Date.now();
  for (const t of Object.values(S.threads)) {
    if (t.id === "main" || !Array.isArray(t.members)) continue;
    const pts = t.members.map((id) => S.seats[id]).filter(Boolean);
    if (pts.length < 2) continue;
    const fresh = now - (t.lastAt || 0) < 15000;
    ctx.setLineDash([6, 6]);
    ctx.lineWidth = t.id === S.activeThread ? 3 : 2;
    ctx.strokeStyle = fresh ? css("--accent") : css("--line");
    ctx.beginPath();
    for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
      ctx.moveTo(pts[i].x, pts[i].y); ctx.lineTo(pts[j].x, pts[j].y);
    }
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Avatars
  for (const s of Object.values(S.seats)) {
    ctx.globalAlpha = s.online === false ? 0.35 : 1;
    ctx.fillStyle = s.color;
    ctx.beginPath(); ctx.arc(s.x, s.y, AVATAR_R, 0, 7); ctx.fill();
    if (s.id === S.me) { ctx.lineWidth = 3; ctx.strokeStyle = css("--ink"); ctx.stroke(); }
    ctx.fillStyle = "#fff"; ctx.font = "bold 14px system-ui"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText(s.kind === "ai" ? "✦" : s.name[0]?.toUpperCase() || "?", s.x, s.y + 1);
    ctx.fillStyle = css("--ink"); ctx.font = "12px system-ui";
    ctx.fillText(s.name, s.x, s.y + AVATAR_R + 12);
    ctx.globalAlpha = 1;
  }

  // Speech bubbles (last 6s) and typing indicators
  for (const s of Object.values(S.seats)) {
    const b = S.bubbles[s.id];
    let text = null;
    if (S.typing[s.id] && now - S.typing[s.id] < 20000) text = "…";
    else if (b && now - b.at < 6000) text = b.text.length > 40 ? b.text.slice(0, 39) + "…" : b.text;
    if (text) bubble(s.x, s.y - AVATAR_R - 10, text);
  }

  ctx.restore();
  requestAnimationFrame(draw);
}

function bubble(x, y, text) {
  ctx.font = "13px system-ui"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
  const w = Math.min(240, ctx.measureText(text).width + 16), h = 24;
  ctx.fillStyle = css("--bubble"); ctx.strokeStyle = css("--line"); ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.roundRect(x - w / 2, y - h, w, h, 10);
  ctx.moveTo(x - 5, y); ctx.lineTo(x, y + 6); ctx.lineTo(x + 5, y);
  ctx.fill(); ctx.stroke();
  ctx.fillStyle = css("--ink");
  ctx.fillText(text, x, y - h / 2, w - 10);
}

requestAnimationFrame(draw);
