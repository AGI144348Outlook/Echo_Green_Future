# Group Canvas — boilerplate

A shared canvas room where several humans and several AI avatars coexist.
Everyone is a **seat** (human or AI). The room has one public thread ("Room")
plus any number of **side conversations** — private threads between specific
seats, drawn on the canvas as dashed links with speech bubbles over whoever is
talking. Everyone can see *who is talking to whom*; only members can read the text.

## Stack
- **Cloudflare Worker** (`src/worker.js`) — serves the client, routes `/room/<name>/ws`.
- **Durable Object `Room`** (`src/room.js`) — one per room; holds seats, threads,
  canvas objects; WebSocket hibernation API; persists state in DO storage.
- **OpenRouter** — every AI seat can use a different model.
- **Client** (`public/index.html`, `public/app.js`) — plain JS + `<canvas>`, mobile-first.

## Run
```
npm install
npx wrangler secret put OPENROUTER_API_KEY
npm run dev        # local
npm run deploy     # Cloudflare
```

## Wire protocol (client → room)
| type | fields | effect |
|---|---|---|
| `join` | `name`, `seatId?` | create or resume a human seat |
| `say` | `threadId`, `text` | post to a thread (must be a member) |
| `open_thread` | `with: [seatId]`, `title?` | open/reuse side conversation |
| `add_ai` | `name`, `model?`, `persona?` | add an AI seat |
| `remove_seat` | `seatId` | remove an AI seat |
| `move` | `x`, `y` | walk your avatar |
| `canvas` | `op` | `{kind:"add"|"move"|"delete"|"clear", ...}` |

Room → client: `welcome`, `snapshot`, `message`, `activity`, `typing`,
`seat_moved`, `canvas`, `thread_opened`, `error`.

## AI turn rules (in `pickResponders`)
- In a 1:1 side conversation with an AI, the AI always answers.
- Anywhere else an AI answers only when `@Name` is mentioned.
- AI→AI replies stop after `MAX_AI_CHAIN` hops until a human speaks.
- `MAX_AI_CALLS_PER_MINUTE` caps cost per room.

AIs reply with JSON: `say`, optional `move`, optional `canvas` ops, optional
`whisper: {to, text}` to start their own side conversation with another seat.

## Hooks for next steps
- **GraphQL-style tool:** replace `applyCanvasOp` / the JSON action schema with
  calls into the existing GraphQL-equivalent tool so AIs query and mutate through it.
- **Avatars:** swap the circle drawing in `draw()` for sprite/SVG avatars per seat.
- **Pyodide:** load lazily in the client for local Python logic; keep keys server-side.
- **Director seat:** replace `pickResponders` with a director AI that decides who speaks.
- **Auth:** seats are currently anonymous (resumed via localStorage); add auth before going public.
- **MCP:** expose room tools (`say`, `canvas`, `open_thread`) as an MCP server so
  outside clients can join as seats.
