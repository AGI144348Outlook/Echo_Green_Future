// Room: one Durable Object per room. Holds every seat (human or AI),
// every thread (the shared "main" room plus side conversations / speech
// bubbles between specific seats), and the shared canvas objects.
// Humans connect over WebSocket; AI seats live server-side and answer
// through OpenRouter.

import { DurableObject } from "cloudflare:workers";

const MAX_MESSAGES_PER_THREAD = 200;
const MAX_CONTEXT_MESSAGES = 20;   // what an AI sees per turn
const MAX_AI_CHAIN = 3;            // AI->AI replies before it must wait for a human
const MAX_AI_CALLS_PER_MINUTE = 20; // per room cost guard
const COLORS = ["#e4572e", "#29335c", "#f3a712", "#669bbc", "#8a4fff", "#2a9d8f", "#d62828", "#6a994e"];

const uid = () => crypto.randomUUID().slice(0, 8);

export class Room extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.state = null;
    this.aiCalls = [];
    ctx.blockConcurrencyWhile(async () => {
      this.state = (await ctx.storage.get("state")) || {
        seats: {},      // id -> {id, name, kind, model, persona, x, y, color}
        threads: {      // id -> {id, title, members: [seatId] | "all", messages: []}
          main: { id: "main", title: "Room", members: "all", messages: [] },
        },
        canvas: [],     // [{id, shape, x, y, w, h, r, color, text, by}]
      };
    });
  }

  save() {
    return this.ctx.storage.put("state", this.state);
  }

  // ---------- connections ----------

  async fetch(request) {
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("Expected WebSocket", { status: 426 });
    }
    const pair = new WebSocketPair();
    this.ctx.acceptWebSocket(pair[1]);
    pair[1].serializeAttachment({ seatId: null });
    return new Response(null, { status: 101, webSocket: pair[0] });
  }

  async webSocketMessage(ws, raw) {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    const { seatId } = ws.deserializeAttachment() || {};

    if (msg.type === "join") return this.onJoin(ws, msg);
    if (!seatId || !this.state.seats[seatId]) return this.send(ws, { type: "error", error: "Join first" });

    switch (msg.type) {
      case "say":         return this.onSay(seatId, msg.threadId, msg.text, 0);
      case "open_thread": return this.onOpenThread(seatId, msg.with, msg.title);
      case "add_ai":      return this.onAddAI(seatId, msg);
      case "remove_seat": return this.onRemoveSeat(msg.seatId);
      case "move":        return this.onMove(seatId, msg.x, msg.y);
      case "canvas":      return this.onCanvas(seatId, msg.op);
    }
  }

  async webSocketClose(ws) {
    const { seatId } = ws.deserializeAttachment() || {};
    if (seatId && this.state.seats[seatId]) {
      this.state.seats[seatId].online = false;
      await this.save();
      this.broadcastSnapshot();
    }
  }

  async webSocketError(ws) { return this.webSocketClose(ws); }

  // ---------- handlers ----------

  async onJoin(ws, { name, seatId }) {
    let seat = seatId && this.state.seats[seatId];
    if (!seat) {
      seat = {
        id: uid(),
        name: String(name || "Guest").slice(0, 24),
        kind: "human",
        x: 80 + Math.random() * 240,
        y: 120 + Math.random() * 240,
        color: COLORS[Object.keys(this.state.seats).length % COLORS.length],
      };
      this.state.seats[seat.id] = seat;
    }
    seat.online = true;
    ws.serializeAttachment({ seatId: seat.id });
    await this.save();
    this.send(ws, { type: "welcome", seatId: seat.id });
    this.broadcastSnapshot();
  }

  async onAddAI(_bySeat, { name, model, persona }) {
    const seat = {
      id: uid(),
      name: String(name || "AI").slice(0, 24),
      kind: "ai",
      model: model || this.env.DEFAULT_MODEL,
      persona: String(persona || "A friendly, curious participant.").slice(0, 1000),
      x: 120 + Math.random() * 280,
      y: 160 + Math.random() * 280,
      color: COLORS[Object.keys(this.state.seats).length % COLORS.length],
      online: true,
    };
    this.state.seats[seat.id] = seat;
    await this.save();
    this.broadcastSnapshot();
  }

  async onRemoveSeat(seatId) {
    const seat = this.state.seats[seatId];
    if (!seat || seat.kind !== "ai") return; // only AI seats can be removed
    delete this.state.seats[seatId];
    for (const t of Object.values(this.state.threads)) {
      if (Array.isArray(t.members)) t.members = t.members.filter((m) => m !== seatId);
    }
    await this.save();
    this.broadcastSnapshot();
  }

  // A side conversation: the "speech bubble" between specific seats.
  // Reuses an existing thread with exactly the same members.
  async onOpenThread(bySeat, withSeats, title) {
    const members = [...new Set([bySeat, ...(withSeats || [])])]
      .filter((id) => this.state.seats[id]).sort();
    if (members.length < 2) return;
    let thread = Object.values(this.state.threads)
      .find((t) => Array.isArray(t.members) && t.members.join() === members.join());
    if (!thread) {
      thread = { id: uid(), title: title || "", members, messages: [] };
      this.state.threads[thread.id] = thread;
      await this.save();
    }
    this.broadcastSnapshot();
    this.sendToSeat(bySeat, { type: "thread_opened", threadId: thread.id });
  }

  async onMove(seatId, x, y) {
    const seat = this.state.seats[seatId];
    seat.x = clamp(x, 0, 2000); seat.y = clamp(y, 0, 2000);
    await this.save();
    this.broadcast({ type: "seat_moved", seatId, x: seat.x, y: seat.y });
  }

  async onCanvas(seatId, op) {
    if (!op) return;
    this.applyCanvasOp(seatId, op);
    await this.save();
    this.broadcast({ type: "canvas", canvas: this.state.canvas });
  }

  applyCanvasOp(seatId, op) {
    if (op.kind === "add") {
      const obj = {
        id: uid(), by: seatId,
        shape: ["rect", "circle", "text", "line"].includes(op.shape) ? op.shape : "rect",
        x: clamp(op.x, 0, 2000), y: clamp(op.y, 0, 2000),
        w: clamp(op.w ?? 60, 1, 800), h: clamp(op.h ?? 60, 1, 800),
        r: clamp(op.r ?? 30, 1, 400),
        x2: clamp(op.x2 ?? op.x + 80, 0, 2000), y2: clamp(op.y2 ?? op.y, 0, 2000),
        color: /^#[0-9a-f]{3,8}$/i.test(op.color || "") ? op.color : "#888888",
        text: String(op.text || "").slice(0, 200),
      };
      this.state.canvas.push(obj);
      if (this.state.canvas.length > 500) this.state.canvas.shift();
    } else if (op.kind === "move") {
      const o = this.state.canvas.find((c) => c.id === op.id);
      if (o) { o.x = clamp(op.x, 0, 2000); o.y = clamp(op.y, 0, 2000); }
    } else if (op.kind === "delete") {
      this.state.canvas = this.state.canvas.filter((c) => c.id !== op.id);
    } else if (op.kind === "clear") {
      this.state.canvas = [];
    }
  }

  // ---------- messages + AI turns ----------

  async onSay(seatId, threadId, text, chainDepth) {
    const thread = this.state.threads[threadId];
    if (!thread || !this.canSee(seatId, thread)) return;
    text = String(text || "").trim().slice(0, 4000);
    if (!text) return;

    const message = { id: uid(), threadId, from: seatId, text, at: Date.now() };
    thread.messages.push(message);
    if (thread.messages.length > MAX_MESSAGES_PER_THREAD) thread.messages.shift();
    await this.save();
    this.broadcastToThread(thread, { type: "message", message });
    this.broadcastActivity(thread, seatId);

    // Decide which AI seats should answer.
    const speaker = this.state.seats[seatId];
    if (speaker.kind === "ai" && chainDepth >= MAX_AI_CHAIN) return;
    const responders = this.pickResponders(thread, seatId, text);
    for (const ai of responders) {
      // Not awaited one-by-one on purpose: AIs in a thread answer in parallel.
      this.ctx.waitUntil(this.runAITurn(ai, thread, speaker.kind === "ai" ? chainDepth + 1 : 0));
    }
  }

  // Rules: in a side thread with exactly one AI and one other seat, the AI always
  // answers. Otherwise an AI answers only when @mentioned by name.
  pickResponders(thread, fromSeat, text) {
    const members = this.membersOf(thread).filter((s) => s.kind === "ai" && s.id !== fromSeat);
    const lower = text.toLowerCase();
    const mentioned = members.filter((s) => lower.includes("@" + s.name.toLowerCase()));
    if (mentioned.length) return mentioned;
    if (Array.isArray(thread.members) && thread.members.length === 2 && members.length === 1) return members;
    return [];
  }

  async runAITurn(ai, thread, chainDepth) {
    if (!this.allowAICall()) {
      return this.postSystem(thread, `${ai.name} is resting (room AI rate limit).`);
    }
    this.broadcastToThread(thread, { type: "typing", seatId: ai.id, threadId: thread.id });

    let reply;
    try {
      reply = await this.callModel(ai, thread);
    } catch (err) {
      return this.postSystem(thread, `${ai.name} couldn't answer: ${String(err.message || err).slice(0, 200)}`);
    }

    // Apply actions: move avatar, draw on canvas, open a side conversation.
    let changed = false;
    if (reply.move && Number.isFinite(reply.move.x) && Number.isFinite(reply.move.y)) {
      ai.x = clamp(reply.move.x, 0, 2000); ai.y = clamp(reply.move.y, 0, 2000);
      this.broadcast({ type: "seat_moved", seatId: ai.id, x: ai.x, y: ai.y });
      changed = true;
    }
    for (const op of (reply.canvas || []).slice(0, 10)) {
      this.applyCanvasOp(ai.id, op);
      changed = true;
    }
    if (changed) {
      await this.save();
      this.broadcast({ type: "canvas", canvas: this.state.canvas });
    }
    if (reply.whisper && reply.whisper.to && reply.whisper.text) {
      const target = Object.values(this.state.seats)
        .find((s) => s.name.toLowerCase() === String(reply.whisper.to).toLowerCase());
      if (target && target.id !== ai.id) {
        await this.onOpenThread(ai.id, [target.id]);
        const side = Object.values(this.state.threads).find((t) =>
          Array.isArray(t.members) && t.members.join() === [ai.id, target.id].sort().join());
        if (side) await this.onSay(ai.id, side.id, reply.whisper.text, chainDepth);
      }
    }
    if (reply.say) await this.onSay(ai.id, thread.id, reply.say, chainDepth);
  }

  async callModel(ai, thread) {
    if (!this.env.OPENROUTER_API_KEY) throw new Error("OPENROUTER_API_KEY secret is not set");
    const seats = this.state.seats;
    const others = Object.values(seats).filter((s) => s.id !== ai.id)
      .map((s) => `${s.name} (${s.kind}) at (${Math.round(s.x)},${Math.round(s.y)})`).join("; ");
    const where = thread.id === "main"
      ? "the main room, where everyone can read"
      : `a private side conversation with ${this.membersOf(thread).filter((s) => s.id !== ai.id).map((s) => s.name).join(", ")}`;
    const canvasSummary = this.state.canvas.slice(-30)
      .map((c) => `${c.id}:${c.shape}@(${c.x},${c.y})${c.text ? ` "${c.text}"` : ""}`).join(" ") || "empty";

    const system = [
      `You are ${ai.name}, an avatar in a shared canvas room. Persona: ${ai.persona}`,
      `You are speaking in ${where}.`,
      `Others present: ${others || "nobody"}.`,
      `Your avatar is at (${Math.round(ai.x)},${Math.round(ai.y)}). Canvas is 2000x2000. Canvas objects: ${canvasSummary}`,
      `Reply ONLY with a JSON object, no prose around it:`,
      `{"say": "your message (keep it short)",`,
      ` "move": {"x": number, "y": number} (optional, walk your avatar),`,
      ` "canvas": [ {"kind":"add","shape":"rect|circle|text|line","x":0,"y":0,"w":60,"h":60,"r":30,"x2":0,"y2":0,"color":"#hex","text":""} | {"kind":"move","id":"...","x":0,"y":0} | {"kind":"delete","id":"..."} ] (optional),`,
      ` "whisper": {"to": "name", "text": "..."} (optional, start or continue a private side conversation)}`,
    ].join("\n");

    const history = thread.messages.slice(-MAX_CONTEXT_MESSAGES).map((m) => {
      const who = seats[m.from]?.name || "system";
      return m.from === ai.id
        ? { role: "assistant", content: JSON.stringify({ say: m.text }) }
        : { role: "user", content: `${who}: ${m.text}` };
    });

    const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${this.env.OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
        "X-Title": "group-canvas",
      },
      body: JSON.stringify({
        model: ai.model,
        messages: [{ role: "system", content: system }, ...history],
        max_tokens: 600,
        temperature: 0.8,
      }),
    });
    if (!res.ok) throw new Error(`OpenRouter ${res.status}: ${(await res.text()).slice(0, 150)}`);
    const data = await res.json();
    return parseReply(data.choices?.[0]?.message?.content || "");
  }

  allowAICall() {
    const now = Date.now();
    this.aiCalls = this.aiCalls.filter((t) => now - t < 60_000);
    if (this.aiCalls.length >= MAX_AI_CALLS_PER_MINUTE) return false;
    this.aiCalls.push(now);
    return true;
  }

  async postSystem(thread, text) {
    const message = { id: uid(), threadId: thread.id, from: "system", text, at: Date.now() };
    thread.messages.push(message);
    await this.save();
    this.broadcastToThread(thread, { type: "message", message });
  }

  // ---------- visibility + broadcast ----------

  membersOf(thread) {
    return thread.members === "all"
      ? Object.values(this.state.seats)
      : thread.members.map((id) => this.state.seats[id]).filter(Boolean);
  }

  canSee(seatId, thread) {
    return thread.members === "all" || thread.members.includes(seatId);
  }

  // Everyone sees that a side conversation exists and who is in it
  // (drawn as a bubble/link on the canvas); only members get the text.
  snapshotFor(seatId) {
    const threads = Object.values(this.state.threads).map((t) => ({
      id: t.id, title: t.title, members: t.members,
      lastAt: t.messages.at(-1)?.at || 0,
      messages: this.canSee(seatId, t) ? t.messages.slice(-50) : [],
      private: !this.canSee(seatId, t),
    }));
    const seats = Object.values(this.state.seats).map(({ persona, ...pub }) => pub);
    return { type: "snapshot", seats, threads, canvas: this.state.canvas };
  }

  broadcastActivity(thread, seatId) {
    this.broadcast({ type: "activity", threadId: thread.id, seatId, members: thread.members, at: Date.now() });
  }

  broadcastSnapshot() {
    for (const ws of this.ctx.getWebSockets()) {
      const { seatId } = ws.deserializeAttachment() || {};
      if (seatId) this.send(ws, this.snapshotFor(seatId));
    }
  }

  broadcastToThread(thread, payload) {
    for (const ws of this.ctx.getWebSockets()) {
      const { seatId } = ws.deserializeAttachment() || {};
      if (seatId && this.canSee(seatId, thread)) this.send(ws, payload);
    }
  }

  broadcast(payload) {
    for (const ws of this.ctx.getWebSockets()) this.send(ws, payload);
  }

  sendToSeat(seatId, payload) {
    for (const ws of this.ctx.getWebSockets()) {
      if ((ws.deserializeAttachment() || {}).seatId === seatId) this.send(ws, payload);
    }
  }

  send(ws, payload) {
    try { ws.send(JSON.stringify(payload)); } catch { /* socket closed */ }
  }
}

function clamp(v, lo, hi) {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : lo;
}

// Models don't always return clean JSON; pull out the first {...} block,
// and fall back to treating the whole reply as speech.
function parseReply(text) {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start !== -1 && end > start) {
    try {
      const obj = JSON.parse(text.slice(start, end + 1));
      if (obj && typeof obj === "object") return obj;
    } catch { /* fall through */ }
  }
  return { say: text.trim().slice(0, 2000) };
}
