// Entry point: routes /room/<name>/ws to that room's Durable Object,
// everything else to the static client in /public.
export { Room } from "./room.js";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const match = url.pathname.match(/^\/room\/([\w-]{1,64})\/ws$/);
    if (match) {
      const stub = env.ROOMS.get(env.ROOMS.idFromName(match[1]));
      return stub.fetch(request);
    }
    return env.ASSETS.fetch(request);
  },
};
