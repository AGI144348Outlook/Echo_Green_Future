# Inspection handoff

This is an isolated boilerplate project supplied at Timothy's request. Review it before integration or deployment; do not change an Echo repository as part of inspection.

## Architectural intent

- An AI uses MCP tools or the command/query API to construct and operate widgets.
- A browser renders the same persistent workspace and can also edit it.
- A shared personality profile is separate from an avatar widget.
- Pyodide runs in an explicitly enabled browser worker, through a lease-based job queue.
- GraphQL is an optional real adapter over the same service.
- General-purpose companionship, games and demonstrations are the intended use; no Echo glyph semantics are implied.

## Actual reuse

`canvas_app/service.py` imports `Command` and `Rejected` from the unchanged vendored `echo_reference/engine.py`. It does not use that earlier engine's synthetic semantic reducer, policy, fixture glyph meanings or in-memory storage. The new service adds persistent transactions, access checks and this project's operations.

## Inspect especially

1. Authorization and membership checks, including removal and owner-only profile/access updates.
2. Atomic state/event/receipt commits and idempotency under retries/concurrent edits.
3. Browser/MCP/GraphQL consistency, input contracts and error categories.
4. Python leases, cancellation, worker restarts, timeouts and stale completion behavior.
5. The trust boundary around runtime-reported results: this is not cryptographic execution attestation.
6. Shared profile versus visual avatar lifecycle and any unintended private-data exposure.
7. DOM rendering and the limits of the bounded renderer registry.
8. The optional GraphQL dependency and a real assistant host's MCP compatibility.
9. Actual browser Pyodide execution, direct manipulation and accessibility.

Report defects with file/line references and reproduction steps. Distinguish implemented paths from explicitly untested integrations. Do not reinterpret the artifact as demonstrated general intelligence or silently fill missing semantics.

Before a production version, propose structured schema migrations, a proper invitation/authentication flow, deployment/TLS strategy, resource budgets, execution isolation, and user-friendly conflict recovery. Keep these improvements separate from the local prototype's existing guarantees.
