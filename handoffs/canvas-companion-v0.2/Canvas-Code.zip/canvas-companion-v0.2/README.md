# Canvas Companion v0.2 — local review boilerplate

A standalone starting project for a general AI to share a widget Canvas with a person. Includes persistent widgets, a shared personality profile, a small avatar in a window, a Python-job queue, and a command/query interface exposed through HTTP and MCP. GraphQL execution is an optional dependency.

**This is separate from Echo.** It contains no approved glyph operators, Algorithm 000/001 implementation, embedded language model, or imported private bot memory. The avatar's default `ג` and frame decoration `ם` are presentation choices, not executable semantics.


## v0.2 review revision

Read [the response to Claude](docs/RESPONSE-TO-CLAUDE.md) and [validation record](VALIDATION.md). This revision adds explicit widget schemas, authenticated WebSocket events, normalized bounded job bodies, stable retry identity and job leases independent of unrelated workspace edits. OAuth and public/mobile connector setup remain unfinished. Group Canvas is reviewed separately; it has not been merged.

Back up existing databases before opening them: v0.2 automatically migrates embedded jobs and applies retention/redaction. Snapshots contain job summaries; fetch job details separately. Old job bodies can expire; receipts and tombstones remain. Preserve a separate backup if complete execution history is required.

## Reuse of the earlier interfacing tool

Yes: `canvas_app/service.py` imports the actual `Command` envelope and `Rejected` primitive from the vendored original `echo_reference/engine.py`. This is the same explicit-command/query pattern used in the earlier package. The old synthetic reducer and `ReviewPolicy` are not used. SQLite transactions and authenticated principal/workspace checks replace its in-memory review-only boundary.

- Browser actions: `/api/workspaces/.../commands`
- Assistant tools: `/mcp`
- Optional real GraphQL: `/graphql`

All three write paths delegate to `Service.submit`. Only SQLite state is authoritative. A schema proposal is not substituted for a running service.

## Quick start

Python 3.10+; install the server requirements in a virtual environment:

```sh
python -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
```

Configure a local token for each principal. The example strings below are deliberately disposable examples; choose your own values. Keep real tokens out of source control and command arguments.

```sh
export CANVAS_TOKENS='{"replace-this-example-alice-token":"alice","replace-this-example-recipient-token":"recipient"}'
python -m uvicorn canvas_app.server:create_app --factory --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000`, choose **Connect**, enter the matching Alice token, and create a workspace. Add a note, avatar, Python widget or sample quiz. The quiz is an actual small interactive renderer, but its default content is an explicitly labeled authored sample, not AI-generated activity.

The UI can drag, resize, collapse, edit and delete widgets. Table, chart and drawing descriptors can be created through the API/MCP or the advanced JSON editor after creation. The first renderer set is bounded; custom renderer registration is an extension task, not arbitrary privileged HTML/JavaScript execution.

## Give a companion a shared personality

Edit its chosen name, manner, greeting, example phrases and selected shared facts. Add an avatar widget, then change its glyph/color/message as desired. Closing the avatar removes that view record while retaining the profile. Adding another avatar presents the same profile again.

To share with the configured recipient, the owner selects **Share with a principal**, enters `recipient` and grants `viewer` or `editor`. The recipient connects with their own configured token. Editors can work on widgets and jobs; only the owner edits the personality or membership. The prototype operator must provision principal/token mappings; there is no self-service invitation, email, OAuth or public user-registration flow.

A connected assistant reads `workspace_inspect` and can use the profile to guide its responses and widgets. The profile is shared instructions/data, not a transferred original model instance. No chatbot or provider API is embedded in the page.

## Python through Pyodide

Enable **Python in this tab**. The default worker downloads Pyodide 0.26.4 from jsDelivr. This requires internet access and is not offline-bundled. Alternatively place a compatible complete runtime under `web/pyodide/` and open `/?runtime=local`; runtime distribution/licensing and offline packaging remain your responsibility.

Add a Python widget and choose **Run in this tab**, or use `python_run` through MCP. Assign a JSON-compatible value to `result`:

```python
result = {
    "columns": ["n", "n squared"],
    "rows": [[n, n*n] for n in range(1, 11)],
}
print("Ten squares, computed in Python.")
```

Jobs remain queued until an enabled browser claims them. Successful recorded table-shaped results expose a **Make table** action. Stdout/stderr and result data are recorded; arbitrary Python objects and live heaps are not persisted. Each job gets fresh globals. Runtime package imports outside the included standard library may require additional installation not provided here.

The worker has a 15-second execution timer and a 40-second server lease. Closing a tab stops its execution. Expired running jobs can be claimed again: computation is not exactly-once, but stale completions are rejected. Cancellation or disabling the runner terminates the current worker. A new worker loses runtime state.

Python in a browser worker is **not a hardened hostile-code sandbox**. It can access the worker's JavaScript environment and may make network calls. The server token is not sent to it. Use this local prototype with trusted participants and code; production execution isolation is a separate task.

## HTTP command example

Read the workspace first to obtain its ID and current version. Python/client examples are in `examples.py`; no LLM API key is required for those clients.

```json
{
  "id": "unique-command-id",
  "expectedVersion": 0,
  "operation": "widget.create",
  "payload": {
    "id": "companion-avatar",
    "kind": "avatar",
    "title": "A little companion",
    "spec": {"glyph": "ג", "color": "#49664e", "message": "Shall we make something together?"},
    "layout": {"x": 40, "y": 40, "width": 320, "height": 300, "collapsed": false}
  }
}
```

Send to `POST /api/workspaces/{workspaceId}/commands` with the configured bearer token. `actor` cannot be injected through the body. Every command requires the expected workspace version; widget updates/deletes also require `expectedWidgetVersion`. Rejected requests do not commit partial state/history. Repeating the same successful command ID/content returns its receipt; changing its content causes a collision error.

## MCP connection

The running server exposes stateless JSON-RPC initialization, discovery and tool calls at `/mcp`. Discovery contains no private workspace records; data-bearing calls require the bearer token.

For assistant hosts supporting local stdio MCP, launch `mcp_stdio.py` with `CANVAS_ACCESS_TOKEN` in that host's environment and optionally `CANVAS_URL`. See `docs/CONNECTIONS.md`. Remote hosts need a reachable HTTPS deployment and a compatible authentication integration; a localhost address cannot be reached by an arbitrary cloud assistant. No public deployment or OAuth connection is supplied by this package.

Supported tools: `workspace_list`, `workspace_create`, `workspace_inspect`, `widget_create`, `widget_update`, `widget_delete`, `persona_update`, `workspace_share`, `python_run`, `python_job_get`, `python_cancel`.

## Optional GraphQL

```sh
python -m pip install -r requirements-graphql.txt
```

Restart the server. `POST /graphql` accepts a normal GraphQL query/document and variables, authenticated with the same token. Without the extra, it returns HTTP 501 explicitly. The schema is implemented in `canvas_app/graphql_api.py`; a serialized SDL is in `docs/schema.graphql`.

```graphql
query { workspaces { id title version } }
```

The `command` mutation accepts a typed command envelope with a JSON payload; the service performs operation-specific validation. This is a small working adapter when its dependency is present, not a comprehensive domain GraphQL schema.

## Tests and boundaries

```sh
python -m pip install -r requirements-test.txt
python -m unittest discover -s tests -v
```

See `VALIDATION.md` for what was actually exercised. HTTP/MCP transport tests use an in-process test client; an actual external assistant connection and browser Pyodide execution require separate verification.

Persistent SQLite data defaults to ignored `data/workspaces.sqlite3`; set `CANVAS_DB` to change it. Workspace export is available in the UI. Import/migrations, undo, presence, real-time push, full accessibility testing, custom widget renderers, end-to-end runtime attestations and production token management are not implemented.

The synchronous SQLite service is deliberately small. It stores one JSON state per workspace and retains all job code, selected personality data and accepted command history. It is a starting point for review, not a scaled multiuser deployment. The HTTP server does not provide request-streaming limits or a complete abuse-control layer; keep its default loopback binding until a proper deployment is reviewed.
