"""Small invalidation broker. Durable events remain the source of truth.

Same-process commits wake clients immediately. A 10s durable-cursor recheck also
catches commits from another process. This is not Durable Object coordination.
"""
import asyncio


class Broker:
    def __init__(self):
        self.generation=0
        self.changed=asyncio.Event()

    def notify(self):
        self.generation+=1
        self.changed.set()

    async def wait(self,generation):
        if self.generation!=generation:return
        self.changed.clear()
        if self.generation!=generation:return
        try:await asyncio.wait_for(self.changed.wait(),10)
        except asyncio.TimeoutError:pass
