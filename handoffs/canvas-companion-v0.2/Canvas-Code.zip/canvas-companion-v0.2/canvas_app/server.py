"""ASGI application. Default startup requires explicitly configured tokens."""
from __future__ import annotations

import hmac
import importlib.util
import json
import os
import asyncio
from pathlib import Path
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from .service import Conflict, Forbidden, Rejected, Service
from .mcp import call_tool, tool_list
from .push import Broker
from .schemas import LAYOUT, SPECS


def create_app(database=None, tokens=None):
    if tokens is None:
        tokens = json.loads(os.environ.get("CANVAS_TOKENS", "{}"))
    if not isinstance(tokens, dict) or not tokens or not all(
        isinstance(k, str) and len(k) >= 16 and isinstance(v, str) and v for k, v in tokens.items()
    ):
        raise RuntimeError('Set CANVAS_TOKENS to a JSON object mapping access tokens (16+ characters) to principal names.')
    service = Service(database or os.environ.get("CANVAS_DB", "./data/workspaces.sqlite3"))
    app = FastAPI(title="Canvas Companion reference", docs_url=None, redoc_url=None)
    app.state.service = service
    broker=Broker()
    service.on_commit=broker.notify
    graphql_ready = importlib.util.find_spec("graphql") is not None

    def principal(header):
        if not header.startswith("Bearer "):
            raise HTTPException(401, "A bearer token is required",headers={"WWW-Authenticate":'Bearer realm="canvas-companion"'})
        supplied = header[7:]
        for token, principal in tokens.items():
            if hmac.compare_digest(supplied.encode(), token.encode()):
                return principal
        raise HTTPException(401, "Invalid access token",headers={"WWW-Authenticate":'Bearer realm="canvas-companion", error="invalid_token"'})

    def actor(request):
        return principal(request.headers.get("authorization", ""))

    async def body(request):
        raw = await request.body()
        if len(raw) > 500000:
            raise HTTPException(413, "Request too large")
        try:
            value = json.loads(raw, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
            if not isinstance(value, dict):
                raise ValueError("Object required")
            return value
        except (ValueError, TypeError):
            raise HTTPException(400, "A finite JSON object is required")

    @app.exception_handler(Rejected)
    async def rejected(request, exc):
        status = 403 if isinstance(exc, Forbidden) else 409 if isinstance(exc, Conflict) else 400
        return JSONResponse({"status": "rejected", "reason": str(exc)}, status_code=status)

    @app.get("/api/info")
    async def info():
        return {"name": "Canvas Companion", "graphql": graphql_ready,
                "mcp": "/mcp", "oauth":False,"version":"0.2.0",
                "runtime": "Browser Pyodide; explicit runner enable required"}

    @app.get("/api/widget-schemas")
    async def widget_schemas():
        return {"layout":LAYOUT,"specs":SPECS,"encodedSpecByteLimit":200000}

    @app.get("/api/workspaces")
    async def workspaces(request: Request):
        return service.list(actor(request))

    @app.post("/api/workspaces")
    async def create(request: Request):
        principal = actor(request)
        b = await body(request)
        return service.create(principal, b.get("title"))

    @app.get("/api/workspaces/{workspace}")
    async def snapshot(workspace: str, request: Request):
        return service.get(actor(request), workspace)

    @app.get("/api/workspaces/{workspace}/events")
    async def events(workspace: str, request: Request, after: int = 0,detail: bool=False):
        return service.changes(actor(request), workspace, after,detail)

    @app.get("/api/workspaces/{workspace}/jobs/{job}")
    async def job_detail(workspace: str,job: str,request: Request):
        return service.job(actor(request),workspace,job)

    @app.websocket("/api/workspaces/{workspace}/ws")
    async def workspace_socket(websocket: WebSocket,workspace: str):
        # Browser tokens go in the first frame, not URL parameters or access logs.
        origin=websocket.headers.get("origin")
        if origin and urlparse(origin).netloc!=websocket.headers.get("host"):
            await websocket.close(code=1008);return
        await websocket.accept()
        try:
            auth=await asyncio.wait_for(websocket.receive_json(),5)
            if not isinstance(auth,dict):raise ValueError("Authentication frame required")
            who=principal("Bearer "+str(auth.get("token","")))
            cursor=auth.get("after",0)
            if type(cursor) is not int or cursor<0:raise ValueError("Invalid cursor")
            service.get(who,workspace)
            await websocket.send_json({"type":"ready","after":cursor})
            while True:
                generation=broker.generation
                # Reauthorize every page/wake; revoked members receive no later events.
                events=service.changes(who,workspace,cursor)
                for event in events:
                    await websocket.send_json({"type":"event","event":event})
                    cursor=event["cursor"]
                if len(events)==100:continue
                await websocket.send_json({"type":"heartbeat","cursor":cursor})
                await broker.wait(generation)
        except (HTTPException,Rejected,ValueError,TypeError,asyncio.TimeoutError):
            await websocket.close(code=1008)
        except WebSocketDisconnect:
            pass

    @app.post("/api/workspaces/{workspace}/commands")
    async def command(workspace: str, request: Request):
        principal = actor(request)
        return service.submit(principal, workspace, await body(request))

    @app.post("/graphql")
    async def graphql(request: Request):
        principal = actor(request)
        if not graphql_ready:
            raise HTTPException(501, "GraphQL extra is not installed; use the command/query API or MCP")
        from .graphql_api import execute
        b = await body(request)
        if not isinstance(b.get("query"), str):
            raise HTTPException(400, "GraphQL query string required")
        return execute(service, principal, b)

    @app.get("/mcp")
    async def mcp_stream_unavailable():
        return Response(status_code=405,headers={"Allow":"POST"})

    @app.post("/mcp")
    async def mcp(request: Request):
        b = await body(request)
        rid, method = b.get("id"), b.get("method")
        if b.get("jsonrpc") != "2.0" or not isinstance(method, str):
            return {"jsonrpc": "2.0", "id": rid, "error": {"code": -32600, "message": "Invalid JSON-RPC request"}}
        if "id" not in b:
            return Response(status_code=202)
        params=b.get("params",{})
        if not isinstance(params,dict):
            return {"jsonrpc":"2.0","id":rid,"error":{"code":-32602,"message":"params must be an object"}}
        try:
            if method == "initialize":
                requested = params.get("protocolVersion")
                version = requested if requested in {"2024-11-05", "2025-03-26", "2025-06-18"} else "2025-03-26"
                result = {"protocolVersion": version, "capabilities": {"tools": {"listChanged": False}},
                          "serverInfo": {"name": "canvas-companion-reference", "version": "0.2.0"}}
            elif method == "ping":
                result = {}
            elif method == "tools/list":
                result = {"tools": tool_list()}
            elif method == "tools/call":
                principal = actor(request)
                try:
                    result = call_tool(service, principal, params["name"], params.get("arguments", {}))
                except (Rejected, KeyError, TypeError) as exc:
                    result = {"content": [{"type": "text", "text": str(exc)}], "isError": True}
            else:
                return {"jsonrpc": "2.0", "id": rid, "error": {"code": -32601, "message": "Method not found"}}
            return {"jsonrpc": "2.0", "id": rid, "result": result}
        except (KeyError, TypeError, ValueError) as exc:
            return {"jsonrpc": "2.0", "id": rid, "error": {"code": -32602, "message": str(exc)}}

    web = Path(__file__).resolve().parent.parent / "web"
    app.mount("/", StaticFiles(directory=web, html=True), name="web")
    return app
