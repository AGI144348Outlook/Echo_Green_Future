"""Local-first Canvas + companion + agent API reference project."""
