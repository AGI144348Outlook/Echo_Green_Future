"""Optional real GraphQL execution. Requires the optional graphql-core package."""

SDL = """
scalar JSON
type WorkspaceSummary { id: ID!, title: String!, version: Int! }
type Query {
  workspaces: [WorkspaceSummary!]!
  workspace(id: ID!): JSON!
  changes(workspaceId: ID!, after: Int = 0): JSON!
}
input WorkspaceCommand {
  id: ID!
  expectedVersion: Int!
  operation: String!
  payload: JSON!
}
type Mutation {
  createWorkspace(title: String!): JSON!
  command(workspaceId: ID!, input: WorkspaceCommand!): JSON!
}
"""


def execute(service, actor, body):
    from graphql import build_schema, graphql_sync
    from graphql.utilities import value_from_ast_untyped

    schema = build_schema(SDL)
    scalar = schema.type_map["JSON"]
    scalar.serialize = lambda value: value
    scalar.parse_value = lambda value: value
    scalar.parse_literal = lambda node, variables=None: value_from_ast_untyped(node, variables)
    q = schema.type_map["Query"].fields
    q["workspaces"].resolve = lambda root, info: service.list(actor)
    q["workspace"].resolve = lambda root, info, id: service.get(actor, id)
    q["changes"].resolve = lambda root, info, workspaceId, after=0: service.changes(actor, workspaceId, after)
    m = schema.type_map["Mutation"].fields
    m["createWorkspace"].resolve = lambda root, info, title: service.create(actor, title)
    m["command"].resolve = lambda root, info, workspaceId, input: service.submit(actor, workspaceId, input)
    result = graphql_sync(schema, body["query"], variable_values=body.get("variables"),
                          operation_name=body.get("operationName"))
    response = {"data": result.data}
    if result.errors:
        response["errors"] = [{"message": str(e.message)} for e in result.errors]
    return response
