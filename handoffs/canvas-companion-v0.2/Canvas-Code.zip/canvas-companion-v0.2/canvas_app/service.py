"""Persistent command/query service shared by browser, MCP and optional GraphQL.

The command envelope and rejection primitive are reused directly from the earlier
reference scaffold. Its synthetic Echo reducer and ReviewPolicy are NOT used.
"""
from __future__ import annotations

from copy import deepcopy
from hashlib import sha256
import json
import logging
from pathlib import Path
import sqlite3
import time
from uuid import uuid4

from vendor.echo_reference.engine import Command, Rejected

CONTRACT = "canvas-companion/v1"
KINDS = {"note", "avatar", "python", "table", "chart", "drawing", "quiz"}
OPS = {
    "widget.create", "widget.update", "widget.delete", "persona.update",
    "workspace.share", "python.queue", "python.claim", "python.complete",
    "python.cancel",
}


class Forbidden(Rejected):
    pass


class Conflict(Rejected):
    pass


class ClosingConnection(sqlite3.Connection):
    def __exit__(self, *args):
        try:
            return super().__exit__(*args)
        finally:
            self.close()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def require(condition, message):
    if not condition:
        raise Rejected(message)


def text(value, name, limit=2000):
    require(isinstance(value, str) and len(value) <= limit, f"Invalid {name}")
    return value


def layout(value):
    require(isinstance(value, dict), "Layout must be an object")
    require(set(value) == {"x", "y", "width", "height", "collapsed"},
            "Layout requires x, y, width, height and collapsed")
    for key in ("x", "y", "width", "height"):
        require(type(value[key]) in (int, float), f"Invalid {key}")
        require(-100000 <= value[key] <= 100000, f"{key} outside canvas bounds")
    require(value["width"] >= 180 and value["height"] >= 100, "Widget too small")
    require(type(value["collapsed"]) is bool, "collapsed must be Boolean")
    return deepcopy(value)


def widget_spec(kind, spec):
    require(kind in KINDS and isinstance(spec, dict), "Invalid widget kind/spec")
    require(len(canonical(spec).encode()) <= 200000, "Widget specification too large")
    if kind == "note":
        require(set(spec) <= {"text"}, "Unknown note field")
        text(spec.get("text", ""), "note text", 30000)
    elif kind == "avatar":
        require(set(spec) <= {"glyph", "color", "message"}, "Unknown avatar field")
        text(spec.get("glyph", "ג"), "avatar glyph", 12)
        color = spec.get("color", "#49664e")
        require(isinstance(color, str) and len(color) == 7 and color[0] == "#"
                and all(c in "0123456789abcdefABCDEF" for c in color[1:]), "Invalid color")
        text(spec.get("message", ""), "avatar message", 3000)
    elif kind == "python":
        require(set(spec) <= {"code"}, "Unknown Python field")
        text(spec.get("code", ""), "Python code", 20000)
    elif kind == "table":
        require(set(spec) <= {"columns", "rows", "jobId"}, "Unknown table field")
        columns, rows = spec.get("columns", []), spec.get("rows", [])
        require(isinstance(columns, list) and len(columns) <= 30
                and all(isinstance(c, str) for c in columns), "Invalid columns")
        require(isinstance(rows, list) and len(rows) <= 500
                and all(isinstance(r, list) and len(r) == len(columns) for r in rows),
                "Rows must match column count")
    elif kind == "chart":
        require(set(spec) <= {"labels", "values"}, "Unknown chart field")
        labels, values = spec.get("labels", []), spec.get("values", [])
        require(isinstance(labels, list) and isinstance(values, list)
                and len(labels) == len(values) <= 100
                and all(isinstance(v, str) for v in labels)
                and all(type(v) in (int, float) for v in values), "Invalid chart series")
    elif kind == "drawing":
        require(set(spec) <= {"shapes"}, "Unknown drawing field")
        shapes = spec.get("shapes", [])
        require(isinstance(shapes, list) and len(shapes) <= 100, "Invalid shapes")
        for shape in shapes:
            require(isinstance(shape, dict)
                    and set(shape) <= {"type", "x", "y", "size", "label"}
                    and shape.get("type") in {"circle", "square"}, "Invalid shape")
            for field in ("x", "y", "size"):
                v = shape.get(field, 20)
                require(type(v) in (int, float) and 0 <= v <= 10000, "Invalid shape geometry")
            text(shape.get("label", ""), "shape label", 100)
    elif kind == "quiz":
        require(set(spec) <= {"question", "options", "answerIndex", "explanation"}, "Unknown quiz field")
        text(spec.get("question", ""), "quiz question", 3000)
        options = spec.get("options", [])
        require(isinstance(options, list) and 2 <= len(options) <= 8
                and all(isinstance(v, str) and len(v) <= 300 for v in options), "Invalid quiz options")
        require(type(spec.get("answerIndex")) is int and 0 <= spec["answerIndex"] < len(options),
                "Invalid quiz answer")
        text(spec.get("explanation", ""), "quiz explanation", 3000)
    return deepcopy(spec)


class Service:
    def __init__(self, database, terminal_keep=50):
        self.database = str(database)
        require(type(terminal_keep) is int and terminal_keep >= 1, "Invalid retention count")
        self.terminal_keep = terminal_keep
        self.on_commit=None
        Path(self.database).parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript("""
              PRAGMA journal_mode=WAL;
              CREATE TABLE IF NOT EXISTS workspaces(
                id TEXT PRIMARY KEY, owner TEXT NOT NULL, state TEXT NOT NULL);
              CREATE TABLE IF NOT EXISTS events(
                seq INTEGER PRIMARY KEY AUTOINCREMENT, workspace TEXT NOT NULL,
                actor TEXT NOT NULL, command TEXT NOT NULL, outcome TEXT NOT NULL,
                version INTEGER NOT NULL);
              CREATE TABLE IF NOT EXISTS receipts(
                workspace TEXT NOT NULL, actor TEXT NOT NULL, id TEXT NOT NULL,
                fingerprint TEXT NOT NULL, response TEXT NOT NULL,
                PRIMARY KEY(workspace,actor,id));
              CREATE TABLE IF NOT EXISTS jobs(
                workspace TEXT NOT NULL, id TEXT NOT NULL, status TEXT NOT NULL,
                requester TEXT NOT NULL, runner TEXT, lease TEXT, expires REAL NOT NULL,
                created REAL NOT NULL, updated REAL NOT NULL, widget_id TEXT,
                code TEXT NOT NULL, bindings TEXT NOT NULL, output TEXT,
                PRIMARY KEY(workspace,id));
              CREATE INDEX IF NOT EXISTS jobs_status ON jobs(workspace,status,updated);
              CREATE TABLE IF NOT EXISTS job_tombstones(
                workspace TEXT NOT NULL,id TEXT NOT NULL,status TEXT NOT NULL,
                archived REAL NOT NULL, PRIMARY KEY(workspace,id));
              CREATE TABLE IF NOT EXISTS memberships(
                workspace TEXT NOT NULL,principal TEXT NOT NULL,role TEXT NOT NULL,
                PRIMARY KEY(workspace,principal));
              CREATE INDEX IF NOT EXISTS memberships_principal ON memberships(principal,workspace);
              PRAGMA user_version=2;
            """)
            # Explicit idempotent v1 -> v2 normalization. No caller data is activated.
            for row in db.execute("SELECT id,state FROM workspaces").fetchall():
                state = json.loads(row["state"])
                legacy_jobs = state.pop("jobs", None)
                for job in (legacy_jobs or {}).values():
                    if not db.execute("SELECT 1 FROM jobs WHERE workspace=? AND id=?", (row["id"],job["id"])).fetchone():
                        self._save_job(db,row["id"],job)
                if legacy_jobs is not None:
                    db.execute("UPDATE workspaces SET state=? WHERE id=?", (canonical(state),row["id"]))
                    for event in db.execute("SELECT seq,actor,command,outcome FROM events WHERE workspace=?",(row["id"],)).fetchall():
                        c=json.loads(event["command"])
                        intent={k:v for k,v in c.items() if k!="expected_version"}
                        db.execute("UPDATE receipts SET fingerprint=? WHERE workspace=? AND actor=? AND id=?",
                                   (sha256(canonical(intent).encode()).hexdigest(),row["id"],event["actor"],c["id"]))
                        if c["operation"].startswith("python."):
                            c["payload"]={"id":c["payload"]["id"]}
                            out=self._job_summary(json.loads(event["outcome"]))
                            db.execute("UPDATE events SET command=?,outcome=? WHERE seq=?",(canonical(c),canonical(out),event["seq"]))
                            receipt=db.execute("SELECT response FROM receipts WHERE workspace=? AND actor=? AND id=?",(row["id"],event["actor"],c["id"])).fetchone()
                            if receipt:
                                response=json.loads(receipt["response"]);response["outcome"]=self._job_summary(response["outcome"])
                                db.execute("UPDATE receipts SET response=? WHERE workspace=? AND actor=? AND id=?",(canonical(response),row["id"],event["actor"],c["id"]))
                    self._prune_jobs(db,row["id"])
                for principal,role in state["members"].items():
                    db.execute("INSERT OR REPLACE INTO memberships VALUES(?,?,?)",(row["id"],principal,role))

    def connect(self):
        db = sqlite3.connect(self.database, timeout=10, factory=ClosingConnection)
        db.row_factory = sqlite3.Row
        return db

    def _state(self, db, actor, workspace, write=False):
        row = db.execute("SELECT state FROM workspaces WHERE id=?", (workspace,)).fetchone()
        if row is None:
            raise Forbidden("Workspace is unavailable to this caller")
        state = json.loads(row["state"])
        role = "owner" if actor == state["owner"] else state["members"].get(actor)
        if role is None or (write and role == "viewer"):
            raise Forbidden("Workspace is unavailable to this caller")
        return state

    def create(self, actor, title):
        title = text(title, "workspace title", 120).strip()
        require(bool(title), "Title required")
        wid = str(uuid4())
        state = {"id": wid, "title": title, "owner": actor, "members": {}, "version": 0,
                 "widgets": {}, "persona": {
                     "name": "Companion", "tone": "Patient, curious and playful",
                     "greeting": "Shall we make something together?", "examples": [],
                     "sharedFacts": [],
                 }}
        with self.connect() as db:
            db.execute("INSERT INTO workspaces VALUES(?,?,?)", (wid, actor, canonical(state)))
        return {**state,"jobs":{},"eventCursor":0}

    def get(self, actor, workspace):
        with self.connect() as db:
            db.execute("BEGIN")
            state = self._state(db, actor, workspace)
            rows=db.execute("""SELECT id,status,requester,runner,expires,created,updated,widget_id,
                output IS NOT NULL AS has_output FROM jobs WHERE workspace=?
                ORDER BY CASE WHEN status IN ('queued','running') THEN 0 ELSE 1 END,updated DESC LIMIT 250""",(workspace,)).fetchall()
            state["jobs"]={r["id"]:{"id":r["id"],"status":r["status"],"requester":r["requester"],
                "runner":r["runner"],"expires":r["expires"],"created":r["created"],"updated":r["updated"],
                "widgetId":r["widget_id"],"hasOutput":bool(r["has_output"])} for r in rows}
            state["eventCursor"]=db.execute("SELECT COALESCE(MAX(seq),0) FROM events WHERE workspace=?",(workspace,)).fetchone()[0]
            return state

    def list(self, actor):
        with self.connect() as db:
            states = [json.loads(row["state"]) for row in db.execute("""SELECT state FROM workspaces w
                WHERE owner=? OR EXISTS(SELECT 1 FROM memberships m WHERE m.workspace=w.id AND m.principal=?)""",(actor,actor))]
        return [{"id": s["id"], "title": s["title"], "version": s["version"]}
                for s in states if actor == s["owner"] or actor in s["members"]]

    def changes(self, actor, workspace, after=0, detail=False):
        require(type(after) is int and after >= 0, "Invalid event cursor")
        with self.connect() as db:
            self._state(db, actor, workspace)
            rows = db.execute("SELECT * FROM events WHERE workspace=? AND seq>? ORDER BY seq LIMIT 100",
                              (workspace, after)).fetchall()
        return [{"cursor": r["seq"], "actor": r["actor"],
                 "operation":json.loads(r["command"])["operation"],"version": r["version"],
                 **({"command":json.loads(r["command"]),"outcome":json.loads(r["outcome"])} if detail else {})} for r in rows]

    def _save_job(self,db,workspace,job):
        db.execute("INSERT OR REPLACE INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(
            workspace,job["id"],job["status"],job["requester"],job.get("runner"),job.get("lease"),job.get("expires",0),
            job["created"],time.time(),job.get("widgetId"),job["code"],canonical(job["bindings"]),
            None if job.get("output") is None else canonical(job["output"])))

    def _load_job(self,db,workspace,jid):
        row=db.execute("SELECT * FROM jobs WHERE workspace=? AND id=?",(workspace,jid)).fetchone()
        if row:
            return {"id":row["id"],"status":row["status"],"requester":row["requester"],"runner":row["runner"],
                "lease":row["lease"],"expires":row["expires"],"created":row["created"],"updated":row["updated"],
                "widgetId":row["widget_id"],"code":row["code"],"bindings":json.loads(row["bindings"]),
                "output":None if row["output"] is None else json.loads(row["output"])}
        return None

    def job(self,actor,workspace,jid):
        with self.connect() as db:
            self._state(db,actor,workspace)
            job=self._load_job(db,workspace,jid)
            if job:return job
            row=db.execute("SELECT status,archived FROM job_tombstones WHERE workspace=? AND id=?",(workspace,jid)).fetchone()
            if row:return {"id":jid,"status":row["status"],"archived":True,"archivedAt":row["archived"],"output":None}
            raise Rejected("Job not found")

    def _prune_jobs(self,db,workspace):
        rows=db.execute("""SELECT id,status,updated FROM jobs WHERE workspace=?
            AND status IN ('succeeded','failed','cancelled') ORDER BY updated DESC,id DESC""",(workspace,)).fetchall()
        for i,row in enumerate(rows):
            if i < self.terminal_keep and row["updated"] >= time.time()-7*86400:continue
            db.execute("INSERT OR REPLACE INTO job_tombstones VALUES(?,?,?,?)",(workspace,row["id"],row["status"],time.time()))
            db.execute("DELETE FROM jobs WHERE workspace=? AND id=?",(workspace,row["id"]))

    @staticmethod
    def _job_summary(value):
        return {k:v for k,v in value.items() if k not in {"code","bindings","output"}}

    def submit(self, actor, workspace, body):
        require(isinstance(body, dict), "Command must be an object")
        require(set(body) <= {"id", "expectedVersion", "operation", "payload"},
                "Unknown command field; actor is supplied by authentication")
        request_id = text(body.get("id"), "command ID", 160)
        require(bool(request_id), "Command ID required")
        version = body.get("expectedVersion")
        require(type(version) is int and version >= 0, "Integer expectedVersion required")
        operation = body.get("operation")
        require(isinstance(operation, str) and operation in OPS, "Unknown operation")
        payload = body.get("payload", {})
        require(isinstance(payload, dict), "Payload must be an object")
        # Reuse the actual earlier envelope with an explicit new contract.
        c = Command(request_id, actor, workspace, version, operation,
                    deepcopy(payload), contract=CONTRACT).record()
        # Version is a concurrency precondition, not part of the operation's intent.
        intent={k:v for k,v in c.items() if k!="expected_version"}
        fingerprint = sha256(canonical(intent).encode()).hexdigest()
        db = self.connect()
        try:
            db.execute("BEGIN IMMEDIATE")
            state = self._state(db, actor, workspace, write=True)
            prior = db.execute("SELECT * FROM receipts WHERE workspace=? AND actor=? AND id=?",
                               (workspace, actor, request_id)).fetchone()
            if prior:
                require(prior["fingerprint"] == fingerprint, "Command ID collision")
                response=json.loads(prior["response"])
                if operation=="python.claim":
                    current=self._load_job(db,workspace,payload["id"])
                    if current and current["status"]=="running" and current["lease"]==response["outcome"].get("lease") and current["expires"]>=time.time():
                        response["outcome"]=current
                    else:response["outcome"]["claimExpired"]=True
                db.commit()
                return response
            if not operation.startswith("python.") and version != state["version"]:
                raise Conflict(f"Expected workspace version {version}; current version {state['version']}")
            state["jobs"]={}
            if operation.startswith("python."):
                require(isinstance(payload.get("id"),str) and bool(payload["id"]),"Job ID required")
                job=self._load_job(db,workspace,payload["id"])
                if operation=="python.queue":
                    require(job is None and not db.execute("SELECT 1 FROM job_tombstones WHERE workspace=? AND id=?",(workspace,payload["id"])).fetchone(),"Job ID already used")
                    require(db.execute("SELECT count(*) FROM jobs WHERE workspace=? AND status IN ('queued','running')",(workspace,)).fetchone()[0]<200,"Active job limit reached")
                else:
                    require(job is not None,"Job not found")
                    state["jobs"][job["id"]]=job
            try:
                outcome = self._apply(state, actor, operation, payload)
            except (KeyError, TypeError, IndexError) as exc:
                raise Rejected(f"Malformed payload or missing reference: {exc}") from exc
            if operation.startswith("python."):
                self._save_job(db,workspace,state["jobs"][payload["id"]])
                self._prune_jobs(db,workspace)
            else:state["version"] += 1
            state.pop("jobs",None)
            if operation=="workspace.share":
                db.execute("DELETE FROM memberships WHERE workspace=? AND principal=?",(workspace,payload["principal"]))
                if payload["role"]!="remove":db.execute("INSERT INTO memberships VALUES(?,?,?)",(workspace,payload["principal"],payload["role"]))
            response = {"status": "accepted", "version": state["version"], "outcome": outcome}
            if not operation.startswith("python."):
                db.execute("UPDATE workspaces SET state=? WHERE id=?", (canonical(state), workspace))
            event_command=deepcopy(c)
            event_outcome=deepcopy(outcome)
            saved_response=deepcopy(response)
            if operation.startswith("python."):
                event_command["payload"]={"id":payload["id"]}
                event_outcome=self._job_summary(outcome)
                saved_response["outcome"]=event_outcome
            db.execute("INSERT INTO events(workspace,actor,command,outcome,version) VALUES(?,?,?,?,?)",
                       (workspace, actor, canonical(event_command), canonical(event_outcome), state["version"]))
            db.execute("INSERT INTO receipts VALUES(?,?,?,?,?)",
                       (workspace, actor, request_id, fingerprint, canonical(saved_response)))
            db.commit()
            if self.on_commit is not None:
                try:self.on_commit()
                except Exception:logging.getLogger(__name__).exception("Commit notification failed; command remains committed")
            return response
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def _apply(self, state, actor, operation, p):
        allowed={
            "widget.create":{"id","kind","title","spec","layout"},
            "widget.update":{"id","expectedWidgetVersion","title","spec","layout"},
            "widget.delete":{"id","expectedWidgetVersion"},
            "persona.update":{"name","tone","greeting","examples","sharedFacts"},
            "workspace.share":{"principal","role"},"python.queue":{"id","code","bindings","widgetId"},
            "python.claim":{"id","runner"},"python.complete":{"id","runner","lease","status","output"},
            "python.cancel":{"id"},
        }
        require(set(p)<=allowed[operation],"Unknown operation payload field")
        if operation == "widget.create":
            wid = text(p["id"], "widget ID", 160)
            require(bool(wid) and wid not in state["widgets"], "Widget ID exists or is empty")
            kind = p["kind"]
            w = {"id": wid, "kind": kind, "title": text(p["title"], "title", 120),
                 "spec": widget_spec(kind, p.get("spec", {})), "layout": layout(p["layout"]),
                 "version": 1}
            state["widgets"][wid] = w
            return deepcopy(w)
        if operation == "widget.update":
            w = state["widgets"][p["id"]]
            if p["expectedWidgetVersion"] != w["version"]:
                raise Conflict("Widget version conflict")
            if "title" in p:
                w["title"] = text(p["title"], "title", 120)
            if "spec" in p:
                w["spec"] = widget_spec(w["kind"], p["spec"])
            if "layout" in p:
                w["layout"] = layout(p["layout"])
            w["version"] += 1
            return deepcopy(w)
        if operation == "widget.delete":
            w = state["widgets"][p["id"]]
            if p["expectedWidgetVersion"] != w["version"]:
                raise Conflict("Widget version conflict")
            del state["widgets"][p["id"]]
            return {"deleted": p["id"], "personaRetained": True}
        if operation == "persona.update":
            require(actor == state["owner"], "Only the owner edits the shared personality")
            require(set(p) <= {"name", "tone", "greeting", "examples", "sharedFacts"},
                    "Unknown personality field")
            for field in ("name", "tone", "greeting"):
                if field in p:
                    text(p[field], field, 3000)
            for field in ("examples", "sharedFacts"):
                if field in p:
                    require(isinstance(p[field], list) and len(p[field]) <= 30
                            and all(isinstance(v, str) and len(v) <= 3000 for v in p[field]),
                            f"Invalid {field}")
            state["persona"].update(deepcopy(p))
            return deepcopy(state["persona"])
        if operation == "workspace.share":
            require(actor == state["owner"], "Only the owner changes access")
            member = text(p["principal"], "member principal", 160)
            require(bool(member) and member != state["owner"], "Invalid member")
            require(p["role"] in {"viewer", "editor", "remove"}, "Unknown membership role")
            if p["role"] == "remove":
                state["members"].pop(member, None)
            else:
                state["members"][member] = p["role"]
            return {"principal": member, "role": p["role"]}
        if operation == "python.queue":
            jid = text(p["id"], "job ID", 160)
            require(bool(jid) and jid not in state["jobs"], "Job ID exists or is empty")
            code = text(p["code"], "Python code", 20000)
            require(bool(code.strip()), "Python code required")
            bindings = p.get("bindings", {})
            require(isinstance(bindings, dict) and len(canonical(bindings).encode()) <= 100000,
                    "Invalid Python bindings")
            if p.get("widgetId") is not None:
                require(isinstance(p["widgetId"],str) and p["widgetId"] in state["widgets"]
                        and state["widgets"][p["widgetId"]]["kind"]=="python","widgetId must reference a Python widget")
            state["jobs"][jid] = {"id": jid, "code": code, "bindings": bindings,
                "status": "queued", "requester": actor, "runner": None,
                "lease": None, "expires": 0, "output": None,
                "created": time.time(), "widgetId": p.get("widgetId")}
            return {"id": jid, "status": "queued", "waitingReason": "Awaiting an enabled browser runner"}
        if operation == "python.claim":
            job = state["jobs"][p["id"]]
            require(job["status"] == "queued" or
                    (job["status"] == "running" and job["expires"] < time.time()),
                    "Job is not available")
            runner = text(p["runner"], "runner ID", 160)
            require(bool(runner), "Runner ID required")
            job.update(status="running", runner=runner, lease=str(uuid4()), expires=time.time()+40)
            return deepcopy(job)
        if operation == "python.complete":
            job = state["jobs"][p["id"]]
            require(job["status"] == "running" and job["lease"] == p["lease"]
                    and job["runner"] == p["runner"] and job["expires"] >= time.time(),
                    "Stale, expired or cancelled job lease")
            require(p["status"] in {"succeeded", "failed"}, "Invalid completion status")
            output = p["output"]
            require(isinstance(output, dict) and len(canonical(output).encode()) <= 250000,
                    "Invalid job output")
            require(set(output) <= {"stdout", "stderr", "result", "error", "runtime"},
                    "Unknown output field")
            for field in ("stdout", "stderr", "error", "runtime"):
                if field in output:
                    text(output[field], field, 32000)
            job.update(status=p["status"], output=deepcopy(output), expires=0)
            return {"id": job["id"], "status": job["status"], "hasOutput": True}
        if operation == "python.cancel":
            job = state["jobs"][p["id"]]
            require(job["status"] in {"queued", "running"}, "Job is already terminal")
            job.update(status="cancelled", expires=0)
            return {"id": job["id"], "status": "cancelled"}
        raise Rejected("Operation has no implementation")
