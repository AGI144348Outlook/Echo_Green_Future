"""Machine-readable widget contracts matching service-side validation."""
from copy import deepcopy

def obj(properties,required=()):
    return {"type":"object","properties":properties,"required":list(required),"additionalProperties":False}

LAYOUT=obj({
    "x":{"type":"number","minimum":-100000,"maximum":100000},
    "y":{"type":"number","minimum":-100000,"maximum":100000},
    "width":{"type":"number","minimum":180,"maximum":100000},
    "height":{"type":"number","minimum":100,"maximum":100000},
    "collapsed":{"type":"boolean"},
},["x","y","width","height","collapsed"])

SPECS={
    "note":obj({"text":{"type":"string","maxLength":30000}}),
    "avatar":obj({"glyph":{"type":"string","maxLength":12},"color":{"type":"string","pattern":"^#[0-9a-fA-F]{6}$"},"message":{"type":"string","maxLength":3000}}),
    "python":obj({"code":{"type":"string","maxLength":20000}}),
    "table":obj({"columns":{"type":"array","maxItems":30,"items":{"type":"string"}},
                 "rows":{"type":"array","maxItems":500,"items":{"type":"array"}},"jobId":{"type":"string"}}),
    "chart":obj({"labels":{"type":"array","maxItems":100,"items":{"type":"string"}},
                 "values":{"type":"array","maxItems":100,"items":{"type":"number"}}}),
    "drawing":obj({"shapes":{"type":"array","maxItems":100,"items":obj({
        "type":{"enum":["circle","square"]},"x":{"type":"number","minimum":0,"maximum":10000},
        "y":{"type":"number","minimum":0,"maximum":10000},"size":{"type":"number","minimum":0,"maximum":10000},
        "label":{"type":"string","maxLength":100}},["type"])}}),
    "quiz":obj({"question":{"type":"string","maxLength":3000},"options":{"type":"array","minItems":2,"maxItems":8,"items":{"type":"string","maxLength":300}},
                "answerIndex":{"type":"integer","minimum":0,"maximum":7},"explanation":{"type":"string","maxLength":3000}},["options","answerIndex"]),
}

def create_payload_schema():
    variants=[]
    for kind,spec in SPECS.items():
        variants.append(obj({"id":{"type":"string","minLength":1,"maxLength":160},
            "kind":{"const":kind},"title":{"type":"string","maxLength":120},
            "spec":deepcopy(spec),"layout":deepcopy(LAYOUT)},["id","kind","title","spec","layout"]))
    return {"oneOf":variants,"description":"Typed widget descriptors. Table rows match columns; chart labels match values; quiz answerIndex is within options. JSON-encoded spec limit: 200000 UTF-8 bytes."}
