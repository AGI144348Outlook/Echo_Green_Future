"""Small stateless JSON-RPC MCP adapter over the same workspace service."""
import json

from .service import Rejected
from .schemas import LAYOUT, SPECS, create_payload_schema
from copy import deepcopy

TOOL_OPS = {
    "widget_create": "widget.create", "widget_update": "widget.update",
    "widget_delete": "widget.delete", "persona_update": "persona.update",
    "workspace_share": "workspace.share", "python_run": "python.queue",
    "python_cancel": "python.cancel",
}
DESCRIPTIONS = {
    "widget_create": "Create a note, avatar, Python, table, chart, drawing or quiz widget.",
    "widget_update": "Update a widget title, spec or layout; preserve its ID.",
    "widget_delete": "Delete a widget view record; companion personality remains.",
    "persona_update": "Owner-only update of explicitly shared companion traits/examples.",
    "workspace_share": "Owner-only grant/revoke access for a configured principal.",
    "python_run": "Queue Python for an enabled browser runner; queued is not executed.",
    "python_cancel": "Cancel a queued/running job; late results are rejected.",
}
PAYLOADS = {
    "widget_create": ({"id": {"type": "string"}, "kind": {"enum": ["note", "avatar", "python", "table", "chart", "drawing", "quiz"]},
                       "title": {"type": "string"}, "spec": {"type": "object"}, "layout": deepcopy(LAYOUT)},
                      ["id", "kind", "title", "spec", "layout"]),
    "widget_update": ({"id": {"type": "string"}, "expectedWidgetVersion": {"type": "integer"},
                       "title": {"type": "string"}, "spec": {"anyOf":list(SPECS.values()),"description":"Must match the existing widget kind; inspect that widget first."}, "layout": deepcopy(LAYOUT)},
                      ["id", "expectedWidgetVersion"]),
    "widget_delete": ({"id": {"type": "string"}, "expectedWidgetVersion": {"type": "integer"}}, ["id", "expectedWidgetVersion"]),
    "persona_update": ({"name": {"type": "string"}, "tone": {"type": "string"}, "greeting": {"type": "string"},
                        "examples": {"type": "array", "items": {"type": "string"}},
                        "sharedFacts": {"type": "array", "items": {"type": "string"}}}, []),
    "workspace_share": ({"principal": {"type": "string"}, "role": {"enum": ["viewer", "editor", "remove"]}}, ["principal", "role"]),
    "python_run": ({"id": {"type": "string"}, "code": {"type": "string"}, "bindings": {"type": "object"},
                    "widgetId": {"type": "string"}}, ["id", "code"]),
    "python_cancel": ({"id": {"type": "string"}}, ["id"]),
}


def tool_list():
    tools = []
    for name, description, properties, required in [
        ("workspace_list", "List workspaces available to the caller.", {}, []),
        ("workspace_create", "Create a new empty persistent workspace.", {"title": {"type": "string"}}, ["title"]),
        ("workspace_inspect", "Read widgets, personality, versions and bounded job summaries. Job code/output is retrieved separately with python_job_get. Read the selected personality before responding in its style.",
         {"workspaceId": {"type": "string"}}, ["workspaceId"]),
        ("python_job_get", "Read actual status/output of a queued Python job.",
         {"workspaceId": {"type": "string"}, "jobId": {"type": "string"}}, ["workspaceId", "jobId"]),
    ]:
        tools.append({"name": name, "description": description,
                      "inputSchema": {"type": "object", "properties": properties,
                                      "required": required, "additionalProperties": False},
                      "annotations": {"readOnlyHint": name != "workspace_create"}})
    for name in TOOL_OPS:
        fields, required = PAYLOADS[name]
        tools.append({"name": name, "description": DESCRIPTIONS[name],
            "inputSchema": {"type": "object", "properties": {
                "workspaceId": {"type": "string"}, "commandId": {"type": "string"},
                "expectedVersion": {"type": "integer", "minimum": 0},
                "payload": {"type": "object", "properties": fields, "required": required,
                            "additionalProperties": False}},
                "required": ["workspaceId", "commandId", "expectedVersion", "payload"],
                "additionalProperties": False}, "annotations": {"readOnlyHint": False}})
        if name=="widget_create":
            tools[-1]["inputSchema"]["properties"]["payload"]=create_payload_schema()
    return tools


def call_tool(service, actor, name, args):
    if not isinstance(args,dict):raise Rejected("Tool arguments must be an object")
    if name == "workspace_list":
        result = service.list(actor)
    elif name == "workspace_create":
        result = service.create(actor, args["title"])
    elif name == "workspace_inspect":
        result = service.get(actor, args["workspaceId"])
    elif name == "python_job_get":
        result = service.job(actor,args["workspaceId"],args["jobId"])
    elif name in TOOL_OPS:
        result = service.submit(actor, args["workspaceId"], {
            "id": args["commandId"], "expectedVersion": args["expectedVersion"],
            "operation": TOOL_OPS[name], "payload": args["payload"],
        })
    else:
        raise Rejected("Unknown tool")
    return {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False)}],
            "structuredContent": {"result": result}, "isError": False}
