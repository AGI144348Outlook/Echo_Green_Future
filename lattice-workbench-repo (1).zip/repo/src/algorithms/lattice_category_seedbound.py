import json, re, sys, random
from collections import defaultdict
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize
from lattice_sequential import canon

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)
with open("category_matrix.json", encoding="utf-8") as f:
    CATEGORY = json.load(f)   # root -> WordNet lexname (or absent)

NOISE_MARKERS = ["proper name", "son of", "daughter of", "father of", "a levite",
                  "descendant of", "chief of", "city in", "in judah", "in benjamin",
                  "in simeon", "in babylonia"]
def is_noise(pos, gloss):
    text = f"{pos} {gloss}".lower()
    return any(m in text for m in NOISE_MARKERS)

clean = {r: (pos, gloss) for r, (pos, gloss) in raw_roots.items() if not is_noise(pos, gloss)}

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    return [w.strip("()[].;:") for w in words if w.strip("()[].;:")][:3]

ROOTS = {r: make_tags(pos, g) for r, (pos, g) in clean.items()}
GLOSS = {r: g for r, (pos, g) in clean.items()}

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index

vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

def flags_touching_bidirectional(stem):
    a, b = stem
    return index.stem_to_flags.get((a, b), set()) | index.stem_to_flags.get((b, a), set())

def flag_closed(f, laid):
    for s in flag_m.flags[f]["stems"]:
        a, b = s
        if (a, b) not in laid and (b, a) not in laid:
            return False
    return True

SEED_FLAGS = ["מענ", "יצב", "עשה", "גדל"]
SEED_GLYPHS = set()
for f in SEED_FLAGS:
    SEED_GLYPHS.update(f)

def run_once(run_id, seed_rng):
    rng = random.Random(seed_rng)
    laid = set()
    for f in SEED_FLAGS:
        laid |= {tuple(s) for s in flag_m.flags[f]["stems"]}
    closed = {f for f in flag_m.flags if flag_closed(f, laid)}

    for step in range(200):
        frontier = defaultdict(set)
        for stem in laid:
            for f in flags_touching_bidirectional(stem):
                if f in closed:
                    continue
                for s in flag_m.flags[f]["stems"]:
                    a, b = s
                    if (a, b) in laid or (b, a) in laid:
                        continue
                    if a in SEED_GLYPHS and b in SEED_GLYPHS:
                        frontier[s].add(f)
        if not frontier:
            break

        def score(cand):
            flags = frontier[cand]
            cats = {CATEGORY[f] for f in flags if f in CATEGORY}
            return (len(cats), len(flags))

        best_score = max(score(c) for c in frontier)
        tied = [c for c in frontier if score(c) == best_score]
        choice = rng.choice(tied)  # RANDOM tie-break, seeded per run
        laid.add(choice)
        for f in flag_m.flags:
            if f not in closed and flag_closed(f, laid):
                closed.add(f)

    cats_present = defaultdict(list)
    for f in closed:
        cats_present[CATEGORY.get(f, "(untagged)")].append(f)

    print(f"=== RUN {run_id} ===")
    print(f"bricks: {len(laid)}, flags closed: {len(closed)}")
    print("category breakdown:")
    for cat, roots in sorted(cats_present.items(), key=lambda kv: -len(kv[1])):
        print(f"  {cat:20s} {len(roots):3d}  e.g. {sorted(roots)[:4]}")
    print()
    return closed

results = [run_once(i + 1, seed_rng=i + 1) for i in range(3)]

print("=== Comparing the 3 runs ===")
print(f"Run 1 vs Run 2 identical: {results[0] == results[1]}")
print(f"Run 1 vs Run 3 identical: {results[0] == results[2]}")
print(f"Run 2 vs Run 3 identical: {results[1] == results[2]}")
if not (results[0] == results[1] == results[2]):
    print(f"Sizes: {[len(r) for r in results]}")
    print(f"In run1 not run2: {sorted(results[0]-results[1])[:10]}")
    print(f"In run2 not run1: {sorted(results[1]-results[0])[:10]}")
