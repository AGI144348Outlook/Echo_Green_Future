"""
Algorithm K: distinct, separated regions -- then check what actually
connects them.

Difference from J: J kept refilling budget and growing from the SAME
frontier, so it kept re-exploring one hub. K instead:
  1. Grows one region to its first D-confirmed pyramid (bootstrap,
     unconstrained -- same as J's first burst).
  2. Marks every glyph touched during that walk as 'claimed'.
  3. Picks the NEXT seed deliberately far from claimed territory --
     the occupied stem whose two glyphs overlap LEAST with everything
     claimed so far.
  4. Repeats for N regions, each grown independently.
  5. THEN, and only then, checks whether any two regions' territories
     (their full walk, not just the final 4-flag pyramid) share a
     stem or glyph -- real cross-talk between genuinely separate
     regions, not artifacts of a single continuous walk.
"""
import json, re
from collections import defaultdict
from itertools import combinations
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize
from lattice_sequential import canon

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)

NOISE_MARKERS = ["proper name", "son of", "daughter of", "father of", "a levite",
                  "descendant of", "chief of", "city in", "in judah", "in benjamin",
                  "in simeon", "in babylonia"]
def is_noise(pos, gloss):
    text = f"{pos} {gloss}".lower()
    return any(m in text for m in NOISE_MARKERS)

clean = {r: (pos, gloss) for r, (pos, gloss) in raw_roots.items() if not is_noise(pos, gloss)}

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    return [w.strip("()[].;:") for w in words if w.strip("()[].;:")][:3]

ROOTS = {r: make_tags(pos, g) for r, (pos, g) in clean.items()}
GLOSS = {r: g for r, (pos, g) in clean.items()}

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index

vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

def flag_stems(f):
    return {canon(s, stem_m.slots) for s in flag_m.flags[f]["stems"]}

THEMES = {
    "perception_cognition": {"see", "hear", "know", "understand", "perceive", "look", "appear", "think", "remember", "learn", "consider"},
    "motion": {"go", "come", "walk", "run", "flee", "move", "turn", "travel", "wander", "pass", "depart"},
    "speech_communication": {"speak", "say", "call", "cry", "tell", "proclaim", "utter", "answer", "sing", "declare"},
    "emotion": {"love", "hate", "fear", "joy", "anger", "grieve", "desire", "delight", "rejoice", "mourn", "afraid"},
}
def theme_hits(gloss):
    tokens = set(re.findall(r"[a-z]+", gloss.lower()))
    return {t for t, words in THEMES.items() if tokens & words}

def is_exact_pyramid(quad):
    stems = set()
    for r in quad:
        stems.update(flag_stems(r))
    if len(stems) != 6:
        return False
    pair_shared = sum(1 for a, b in combinations(quad, 2) if flag_stems(a) & flag_stems(b))
    return pair_shared >= 3


def grow_one_region(seed, max_copies=2, max_bricks=60):
    """Bootstrap growth (H-style, unconstrained) until D confirms the
    first exact pyramid. Returns the full walk territory plus the
    closing quad."""
    laid = {canon(seed, stem_m.slots)}
    closed = set()
    for f in flag_m.flags:
        if flag_stems(f) <= laid:
            closed.add(f)

    for step in range(max_bricks):
        frontier = defaultdict(set)
        for stem in laid:
            for f in index.stem_to_flags.get(stem, set()):
                if f in closed:
                    continue
                for s in flag_stems(f):
                    if s not in laid:
                        frontier[s].add(f)
        if not frontier:
            return {"laid": laid, "closed": closed, "quad": None}

        def score(cand):
            flags = frontier[cand]
            themes_touched, total_hits = set(), 0
            for f in flags:
                th = theme_hits(GLOSS.get(f, ""))
                themes_touched |= th
                total_hits += len(th)
            return (len(themes_touched), total_hits, len(flags))

        choice = max(frontier, key=score)
        laid.add(choice)
        for f in flag_m.flags:
            if f not in closed and flag_stems(f) <= laid:
                closed.add(f)

        if len(closed) >= 4:
            quad = next((q for q in combinations(closed, 4) if is_exact_pyramid(q)), None)
            if quad:
                return {"laid": laid, "closed": set(quad), "quad": quad}

    return {"laid": laid, "closed": closed, "quad": None}


def algo_K(first_seed, n_regions=5):
    occupied_stems = [s for s, flags in stem_m.slots.items() if flags]
    claimed_glyphs = set()
    regions = []

    seed = first_seed
    for i in range(n_regions):
        r = grow_one_region(seed)
        regions.append({"seed": seed, **r})
        for stem in r["laid"]:
            claimed_glyphs.update(stem)

        if i == n_regions - 1:
            break

        # pick the next seed: occupied stem with LEAST glyph overlap
        # with everything claimed so far
        def novelty(stem):
            return len(set(stem) & claimed_glyphs)
        remaining = [s for s in occupied_stems if s not in claimed_glyphs]
        if not remaining:
            break
        seed = min(remaining, key=novelty)

    return regions


FIRST_SEED = ("א", "ה")
regions = algo_K(FIRST_SEED, n_regions=5)

print(f"=== Algorithm K: {len(regions)} separately-seeded regions ===\n")
for i, r in enumerate(regions):
    status = "CLOSED" if r["quad"] else "no pyramid found (ran out of frontier)"
    print(f"Region {i+1}  seed={r['seed']}  ({status})")
    if r["quad"]:
        for f in sorted(r["quad"]):
            print(f"   {f}: {GLOSS.get(f,'')}")
    print()

print("=== Cross-talk between SEPARATELY-seeded regions ===")
for i in range(len(regions)):
    for j in range(i + 1, len(regions)):
        shared_stems = regions[i]["laid"] & regions[j]["laid"]
        gi = set()
        for s in regions[i]["laid"]:
            gi.update(s)
        gj = set()
        for s in regions[j]["laid"]:
            gj.update(s)
        shared_glyphs = gi & gj
        if shared_stems:
            print(f"  Region {i+1} <-> Region {j+1}: SHARE STEM(S) {sorted(shared_stems)}")
        elif shared_glyphs:
            print(f"  Region {i+1} <-> Region {j+1}: no shared stem, but share glyph(s) {sorted(shared_glyphs)} (indirect)")
        else:
            print(f"  Region {i+1} <-> Region {j+1}: fully segregated (no shared stems or glyphs)")
