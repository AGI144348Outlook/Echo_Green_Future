"""
Step 1: fix the two honesty issues from last run --
  (a) filter out proper-name / place-name noise
  (b) replace substring keyword matching with real word-boundary matching

Step 2: draw several SEPARATE thematic regions at the workbench, by hand
(same mechanism as before -- full frontier shown, gloss-based choice --
just run across multiple themes/seeds instead of one).

Step 3: extract the pattern common to all those choices into an actual
algorithm (Algorithm G: theme-locked frontier walk).

Step 4: neuroscience framing -- treat each theme as a 'cortical region'
label (Category Matrix, as originally proposed), and build a small
connectome: do the regions ever share a stem/glyph with each other
(cross-talk), the way brain regions are linked by white-matter tracts?
"""
import json, re
from collections import defaultdict
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize
from lattice_sequential import canon

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)

NOISE_MARKERS = ["proper name", "son of", "daughter of", "father of", "a levite",
                  "descendant of", "chief of", "city in", "in judah", "in benjamin",
                  "in simeon", "in babylonia"]

def is_noise(pos, gloss):
    text = f"{pos} {gloss}".lower()
    return any(m in text for m in NOISE_MARKERS)

clean = {r: (pos, gloss) for r, (pos, gloss) in raw_roots.items() if not is_noise(pos, gloss)}
print(f"Filtered {len(raw_roots)} -> {len(clean)} roots after removing proper-name/place noise\n")

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    return [w.strip("()[].;:") for w in words if w.strip("()[].;:")][:3]

ROOTS = {r: make_tags(pos, g) for r, (pos, g) in clean.items()}
GLOSS = {r: g for r, (pos, g) in clean.items()}

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index

vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

def flag_stems(f):
    return {canon(s, stem_m.slots) for s in flag_m.flags[f]["stems"]}

def word_match(theme_words, gloss):
    """FIXED: word-boundary match, not substring -- 'see' no longer
    matches inside 'overseer'."""
    tokens = set(re.findall(r"[a-z]+", gloss.lower()))
    return len(tokens & theme_words)

# --- THE PATTERN, formalized ---
# Every hand-built region followed the same rule, whether I said so
# explicitly or not: at each step, score every frontier candidate by
# how many of its motivating flags' glosses hit the theme vocabulary
# (word-boundary), break ties by branching factor (how many open
# flags touch it), and lay the highest scorer. That's Algorithm G.

def algo_G_theme_walk(seed, theme_words, min_flags=4, min_stems=6, max_bricks=25):
    laid = {canon(seed, stem_m.slots)}
    closed = set()
    for f in flag_m.flags:
        if flag_stems(f) <= laid:
            closed.add(f)
    path = [{"brick": next(iter(laid)), "reason": "seed"}]

    for _ in range(max_bricks):
        frontier = defaultdict(set)
        for stem in laid:
            for f in index.stem_to_flags.get(stem, set()):
                if f in closed:
                    continue
                for s in flag_stems(f):
                    if s not in laid:
                        frontier[s].add(f)
        if not frontier:
            break

        def score(cand):
            flags = frontier[cand]
            theme_hits = sum(word_match(theme_words, GLOSS.get(f, "")) for f in flags)
            return (theme_hits, len(flags))

        choice = max(frontier, key=score)
        theme_hits, branch = score(choice)
        via = next(iter(frontier[choice]))
        laid.add(choice)
        for f in flag_m.flags:
            if f not in closed and flag_stems(f) <= laid:
                closed.add(f)
        path.append({"brick": choice, "reason": f"via {via}={GLOSS.get(via,'')} (theme_hits={theme_hits}, branch={branch})"})

        if len(closed) >= min_flags and len(laid) >= min_stems:
            return {"closed": True, "bricks": laid, "flags": closed, "path": path}

    return {"closed": False, "bricks": laid, "flags": closed, "path": path}


THEMES = {
    "perception_cognition": {"see", "hear", "know", "understand", "perceive", "look", "appear", "think", "remember", "learn", "consider"},
    "motion": {"go", "come", "walk", "run", "flee", "move", "turn", "travel", "wander", "pass", "depart"},
    "speech_communication": {"speak", "say", "call", "cry", "tell", "proclaim", "utter", "answer", "sing", "declare"},
    "emotion": {"love", "hate", "fear", "joy", "anger", "grieve", "desire", "delight", "rejoice", "mourn", "afraid"},
}

# seed picks: same style as the manual run -- letters with wide branching
SEEDS = {
    "perception_cognition": ("א", "ה"),
    "motion": ("ה", "ל"),
    "speech_communication": ("ד", "ב"),
    "emotion": ("א", "ה"),
}

print("=== Several separate, deliberately-themed regions (Algorithm G) ===\n")
regions_by_theme = {}
for theme, words in THEMES.items():
    r = algo_G_theme_walk(SEEDS[theme], words)
    regions_by_theme[theme] = r
    status = "CLOSED" if r["closed"] else "STALLED"
    print(f"--- {theme} ({status}, {len(r['bricks'])} bricks, {len(r['flags'])} flags) ---")
    for f in sorted(r["flags"]):
        print(f"   {f}: {GLOSS.get(f,'')}")
    print()

# --- Neuroscience-inspired layer: treat each theme as a labelled
# 'cortical region' (the Category Matrix from the original spec) and
# check for cross-talk -- do any two regions share a laid stem, the
# way brain regions are linked by white-matter tracts? ---

BRAIN_LABELS = {
    "perception_cognition": "Visual/Association Cortex (seeing, knowing)",
    "motion": "Motor Cortex / Cerebellum (movement, gait)",
    "speech_communication": "Broca's-Wernicke's Network (speech production & comprehension)",
    "emotion": "Limbic System / Amygdala (fear, love, grief)",
}

print("=== Neuroscience-inspired Category Matrix ===")
for theme, label in BRAIN_LABELS.items():
    print(f"  {theme:24s} -> {label}")
print()

print("=== Connectome: shared-stem cross-talk between regions ===")
themes = list(regions_by_theme.keys())
for i in range(len(themes)):
    for j in range(i + 1, len(themes)):
        t1, t2 = themes[i], themes[j]
        shared = regions_by_theme[t1]["bricks"] & regions_by_theme[t2]["bricks"]
        if shared:
            print(f"  {t1} <-> {t2}: share stem(s) {sorted(shared)}  (cross-talk)")
        else:
            print(f"  {t1} <-> {t2}: no shared stems (functionally segregated)")
