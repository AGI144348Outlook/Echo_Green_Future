import json, re
from collections import defaultdict
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize
from lattice_sequential import canon

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)
with open("category_matrix.json", encoding="utf-8") as f:
    CATEGORY = json.load(f)

NOISE_MARKERS = ["proper name", "son of", "daughter of", "father of", "a levite",
                  "descendant of", "chief of", "city in", "in judah", "in benjamin",
                  "in simeon", "in babylonia"]
def is_noise(pos, gloss):
    text = f"{pos} {gloss}".lower()
    return any(m in text for m in NOISE_MARKERS)

clean = {r: (pos, gloss) for r, (pos, gloss) in raw_roots.items() if not is_noise(pos, gloss)}

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    return [w.strip("()[].;:") for w in words if w.strip("()[].;:")][:3]

ROOTS = {r: make_tags(pos, g) for r, (pos, g) in clean.items()}
GLOSS = {r: g for r, (pos, g) in clean.items()}

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index

vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

def flags_touching_bidirectional(stem):
    a, b = stem
    return index.stem_to_flags.get((a, b), set()) | index.stem_to_flags.get((b, a), set())

def flag_closed(f, laid):
    for s in flag_m.flags[f]["stems"]:
        a, b = s
        if (a, b) not in laid and (b, a) not in laid:
            return False
    return True

SEEDS = {
    "emotion":  ["אבל", "אהב", "אוה", "אנה"],
    "speech":   ["אמר", "אנק", "ארר", "קרא"],
    "creation": ["גדר", "יסד", "יצר", "מסד"],
    "journey":  ["ארח", "בוא", "ברח", "עבר"],
    "power":    ["אמצ", "אפק", "עצמ", "תקפ"],
}

def grow_seed_bound(seed_flags):
    seed_glyphs = set()
    for f in seed_flags:
        seed_glyphs.update(f)
    laid = set()
    for f in seed_flags:
        laid |= {tuple(s) for s in flag_m.flags[f]["stems"]}
    closed = {f for f in flag_m.flags if flag_closed(f, laid)}

    for step in range(300):
        frontier = defaultdict(set)
        for stem in laid:
            for f in flags_touching_bidirectional(stem):
                if f in closed:
                    continue
                for s in flag_m.flags[f]["stems"]:
                    a, b = s
                    if (a, b) in laid or (b, a) in laid:
                        continue
                    if a in seed_glyphs and b in seed_glyphs:
                        frontier[s].add(f)
        if not frontier:
            break

        def score(cand):
            flags = frontier[cand]
            cats = {CATEGORY[f] for f in flags if f in CATEGORY}
            return (len(cats), len(flags))

        choice = max(frontier, key=score)
        laid.add(choice)
        for f in flag_m.flags:
            if f not in closed and flag_closed(f, laid):
                closed.add(f)

    return {"glyphs": seed_glyphs, "laid": laid, "closed": closed}


regions = {}
for name, seed in SEEDS.items():
    regions[name] = grow_seed_bound(seed)

print("=== 5 seed-bound regions ===\n")
for name, r in regions.items():
    print(f"[{name}]  sub-alphabet ({len(r['glyphs'])}): {sorted(r['glyphs'])}")
    print(f"  bricks: {len(r['laid'])}, flags closed: {len(r['closed'])}")
    cats = defaultdict(int)
    for f in r["closed"]:
        cats[CATEGORY.get(f, "(untagged)")] += 1
    top_cats = sorted(cats.items(), key=lambda kv: -kv[1])[:3]
    print(f"  top categories: {top_cats}")
    print()

print("=== Cross-talk between the 5 regions ===")
names = list(regions.keys())
for i in range(len(names)):
    for j in range(i + 1, len(names)):
        n1, n2 = names[i], names[j]
        shared_stems = regions[n1]["laid"] & regions[n2]["laid"]
        shared_flags = regions[n1]["closed"] & regions[n2]["closed"]
        shared_glyphs = regions[n1]["glyphs"] & regions[n2]["glyphs"]
        if shared_flags:
            print(f"  {n1} <-> {n2}: SHARE FLAG(S) {sorted(shared_flags)}")
        elif shared_stems:
            print(f"  {n1} <-> {n2}: share stem(s) {sorted(shared_stems)}")
        elif shared_glyphs:
            print(f"  {n1} <-> {n2}: no shared stem, share glyph(s) {sorted(shared_glyphs)} (indirect)")
        else:
            print(f"  {n1} <-> {n2}: fully segregated")
