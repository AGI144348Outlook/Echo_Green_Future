"""
Algorithm L: bidirectional stem reading.

Fix for the asymmetry flagged last turn: the Stem Matrix stores
(Resh,Ayin) and (Ayin,Resh) as two separate slots, because a Flag's
stems are built in the literal left-to-right order the glyphs occur
in a root. That meant a laid stem could only ever pull candidates
from flags that happened to use its exact direction.

Here: when reading a laid stem's frontier, read it BOTH ways --
Resh-Ayin left to right, Ayin-Resh right to left -- and merge the
candidate flags from both directions. The stem itself isn't changed
in the matrix (that history stays intact); only how growth READS it
changes. This is the 'sprouting seed, roots shooting out in varying
directions' version: one planted point, branching both ways.
"""
import json, re
from collections import defaultdict
from itertools import combinations
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize
from lattice_sequential import canon

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)

NOISE_MARKERS = ["proper name", "son of", "daughter of", "father of", "a levite",
                  "descendant of", "chief of", "city in", "in judah", "in benjamin",
                  "in simeon", "in babylonia"]
def is_noise(pos, gloss):
    text = f"{pos} {gloss}".lower()
    return any(m in text for m in NOISE_MARKERS)

clean = {r: (pos, gloss) for r, (pos, gloss) in raw_roots.items() if not is_noise(pos, gloss)}

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    return [w.strip("()[].;:") for w in words if w.strip("()[].;:")][:3]

ROOTS = {r: make_tags(pos, g) for r, (pos, g) in clean.items()}
GLOSS = {r: g for r, (pos, g) in clean.items()}

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index

vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

def flag_stems_directed(f):
    """The flag's stems exactly as laid (order matters -- this is
    what gets ADDED to `laid`)."""
    return {tuple(s) for s in flag_m.flags[f]["stems"]}

def flags_touching_bidirectional(stem):
    """THE FIX: read a laid stem's frontier both directions."""
    a, b = stem
    return index.stem_to_flags.get((a, b), set()) | index.stem_to_flags.get((b, a), set())

def flag_closed(f, laid):
    """A flag closes once all 3 of its stems are laid, checking each
    stem in EITHER direction (since growth may have laid the reverse
    of how this particular flag stores it)."""
    for s in flag_m.flags[f]["stems"]:
        a, b = s
        if (a, b) not in laid and (b, a) not in laid:
            return False
    return True

THEMES = {
    "perception_cognition": {"see", "hear", "know", "understand", "perceive", "look", "appear", "think", "remember", "learn", "consider"},
    "motion": {"go", "come", "walk", "run", "flee", "move", "turn", "travel", "wander", "pass", "depart"},
    "speech_communication": {"speak", "say", "call", "cry", "tell", "proclaim", "utter", "answer", "sing", "declare"},
    "emotion": {"love", "hate", "fear", "joy", "anger", "grieve", "desire", "delight", "rejoice", "mourn", "afraid"},
}
def theme_hits(gloss):
    tokens = set(re.findall(r"[a-z]+", gloss.lower()))
    return {t for t, words in THEMES.items() if tokens & words}


def grow_bidirectional(seed, max_bricks=60):
    laid = {tuple(seed)}
    closed = {f for f in flag_m.flags if flag_closed(f, laid)}
    path = [{"brick": tuple(seed), "reason": "seed"}]

    for step in range(max_bricks):
        frontier = defaultdict(set)
        for stem in laid:
            for f in flags_touching_bidirectional(stem):
                if f in closed:
                    continue
                for s in flag_m.flags[f]["stems"]:
                    a, b = s
                    if (a, b) not in laid and (b, a) not in laid:
                        frontier[s].add(f)   # candidate kept in ITS OWN native direction

        if not frontier:
            path.append({"brick": None, "reason": "frontier exhausted"})
            break

        def score(cand):
            flags = frontier[cand]
            themes_touched, total_hits = set(), 0
            for f in flags:
                th = theme_hits(GLOSS.get(f, ""))
                themes_touched |= th
                total_hits += len(th)
            return (len(themes_touched), total_hits, len(flags))

        choice = max(frontier, key=score)
        via = next(iter(frontier[choice]))
        laid.add(choice)
        newly_closed = set()
        for f in flag_m.flags:
            if f not in closed and flag_closed(f, laid):
                closed.add(f)
                newly_closed.add(f)
        path.append({"brick": choice, "reason": f"via {via}={GLOSS.get(via,'')}", "newly_closed": newly_closed})

        if len(closed) >= 4 and len(laid) >= 6:
            return {"laid": laid, "closed": closed, "path": path, "status": "CLOSED"}

    return {"laid": laid, "closed": closed, "path": path, "status": "STALLED"}


print("=== Algorithm L: bidirectional stem reading ===\n")
for seed in [("ר", "ע"), ("ע", "ר")]:
    r = grow_bidirectional(seed)
    print(f"--- Seed {seed} ({r['status']}, {len(r['laid'])} bricks) ---")
    for f in sorted(r["closed"]):
        print(f"   {f}: {GLOSS.get(f,'')}")
    print("   path:")
    for step in r["path"]:
        nc = step.get("newly_closed")
        nc_str = f"  closed:{sorted(nc)}" if nc else ""
        print(f"     {step['brick']}  {step['reason']}{nc_str}")
    print()
