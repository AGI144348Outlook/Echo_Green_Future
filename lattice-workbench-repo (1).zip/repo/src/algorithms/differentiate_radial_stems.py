"""
Differentiation algorithm: Stem Matrix -> fine-grained Radial Stem
tokens, using the Flag Matrix (which flags touch this stem) and the
Category Matrix (what semantic category each flag belongs to).

A raw Stem is just a letter-pair -- undifferentiated, no semantic
content. This produces, for every occupied stem, one token PER
DISTINCT CATEGORY among the flags that touch it:

    (stem, category) -> {flags in that category touching this stem}

That's the actual fine-grained brick a growth algorithm should lay,
instead of either a raw letter-pair (no semantic identity at all) or
a whole-alphabet-unbounded walk (no coherence at all).
"""
import json, re
from collections import defaultdict
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)
with open("category_matrix.json", encoding="utf-8") as f:
    CATEGORY = json.load(f)

NOISE_MARKERS = ["proper name", "son of", "daughter of", "father of", "a levite",
                  "descendant of", "chief of", "city in", "in judah", "in benjamin",
                  "in simeon", "in babylonia"]
def is_noise(pos, gloss):
    text = f"{pos} {gloss}".lower()
    return any(m in text for m in NOISE_MARKERS)

clean = {r: (pos, gloss) for r, (pos, gloss) in raw_roots.items() if not is_noise(pos, gloss)}

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    return [w.strip("()[].;:") for w in words if w.strip("()[].;:")][:3]

ROOTS = {r: make_tags(pos, g) for r, (pos, g) in clean.items()}
GLOSS = {r: g for r, (pos, g) in clean.items()}

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index

vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

def canonical_stem(a, b):
    return tuple(sorted((a, b)))

def flags_touching(stem):
    a, b = stem
    return index.stem_to_flags.get((a, b), set()) | index.stem_to_flags.get((b, a), set())

# --- THE DIFFERENTIATION ALGORITHM ---
FINE_RADIAL_STEMS = defaultdict(set)   # (canonical_stem, category) -> {flags}
raw_stems_seen = set()
for a in GLYPHS:
    for b in GLYPHS:
        stem = canonical_stem(a, b)
        if stem in raw_stems_seen:
            continue
        raw_stems_seen.add(stem)
        flags = flags_touching(stem)
        if not flags:
            continue
        for f in flags:
            cat = CATEGORY.get(f, "(untagged)")
            FINE_RADIAL_STEMS[(stem, cat)].add(f)

# --- Stats: how much did differentiation actually split things up? ---
splits_per_stem = defaultdict(set)
for (stem, cat) in FINE_RADIAL_STEMS:
    splits_per_stem[stem].add(cat)

n_occupied = len(splits_per_stem)
n_tokens = len(FINE_RADIAL_STEMS)
split_counts = defaultdict(int)
for stem, cats in splits_per_stem.items():
    split_counts[len(cats)] += 1

print(f"Occupied raw stems: {n_occupied}")
print(f"Fine-grained Radial Stem tokens produced: {n_tokens}")
print(f"Average categories per stem: {n_tokens/n_occupied:.2f}\n")
print("Distribution of how many categories a single stem got split into:")
for k in sorted(split_counts):
    print(f"  split into {k} categor{'y' if k==1 else 'ies'}: {split_counts[k]} stems")

print()
print("=== Example: stem (ר,ע) fine-grained ===")
example = canonical_stem("ר", "ע")
for (stem, cat), flags in FINE_RADIAL_STEMS.items():
    if stem == example:
        print(f"  [{cat}] ({len(flags)} flags): {sorted(flags)[:6]}")

with open("fine_radial_stems.json", "w", encoding="utf-8") as f:
    serializable = {f"{s[0]}|{s[1]}|{cat}": sorted(flags) for (s, cat), flags in FINE_RADIAL_STEMS.items()}
    json.dump(serializable, f, ensure_ascii=False)
print("\nSaved fine-grained Radial Stem tokens to fine_radial_stems.json")
