"""
Run the pipeline against REAL data: 1,673 triconsonantal root headwords
extracted from the unabridged Brown-Driver-Briggs Hebrew Lexicon
(source: github.com/eliranwong/unabridged-BDB-Hebrew-lexicon, itself a
digitisation of BDB 1906, public domain / formatting CC).

Extraction method (see extract step in conversation): for every BDB
entry, took the entry's first headword; kept it only if its consonant
skeleton (niqqud stripped) is exactly 3 Hebrew letters; used the
entry's own part-of-speech + gloss as its tags. This is a heuristic
extraction, not hand-verified lexicography -- some entries are proper
names or mis-parsed sub-senses, left in as-is for volume/realism.
"""

import json
import re
from collections import defaultdict, deque
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize
from lattice_sequential import sequential_stitch, canon

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    words = [w.strip("()[].;:") for w in words if w.strip("()[].;:")]
    return words[:3] if words else [pos.lower()]

ROOTS = {root: make_tags(pos, gloss) for root, (pos, gloss) in raw_roots.items()}
print(f"Loaded {len(ROOTS)} real triconsonantal roots from BDB\n")

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index


vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

print("=== Pipeline stats on real BDB data ===")
print(f"Roots processed (flags): {len(flag_m.flags)}")
print(f"Vertex Matrix nodes touched: {sum(1 for g in vertex_m.nodes if vertex_m.nodes[g]['roots'])} / {len(GLYPHS)}")
occupied = sum(1 for s in stem_m.slots.values() if s)
print(f"Stem Matrix slots occupied: {occupied} / {len(stem_m.slots)}")
print(f"Radial (differentiated) stems: {len(radial_m.radial)}\n")

# --- Algorithm A: batch greedy stem closure ---
def algo_A(flag_m, min_flags=4, min_stems=6):
    parent = {r: r for r in flag_m.flags}
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    stem_to_flags = defaultdict(set)
    for root, flag in flag_m.flags.items():
        for s in flag["stems"]:
            stem_to_flags[tuple(sorted(s))].add(root)
    for flags_sharing in stem_to_flags.values():
        flags_sharing = list(flags_sharing)
        for i in range(1, len(flags_sharing)):
            union(flags_sharing[0], flags_sharing[i])

    clusters = defaultdict(set)
    for r in flag_m.flags:
        clusters[find(r)].add(r)

    regions = []
    for cluster in clusters.values():
        stems = set()
        for r in cluster:
            stems.update(tuple(sorted(s)) for s in flag_m.flags[r]["stems"])
        if len(cluster) >= min_flags and len(stems) >= min_stems:
            regions.append({"flags": cluster, "stems": stems})
    return regions, clusters

regions_a, clusters_a = algo_A(flag_m)
sizes = sorted((len(c) for c in clusters_a.values()), reverse=True)
print("=== Algorithm A: batch greedy stem closure ===")
print(f"Total connected clusters: {len(clusters_a)}")
print(f"Clusters meeting region threshold (>=4 flags, >=6 stems): {len(regions_a)}")
print(f"Largest 5 cluster sizes (flag count): {sizes[:5]}")
if regions_a:
    biggest = max(regions_a, key=lambda r: len(r["flags"]))
    print(f"Largest region: {len(biggest['flags'])} flags, {len(biggest['stems'])} distinct stems")
print()

# --- Algorithm F: sequential frontier stitching, sampled ---
occupied_stems = [s for s, flags in stem_m.slots.items() if flags]
print(f"=== Algorithm F: sequential frontier stitching (all {len(occupied_stems)} occupied seeds) ===")

closed_count = 0
best = None
bricks_dist = defaultdict(int)
for seed in occupied_stems:
    r = sequential_stitch(flag_m, index, stem_m, seed, min_flags=4, min_stems=6, max_bricks=30)
    bricks_dist[len(r["bricks"])] += 1
    if r["closed"]:
        closed_count += 1
        if best is None or len(best["closed_flags"]) < len(r["closed_flags"]):
            best = r

print(f"Closed regions: {closed_count} / {len(occupied_stems)} seeds")
if best:
    print(f"Example closed region: {len(best['bricks'])} bricks, flags: {sorted(best['closed_flags'])}")
    print("Path:")
    for step in best["path"]:
        print(f"  {step['brick']}  <- {step['reason']}")
