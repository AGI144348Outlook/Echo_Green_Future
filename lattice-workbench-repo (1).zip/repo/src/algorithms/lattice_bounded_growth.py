"""
Algorithm I: H + C + E + D combined -- growth WITH wiring cost.

  - Candidate selection preference: H's rule (prefer the stem that
    bridges the most themes, then total theme-hit strength, then
    branching).
  - Admission gate (C): a candidate is only eligible for the frontier
    at all if its motivating flag's gloss-tags overlap the region's
    accumulated tag pool (union of tags from flags already closed).
    Before anything has closed, the gate is open (nothing to compare
    against yet) -- it activates the moment the first flag closes.
  - Reuse budget (E): each laid stem can only be drawn on as a
    frontier source `max_copies` times before it stops contributing
    new candidates -- models a hub 'wearing out' instead of being
    infinitely reusable, which is what let (ר,*)/(ב,*) dominate H's
    unconstrained run.
  - Stop condition (D): stop the moment ANY 4 closed flags satisfy
    the strict pyramid test (exactly 6 shared stems among them,
    pairwise-sharing on at least 3 of the 6 pairs) -- stop at the
    first real minimal shape instead of growing until stagnation.
"""
import json, re
from collections import defaultdict
from itertools import combinations
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize
from lattice_sequential import canon

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)

NOISE_MARKERS = ["proper name", "son of", "daughter of", "father of", "a levite",
                  "descendant of", "chief of", "city in", "in judah", "in benjamin",
                  "in simeon", "in babylonia"]
def is_noise(pos, gloss):
    text = f"{pos} {gloss}".lower()
    return any(m in text for m in NOISE_MARKERS)

clean = {r: (pos, gloss) for r, (pos, gloss) in raw_roots.items() if not is_noise(pos, gloss)}

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    return [w.strip("()[].;:") for w in words if w.strip("()[].;:")][:3]

ROOTS = {r: make_tags(pos, g) for r, (pos, g) in clean.items()}
GLOSS = {r: g for r, (pos, g) in clean.items()}

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index

vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

def flag_stems(f):
    return {canon(s, stem_m.slots) for s in flag_m.flags[f]["stems"]}

THEMES = {
    "perception_cognition": {"see", "hear", "know", "understand", "perceive", "look", "appear", "think", "remember", "learn", "consider"},
    "motion": {"go", "come", "walk", "run", "flee", "move", "turn", "travel", "wander", "pass", "depart"},
    "speech_communication": {"speak", "say", "call", "cry", "tell", "proclaim", "utter", "answer", "sing", "declare"},
    "emotion": {"love", "hate", "fear", "joy", "anger", "grieve", "desire", "delight", "rejoice", "mourn", "afraid"},
}
def theme_hits(gloss):
    tokens = set(re.findall(r"[a-z]+", gloss.lower()))
    return {t for t, words in THEMES.items() if tokens & words}


def is_exact_pyramid(quad):
    """D's test: exactly 6 distinct shared stems across the 4 flags,
    with pairwise sharing on at least 3 of the 6 possible pairs."""
    stems = set()
    for r in quad:
        stems.update(flag_stems(r))
    if len(stems) != 6:
        return False
    pair_shared = 0
    for a, b in combinations(quad, 2):
        if flag_stems(a) & flag_stems(b):
            pair_shared += 1
    return pair_shared >= 3


def algo_I_bounded_growth(seed, max_copies=2, max_bricks=60):
    laid = {canon(seed, stem_m.slots)}
    closed = set()
    for f in flag_m.flags:
        if flag_stems(f) <= laid:
            closed.add(f)
    stem_budget = defaultdict(lambda: max_copies)
    region_tags = set()
    for f in closed:
        region_tags.update(flag_m.flags[f]["tags"])

    log = [{"brick": next(iter(laid)), "reason": "seed"}]

    for step in range(max_bricks):
        # frontier, respecting E's per-stem reuse budget
        frontier = defaultdict(set)       # candidate -> {(source_stem, flag)}
        for stem in laid:
            if stem_budget[stem] <= 0:
                continue
            for f in index.stem_to_flags.get(stem, set()):
                if f in closed:
                    continue
                for s in flag_stems(f):
                    if s not in laid:
                        frontier[s].add((stem, f))

        if not frontier:
            log.append({"brick": None, "reason": "STOPPED: frontier exhausted (all sources out of budget or dead-ended)"})
            break

        # C's admission gate: once region_tags is non-empty, a
        # candidate only survives if at least one motivating flag's
        # tags overlap the region's accumulated tag pool
        if region_tags:
            gated = {}
            for cand, sources in frontier.items():
                ok_sources = {(s, f) for s, f in sources if set(flag_m.flags[f]["tags"]) & region_tags}
                if ok_sources:
                    gated[cand] = ok_sources
            if not gated:
                log.append({"brick": None, "reason": "STOPPED: no candidate cleared the tag-overlap gate"})
                break
            frontier = gated

        # H's scoring: prefer bridging the most themes, then hit
        # strength, then branching
        def score(cand):
            flags = {f for _, f in frontier[cand]}
            themes_touched = set()
            total_hits = 0
            for f in flags:
                th = theme_hits(GLOSS.get(f, ""))
                themes_touched |= th
                total_hits += len(th)
            return (len(themes_touched), total_hits, len(flags))

        choice = max(frontier, key=score)
        sources = frontier[choice]
        n_themes, hits, branch = score(choice)

        laid.add(choice)
        for stem, _ in sources:
            stem_budget[stem] -= 1  # E: wear on the hub(s) that unlocked this

        newly_closed = set()
        for f in flag_m.flags:
            if f not in closed and flag_stems(f) <= laid:
                closed.add(f)
                newly_closed.add(f)
                region_tags.update(flag_m.flags[f]["tags"])

        log.append({"brick": choice, "reason": f"bridges {n_themes} theme(s), hits={hits}, branch={branch}",
                     "newly_closed": newly_closed})

        # D's stop condition: first exact minimal pyramid among closed flags
        if len(closed) >= 4:
            found = None
            for quad in combinations(closed, 4):
                if is_exact_pyramid(quad):
                    found = quad
                    break
            if found:
                log.append({"brick": None, "reason": f"STOPPED: exact pyramid closed at {sorted(found)}"})
                return {"bricks": laid, "flags": closed, "log": log, "pyramid": found}

    return {"bricks": laid, "flags": closed, "log": log, "pyramid": None}


SEED = ("א", "ה")
print(f"=== Algorithm I: bounded growth from seed {SEED} ===\n")
result = algo_I_bounded_growth(SEED)

print(f"Final size: {len(result['bricks'])} bricks, {len(result['flags'])} flags closed")
print(f"Exact pyramid found: {result['pyramid']}\n")

print("=== Growth log ===")
for i, step in enumerate(result["log"]):
    nc = step.get("newly_closed", set())
    nc_str = f"  closed:{sorted(nc)}" if nc else ""
    brick = step["brick"] if step["brick"] else "--"
    print(f"  {i:2d}. {brick}  {step['reason']}{nc_str}")

print("\n=== Final flags ===")
for f in sorted(result["flags"]):
    print(f"   {f}: {GLOSS.get(f,'')}")
