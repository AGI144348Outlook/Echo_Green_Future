"""
Feedback Loop experiments: using mesh_algorithm.py's output to derive
"learned relations" (which glyph pairs co-occur most across discovered
tetrahedra), feeding that back in as a bias on future runs, and adding a
SECOND-ORDER (sub-feedback) loop that monitors whether the first loop's
bias is helping or hurting -- adjusting the bias weight itself.

=== NAMING THIS PRECISELY ===
A system that (1) acts, (2) observes the consequence, (3) updates a
parameter based on whether that consequence was good or bad, and
(4) repeats, is a learning algorithm. Specifically, a loop that learns
relations from data while a second loop learns how much to TRUST the
first loop is a two-tier adaptive / meta-learning system.

=== RESULT 1: naive positive feedback caused mode collapse, not growth ===
Generation 0 (baseline): 351 tetrahedra.
Generation 1 (biased toward gen-0's most common relations): 97
tetrahedra -- a collapse, not reinforcement. Biasing toward "what
already worked" narrowed the search so aggressively that even the
favored relations ended up with FEWER total occurrences, because there
was far less overall exploration for them to appear in. The
sub-feedback stability check found ZERO relations that held steady or
strengthened between generations.

=== RESULT 2: a real meta-controller CAN self-correct, but only partly ===
Adding a controller that watches generation-over-generation SIZE and
cuts its own bias_weight on collapse actually worked: 0.5 -> 0.2 -> 0.08
-> 0.032, correctly detecting and throttling its own primary loop's
damage, eventually stabilizing at 46 tetrahedra (up from a low of 42).

BUT it stabilized at 46, far below the original 351 -- because each
generation's "learned relations" were re-derived from THAT
generation's own already-shrunk structure, not from a clean baseline.
The controller was tuning its influence correctly, but influencing
itself with corrupted data the whole time. The unfixed architectural
lesson: a sub-feedback loop should separate WHAT IT MONITORS (current
generation, to detect collapse) from WHAT IT LEARNS FROM (should stay
anchored to the last known-healthy generation, not whichever one just
ran). This fix was identified but not yet implemented/tested.
"""
import json
from itertools import combinations
from collections import Counter
import sys
sys.path.append('.')
from mesh_algorithm import mesh, real_flags_for  # noqa: E402


def relations_from(tetra_index):
    rs = Counter()
    for verts in tetra_index:
        for pair in combinations(verts, 2):
            rs[tuple(sorted(pair))] += 1
    return rs


def naive_feedback_run(parent, living, generations=2, bias_weight=0.5):
    """Reproduces the FIRST experiment: naive reinforcement, no
    self-correction. Demonstrates the collapse."""
    relation_bonus = {}
    history = []
    for gen in range(generations):
        result = mesh(parent, living, relation_bonus=relation_bonus, bias_weight=bias_weight)
        size = len(result['tetra_index'])
        history.append(size)
        relation_bonus = relations_from(result['tetra_index'])
        print(f"  Gen {gen}: {size} tetrahedra")
    return history


def meta_controlled_run(parent, living, generations=6, initial_bias=0.5):
    """Reproduces the SECOND experiment: a sub-feedback loop that
    monitors the primary loop's own performance and adjusts bias_weight.
    KNOWN LIMITATION (see module docstring): relation_bonus is re-derived
    from each generation's own (possibly collapsed) output, not anchored
    to a healthy baseline -- this is why it stabilizes low instead of
    recovering. A fixed version would keep relation_bonus computed from
    the FIRST healthy generation while still monitoring current size."""
    bias_weight = initial_bias
    relation_bonus = {}
    history = []

    for gen in range(generations):
        result = mesh(parent, living, relation_bonus=relation_bonus, bias_weight=bias_weight)
        size = len(result['tetra_index'])

        if gen > 0:
            prev_size = history[gen - 1][2]
            if size < prev_size:
                verdict = 'COLLAPSE -- cutting bias'
                bias_weight *= 0.4
            elif size > prev_size:
                verdict = 'GROWTH -- nudging bias up'
                bias_weight = min(bias_weight * 1.2, 1.0)
            else:
                verdict = 'FLAT -- holding steady'
        else:
            verdict = 'baseline'

        history.append((gen, bias_weight, size))
        print(f"  Gen {gen}: bias_weight={bias_weight:.4f} -> {size} tetrahedra   [{verdict}]")
        relation_bonus = relations_from(result['tetra_index'])  # <-- the un-fixed bug

    return history


if __name__ == "__main__":
    PARENT = ('נ', 'ת', 'כ', 'ח')
    LIVING = ['ע', 'ר', 'ס', 'ש', 'מ', 'ל', 'ה', 'ד']

    print("=== Naive feedback (no self-correction) ===")
    naive_feedback_run(PARENT, LIVING)

    print("\n=== Meta-controlled feedback (sub-loop tunes the primary loop) ===")
    meta_controlled_run(PARENT, LIVING)
