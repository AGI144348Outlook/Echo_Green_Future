"""
Algorithm J: D as a RESET control for E, so C becomes a real gate
instead of either inert (alone) or a starvation trap (with E untouched).

Mechanism:
  - Grow with C's tag-gate active and E's reuse budget active, same as
    before.
  - The moment D detects a new exact pyramid among closed flags, that's
    not a hard stop anymore -- it's a CHECKPOINT: log it as a
    completed Region, and RESET every stem's E-budget back to full.
  - region_tags (what C's gate compares against) is NEVER reset -- it
    keeps accumulating across every region found, so C's gate gets
    more informed (and can afford to be strict) as growth continues,
    instead of running dry on a thin tag pool early on.
  - Growth keeps going in pulses until the frontier truly dies or a
    region cap is hit.
"""
import json, re
from collections import defaultdict
from itertools import combinations
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize
from lattice_sequential import canon

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)

NOISE_MARKERS = ["proper name", "son of", "daughter of", "father of", "a levite",
                  "descendant of", "chief of", "city in", "in judah", "in benjamin",
                  "in simeon", "in babylonia"]
def is_noise(pos, gloss):
    text = f"{pos} {gloss}".lower()
    return any(m in text for m in NOISE_MARKERS)

clean = {r: (pos, gloss) for r, (pos, gloss) in raw_roots.items() if not is_noise(pos, gloss)}

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    return [w.strip("()[].;:") for w in words if w.strip("()[].;:")][:3]

ROOTS = {r: make_tags(pos, g) for r, (pos, g) in clean.items()}
GLOSS = {r: g for r, (pos, g) in clean.items()}

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index

vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

def flag_stems(f):
    return {canon(s, stem_m.slots) for s in flag_m.flags[f]["stems"]}

THEMES = {
    "perception_cognition": {"see", "hear", "know", "understand", "perceive", "look", "appear", "think", "remember", "learn", "consider"},
    "motion": {"go", "come", "walk", "run", "flee", "move", "turn", "travel", "wander", "pass", "depart"},
    "speech_communication": {"speak", "say", "call", "cry", "tell", "proclaim", "utter", "answer", "sing", "declare"},
    "emotion": {"love", "hate", "fear", "joy", "anger", "grieve", "desire", "delight", "rejoice", "mourn", "afraid"},
}
def theme_hits(gloss):
    tokens = set(re.findall(r"[a-z]+", gloss.lower()))
    return {t for t, words in THEMES.items() if tokens & words}

def is_exact_pyramid(quad):
    stems = set()
    for r in quad:
        stems.update(flag_stems(r))
    if len(stems) != 6:
        return False
    pair_shared = sum(1 for a, b in combinations(quad, 2) if flag_stems(a) & flag_stems(b))
    return pair_shared >= 3


def algo_J(seed, max_copies=2, max_bricks=200, max_regions=8):
    laid = {canon(seed, stem_m.slots)}
    closed = set()
    for f in flag_m.flags:
        if flag_stems(f) <= laid:
            closed.add(f)
    stem_budget = defaultdict(lambda: max_copies)
    region_tags = set()
    for f in closed:
        region_tags.update(flag_m.flags[f]["tags"])

    regions = []          # list of (quad, step_found)
    recorded = set()      # frozensets already counted, don't recount
    gate_blocks = 0
    stop_reason = "max_bricks reached"
    bootstrapped = False  # C+E stay OFF until the first region closes

    for step in range(max_bricks):
        frontier = defaultdict(set)
        for stem in laid:
            if bootstrapped and stem_budget[stem] <= 0:
                continue
            for f in index.stem_to_flags.get(stem, set()):
                if f in closed:
                    continue
                for s in flag_stems(f):
                    if s not in laid:
                        frontier[s].add((stem, f))

        if not frontier:
            stop_reason = "frontier exhausted"
            break

        if bootstrapped and region_tags:
            gated = {}
            for cand, sources in frontier.items():
                ok = {(s, f) for s, f in sources if set(flag_m.flags[f]["tags"]) & region_tags}
                if ok:
                    gated[cand] = ok
            if not gated:
                gate_blocks += 1
                stop_reason = "tag-overlap gate blocked all candidates"
                break
            frontier = gated

        def score(cand):
            flags = {f for _, f in frontier[cand]}
            themes_touched, total_hits = set(), 0
            for f in flags:
                th = theme_hits(GLOSS.get(f, ""))
                themes_touched |= th
                total_hits += len(th)
            return (len(themes_touched), total_hits, len(flags))

        choice = max(frontier, key=score)
        sources = frontier[choice]
        laid.add(choice)
        if bootstrapped:
            for stem, _ in sources:
                stem_budget[stem] -= 1

        newly_closed = set()
        for f in flag_m.flags:
            if f not in closed and flag_stems(f) <= laid:
                closed.add(f)
                newly_closed.add(f)
                region_tags.update(flag_m.flags[f]["tags"])

        # D as CHECKPOINT, not stop: look for a new exact pyramid
        if len(closed) >= 4:
            for quad in combinations(closed, 4):
                key = frozenset(quad)
                if key in recorded:
                    continue
                if is_exact_pyramid(quad):
                    recorded.add(key)
                    regions.append((quad, step))
                    stem_budget = defaultdict(lambda: max_copies)  # RESET (the new mechanic)
                    bootstrapped = True  # C+E switch ON from here forward
                    break  # one checkpoint per step is enough

        if len(regions) >= max_regions:
            stop_reason = f"reached max_regions ({max_regions})"
            break

    return {"bricks": laid, "flags": closed, "regions": regions,
             "stop": stop_reason, "gate_blocks": gate_blocks}


SEED = ("א", "ה")
print(f"=== Algorithm J: D-triggered E-reset, seed {SEED} ===\n")
r = algo_J(SEED)

print(f"Total bricks: {len(r['bricks'])}, total flags closed: {len(r['flags'])}")
print(f"Regions (checkpoints) found: {len(r['regions'])}")
print(f"Stopped because: {r['stop']}\n")

for i, (quad, step) in enumerate(r["regions"]):
    print(f"Region {i+1} (closed at step {step}):")
    for f in sorted(quad):
        print(f"   {f}: {GLOSS.get(f,'')}")
    print()

covered = set()
for quad, _ in r["regions"]:
    covered.update(quad)
leftover = r["flags"] - covered
print(f"Flags closed but not inside any recorded pyramid: {len(leftover)}")
print(sorted(leftover)[:20], "..." if len(leftover) > 20 else "")
