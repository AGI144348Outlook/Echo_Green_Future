"""
Algorithm H: cross-talk-seeking growth from a single seed.

Difference from Algorithm G: G locks to ONE theme and scores candidates
by how well they fit it. H scores candidates by how many DIFFERENT
themes they touch at once -- it actively prefers bridge stems (the
ones that would wire two 'brain regions' together) over staying inside
one theme. No early stop at the first minimal closure -- let it run
and watch the shape it grows into.
"""
import json, re
from collections import defaultdict
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize
from lattice_sequential import canon

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)

NOISE_MARKERS = ["proper name", "son of", "daughter of", "father of", "a levite",
                  "descendant of", "chief of", "city in", "in judah", "in benjamin",
                  "in simeon", "in babylonia"]
def is_noise(pos, gloss):
    text = f"{pos} {gloss}".lower()
    return any(m in text for m in NOISE_MARKERS)

clean = {r: (pos, gloss) for r, (pos, gloss) in raw_roots.items() if not is_noise(pos, gloss)}

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    return [w.strip("()[].;:") for w in words if w.strip("()[].;:")][:3]

ROOTS = {r: make_tags(pos, g) for r, (pos, g) in clean.items()}
GLOSS = {r: g for r, (pos, g) in clean.items()}

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index

vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

def flag_stems(f):
    return {canon(s, stem_m.slots) for s in flag_m.flags[f]["stems"]}

THEMES = {
    "perception_cognition": {"see", "hear", "know", "understand", "perceive", "look", "appear", "think", "remember", "learn", "consider"},
    "motion": {"go", "come", "walk", "run", "flee", "move", "turn", "travel", "wander", "pass", "depart"},
    "speech_communication": {"speak", "say", "call", "cry", "tell", "proclaim", "utter", "answer", "sing", "declare"},
    "emotion": {"love", "hate", "fear", "joy", "anger", "grieve", "desire", "delight", "rejoice", "mourn", "afraid"},
}

def theme_hits(gloss):
    tokens = set(re.findall(r"[a-z]+", gloss.lower()))
    return {t for t, words in THEMES.items() if tokens & words}

def algo_H_crosstalk_growth(seed, max_bricks=60, stop_after_no_growth=15):
    laid = {canon(seed, stem_m.slots)}
    closed = set()
    for f in flag_m.flags:
        if flag_stems(f) <= laid:
            closed.add(f)
    log = [{"brick": next(iter(laid)), "reason": "seed", "themes": set()}]
    stall_counter = 0

    for step in range(max_bricks):
        frontier = defaultdict(set)
        for stem in laid:
            for f in index.stem_to_flags.get(stem, set()):
                if f in closed:
                    continue
                for s in flag_stems(f):
                    if s not in laid:
                        frontier[s].add(f)
        if not frontier:
            break

        def score(cand):
            flags = frontier[cand]
            themes_touched = set()
            total_hits = 0
            for f in flags:
                th = theme_hits(GLOSS.get(f, ""))
                themes_touched |= th
                total_hits += len(th)
            # prioritize: (a) how many DISTINCT themes this bridges,
            # (b) total theme-hit strength, (c) branching factor
            return (len(themes_touched), total_hits, len(flags))

        choice = max(frontier, key=score)
        n_themes, hits, branch = score(choice)
        via_flags = frontier[choice]
        themes_here = set()
        for f in via_flags:
            themes_here |= theme_hits(GLOSS.get(f, ""))

        laid.add(choice)
        newly_closed = set()
        for f in flag_m.flags:
            if f not in closed and flag_stems(f) <= laid:
                closed.add(f)
                newly_closed.add(f)

        log.append({"brick": choice, "reason": f"bridges {n_themes} theme(s), hits={hits}, branch={branch}",
                     "themes": themes_here, "newly_closed": newly_closed})

        if not newly_closed:
            stall_counter += 1
        else:
            stall_counter = 0
        if stall_counter >= stop_after_no_growth:
            break

    return {"bricks": laid, "flags": closed, "log": log}


SEED = ("א", "ה")
print(f"=== Algorithm H: watching seed {SEED} grow its own 'brain' ===\n")
result = algo_H_crosstalk_growth(SEED)

print(f"Final size: {len(result['bricks'])} bricks, {len(result['flags'])} flags closed\n")

print("=== Growth log (bridge steps highlighted) ===")
for i, step in enumerate(result["log"]):
    marker = " <-- BRIDGE" if len(step.get("themes", set())) >= 2 else ""
    nc = step.get("newly_closed", set())
    nc_str = f" closed:{sorted(nc)}" if nc else ""
    print(f"  {i:2d}. {step['brick']}  {step['reason']}{nc_str}{marker}")

print("\n=== Final region, grouped by theme (a flag can belong to >1 = bridge) ===")
theme_membership = defaultdict(list)
bridge_flags = []
for f in result["flags"]:
    th = theme_hits(GLOSS.get(f, ""))
    if len(th) >= 2:
        bridge_flags.append((f, th))
    elif len(th) == 1:
        theme_membership[next(iter(th))].append(f)
    else:
        theme_membership["(untagged / other)"].append(f)

for theme, flags in theme_membership.items():
    print(f"\n  [{theme}]  ({len(flags)} flags)")
    for f in sorted(flags):
        print(f"     {f}: {GLOSS.get(f,'')}")

if bridge_flags:
    print(f"\n  [BRIDGE FLAGS -- touch multiple themes at once]  ({len(bridge_flags)})")
    for f, th in bridge_flags:
        print(f"     {f}: {GLOSS.get(f,'')}  -- themes: {sorted(th)}")
