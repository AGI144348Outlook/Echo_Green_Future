"""
Fractal Centroid algorithms: the Region Integrity Infrastructure family.

When a tetrahedron (4 flags / 6 stems) closes, a Null/Inert centroid
vertex can be instantiated at its "center" -- connected to all 4 outer
vertices via 4 new stems, opening up to 6 new interior faces (C(4,2)).
If any of the resulting 4 sub-tetrahedra ALSO close, that recursively
triggers a new centroid, and so on, inward.

This file contains every reuse-policy variant tested this session, in
the order they were tried, because each one taught something the
previous one didn't:

  1. PERMANENT EXCLUSION -- a glyph used once can never be centroid
     again anywhere in the recursion. Bounded (max ~84), but doesn't
     reflect how tokenization actually works (a Vertex isn't consumed
     by use).

  2. COOLDOWN REUSE -- a glyph is eligible again after N levels.
     Removes the artificial exclusion, but revealed that ANY letter
     that can ignite at all has UNBOUNDED fractal potential once
     revisits are allowed within a short cooldown -- it just hits
     whatever safety cap you set, every time.

  3. TETRAHEDRON-INDEX CYCLE PREVENTION -- a global index permanently
     denies re-opening any 4-vertex tetrahedron that's already been
     logged, regardless of reuse policy. This is the fix that actually
     matters: without it, "unbounded growth" turns out to mostly be
     the same handful of tetrahedra being revisited thousands of times
     (one test found 98.8% of 3,000 "new" centroids were really just 5
     tetrahedra in a loop). With it, growth naturally terminates on
     genuinely novel structure.

  4. CATEGORY-PROPORTIONAL CAPS (Sefer Yetzirah inspired) -- instead of
     one global cap, usage budget is set per traditional Hebrew letter
     classification: Mothers (unlimited or 3x Doubles), Doubles (2x
     Simples), Simples (budget / 12). Combined with cycle prevention,
     this is the most defensible variant tested.

KEY EMPIRICAL FINDING (all variants): against the fixed parent
tetrahedron (נ,ת,כ,ח), exactly the SAME 10 of 22 glyphs never ignite a
single sub-tetrahedron closure under ANY reuse policy: א,ב,ג,ו,ז,ט,י,
פ,צ,ק. The other 12 (ד,ה,ל,מ,ס,ע,פ,ר,ש + the 4 parent vertices) all
ignite to varying degrees. Resh (ר) is consistently among the top
performers across every variant tried.
"""
import json
from itertools import combinations, permutations
from collections import defaultdict

with open("../../data/processed/bdb_roots.json", encoding="utf-8") as f:
    roots = json.load(f)

GLYPHS = list('אבגדהוזחטיכלמנסעפצקרשת')

# Sefer Yetzirah's traditional 3/7/12 classification
MOTHERS = set('אמש')
DOUBLES = set('בגדכפרת')
SIMPLES = set(GLYPHS) - MOTHERS - DOUBLES


def real_flags_for(letters):
    return [''.join(p) for p in set(permutations(letters)) if ''.join(p) in roots]


def score_centroid(centroid, outer_vertices):
    by_pair = {}
    for pair in combinations(outer_vertices, 2):
        hits = real_flags_for((centroid,) + pair)
        if hits:
            by_pair[pair] = hits
    return by_pair


def sub_tet_closes(centroid, three_vertices):
    if not real_flags_for(three_vertices):
        return False
    return all(real_flags_for((centroid,) + pair) for pair in combinations(three_vertices, 2))


# ---------------------------------------------------------------------
# Variant 1: permanent exclusion (each glyph usable once, ever)
# ---------------------------------------------------------------------
def fractal_permanent_exclusion(centroid, outer_vertices, used, max_depth=8):
    used = used | {centroid}
    children = 0
    for three in combinations(outer_vertices, 3):
        if sub_tet_closes(centroid, three):
            candidates = [g for g in GLYPHS if g not in used and g not in three and g != centroid]
            if not candidates:
                continue
            best = max(candidates, key=lambda g: len(score_centroid(g, (centroid,) + three)))
            if len(score_centroid(best, (centroid,) + three)) > 0:
                children += 1 + fractal_permanent_exclusion(best, (centroid,) + three, used, max_depth)
    return children


# ---------------------------------------------------------------------
# Variant 4 (recommended): category-proportional caps + cycle prevention
# ---------------------------------------------------------------------
def make_cap_function(budget_base=3000):
    simple_cap = budget_base / len(SIMPLES)
    double_cap = 2 * simple_cap
    mother_cap = 3 * double_cap

    def cap_for(g):
        if g in MOTHERS:
            return mother_cap
        if g in DOUBLES:
            return double_cap
        return simple_cap
    return cap_for, (simple_cap, double_cap, mother_cap)


def fractal_bounded(parent, centroid0, budget_base=3000):
    """Recommended variant: proportional caps + a real Tetrahedron index
    that permanently denies revisiting any already-logged tetrahedron.
    Terminates naturally, on genuinely novel structure only."""
    cap_for, caps = make_cap_function(budget_base)
    usage = defaultdict(int)
    for g in parent:
        usage[g] += 1
    usage[centroid0] += 1
    tetra_index = {frozenset(parent)}
    log = []

    def grow(centroid, outer, depth):
        for three in combinations(outer, 3):
            if sub_tet_closes(centroid, three):
                new_tetra = frozenset((centroid,) + three)
                if new_tetra in tetra_index:
                    continue  # DENIED -- already logged
                candidates = [g for g in GLYPHS if g not in three and g != centroid
                              and usage[g] < cap_for(g)]
                if not candidates:
                    continue
                best = max(candidates, key=lambda g: len(score_centroid(g, (centroid,) + three)))
                if len(score_centroid(best, (centroid,) + three)) > 0:
                    tetra_index.add(new_tetra)
                    usage[best] += 1
                    log.append((depth, best, (centroid,) + three))
                    grow(best, (centroid,) + three, depth + 1)

    grow(centroid0, parent, 0)
    return {"tetra_index": tetra_index, "usage": dict(usage), "log": log, "caps": caps}


if __name__ == "__main__":
    PARENT = ('נ', 'ת', 'כ', 'ח')
    print(f"Testing all 22 glyphs as centroid against parent {PARENT}\n")
    for g in GLYPHS:
        if g in PARENT:
            continue
        result = fractal_bounded(PARENT, g)
        print(f"  {g}: {len(result['tetra_index'])-1} genuine tetrahedra "
              f"(naturally terminated, no revisits)")
