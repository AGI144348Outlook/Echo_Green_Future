"""
Mesh Algorithm: merges multiple independent fractal-centroid explorations
(see fractal_centroid.py) into one unified structure using Union-Find.

Each of the "living" glyphs (the ones that ignite at all against a given
parent tetrahedron) starts as its own component. All of them expand
simultaneously in round-robin order, sharing ONE global Tetrahedron
index and ONE global usage budget (not one each). Whenever two
different glyphs' branches independently discover the identical
tetrahedron, their components are unioned.

SESSION RESULT: against parent (נ,ת,כ,ח) with the 8 living glyphs
(ע,ר,ס,ש,מ,ל,ה,ד), all 8 merged into a SINGLE connected component --
351 total distinct tetrahedra, 312 mesh (union) events. The merging was
not gradual; a handful of "confluence" tetrahedra (e.g. {ה,כ,נ,ת}) each
pulled in multiple unrelated pairs at once, meaning there is a small
number of real structural junctions doing most of the connecting work,
not many one-to-one handshakes.
"""
import json
from itertools import combinations, permutations
from collections import defaultdict, deque

with open("../../data/processed/bdb_roots.json", encoding="utf-8") as f:
    roots = json.load(f)

GLYPHS = list('אבגדהוזחטיכלמנסעפצקרשת')
MOTHERS = set('אמש')
DOUBLES = set('בגדכפרת')
SIMPLES = set(GLYPHS) - MOTHERS - DOUBLES


def make_cap_function(budget_base=3000):
    simple_cap = budget_base / len(SIMPLES)
    double_cap = 2 * simple_cap
    mother_cap = 3 * double_cap

    def cap_for(g):
        if g in MOTHERS:
            return mother_cap
        if g in DOUBLES:
            return double_cap
        return simple_cap
    return cap_for


def real_flags_for(letters):
    return [''.join(p) for p in set(permutations(letters)) if ''.join(p) in roots]


def sub_tet_closes(centroid, three):
    if not real_flags_for(three):
        return False
    return all(real_flags_for((centroid,) + pair) for pair in combinations(three, 2))


class UnionFind:
    def __init__(self, items):
        self.parent = {x: x for x in items}

    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[ra] = rb

    def components(self):
        groups = defaultdict(list)
        for x in self.parent:
            groups[self.find(x)].append(x)
        return list(groups.values())


def mesh(parent, living_glyphs, budget_base=3000, relation_bonus=None, bias_weight=0.0):
    """Runs all living_glyphs' fractal explorations simultaneously against
    a shared global Tetrahedron index and shared usage budget. Optional
    relation_bonus + bias_weight let a learned ontology (see
    feedback_loops.py) bias candidate selection."""
    relation_bonus = relation_bonus or {}
    cap_for = make_cap_function(budget_base)
    uf = UnionFind(living_glyphs)
    usage = defaultdict(int)
    for g in parent:
        usage[g] += 1
    for g in living_glyphs:
        usage[g] += 1

    tetra_index = {frozenset(parent): None}
    mesh_events = []

    def score(c, outer):
        base = len([1 for pair in combinations(outer, 2) if real_flags_for((c,) + pair)])
        bonus = sum(relation_bonus.get(tuple(sorted((c, v))), 0) for v in outer) * bias_weight
        return base + bonus

    queues = {g: deque([(g, parent)]) for g in living_glyphs}
    active = True
    while active:
        active = False
        for g in living_glyphs:
            if not queues[g]:
                continue
            active = True
            centroid, outer = queues[g].popleft()
            for three in combinations(outer, 3):
                if sub_tet_closes(centroid, three):
                    candidates = [c for c in GLYPHS if c not in three and c != centroid
                                  and usage[c] < cap_for(c)]
                    if not candidates:
                        continue
                    best = max(candidates, key=lambda c: score(c, (centroid,) + three))
                    if score(best, (centroid,) + three) <= 0:
                        continue
                    new_tetra = frozenset((centroid,) + three)
                    if new_tetra in tetra_index:
                        owner = tetra_index[new_tetra]
                        if owner is not None and owner != g:
                            uf.union(g, owner)
                            mesh_events.append((g, owner, sorted(new_tetra)))
                        continue
                    tetra_index[new_tetra] = g
                    usage[best] += 1
                    queues[g].append((best, (centroid,) + three))

    return {"tetra_index": tetra_index, "mesh_events": mesh_events, "components": uf.components()}


if __name__ == "__main__":
    PARENT = ('נ', 'ת', 'כ', 'ח')
    LIVING = ['ע', 'ר', 'ס', 'ש', 'מ', 'ל', 'ה', 'ד']
    result = mesh(PARENT, LIVING)
    print(f"Tetrahedra: {len(result['tetra_index'])}")
    print(f"Mesh events: {len(result['mesh_events'])}")
    print(f"Final components: {result['components']}")
