"""
Isolate C, E, and D individually against H's baseline scoring, same
seed each time, so it's clear which constraint does what instead of
seeing only their combined (over-constrained) effect.
"""
import json, re
from collections import defaultdict
from itertools import combinations
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize
from lattice_sequential import canon

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)

NOISE_MARKERS = ["proper name", "son of", "daughter of", "father of", "a levite",
                  "descendant of", "chief of", "city in", "in judah", "in benjamin",
                  "in simeon", "in babylonia"]
def is_noise(pos, gloss):
    text = f"{pos} {gloss}".lower()
    return any(m in text for m in NOISE_MARKERS)

clean = {r: (pos, gloss) for r, (pos, gloss) in raw_roots.items() if not is_noise(pos, gloss)}

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    return [w.strip("()[].;:") for w in words if w.strip("()[].;:")][:3]

ROOTS = {r: make_tags(pos, g) for r, (pos, g) in clean.items()}
GLOSS = {r: g for r, (pos, g) in clean.items()}

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index

vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

def flag_stems(f):
    return {canon(s, stem_m.slots) for s in flag_m.flags[f]["stems"]}

THEMES = {
    "perception_cognition": {"see", "hear", "know", "understand", "perceive", "look", "appear", "think", "remember", "learn", "consider"},
    "motion": {"go", "come", "walk", "run", "flee", "move", "turn", "travel", "wander", "pass", "depart"},
    "speech_communication": {"speak", "say", "call", "cry", "tell", "proclaim", "utter", "answer", "sing", "declare"},
    "emotion": {"love", "hate", "fear", "joy", "anger", "grieve", "desire", "delight", "rejoice", "mourn", "afraid"},
}
def theme_hits(gloss):
    tokens = set(re.findall(r"[a-z]+", gloss.lower()))
    return {t for t, words in THEMES.items() if tokens & words}

def is_exact_pyramid(quad):
    stems = set()
    for r in quad:
        stems.update(flag_stems(r))
    if len(stems) != 6:
        return False
    pair_shared = sum(1 for a, b in combinations(quad, 2) if flag_stems(a) & flag_stems(b))
    return pair_shared >= 3


def run(seed, use_C=False, use_E=False, use_D=False, max_copies=2, max_bricks=60):
    laid = {canon(seed, stem_m.slots)}
    closed = set()
    for f in flag_m.flags:
        if flag_stems(f) <= laid:
            closed.add(f)
    stem_budget = defaultdict(lambda: max_copies)
    region_tags = set()
    for f in closed:
        region_tags.update(flag_m.flags[f]["tags"])

    stop_reason = "max_bricks reached"

    for step in range(max_bricks):
        frontier = defaultdict(set)
        for stem in laid:
            if use_E and stem_budget[stem] <= 0:
                continue
            for f in index.stem_to_flags.get(stem, set()):
                if f in closed:
                    continue
                for s in flag_stems(f):
                    if s not in laid:
                        frontier[s].add((stem, f))

        if not frontier:
            stop_reason = "frontier exhausted"
            break

        if use_C and region_tags:
            gated = {}
            for cand, sources in frontier.items():
                ok = {(s, f) for s, f in sources if set(flag_m.flags[f]["tags"]) & region_tags}
                if ok:
                    gated[cand] = ok
            if not gated:
                stop_reason = "tag-overlap gate blocked all candidates"
                break
            frontier = gated

        def score(cand):
            flags = {f for _, f in frontier[cand]}
            themes_touched, total_hits = set(), 0
            for f in flags:
                th = theme_hits(GLOSS.get(f, ""))
                themes_touched |= th
                total_hits += len(th)
            return (len(themes_touched), total_hits, len(flags))

        choice = max(frontier, key=score)
        sources = frontier[choice]
        laid.add(choice)
        if use_E:
            for stem, _ in sources:
                stem_budget[stem] -= 1

        newly_closed = set()
        for f in flag_m.flags:
            if f not in closed and flag_stems(f) <= laid:
                closed.add(f)
                newly_closed.add(f)
                region_tags.update(flag_m.flags[f]["tags"])

        if use_D and len(closed) >= 4:
            found = next((q for q in combinations(closed, 4) if is_exact_pyramid(q)), None)
            if found:
                stop_reason = f"exact pyramid closed at {sorted(found)}"
                return {"bricks": laid, "flags": closed, "stop": stop_reason}

    return {"bricks": laid, "flags": closed, "stop": stop_reason}


SEED = ("א", "ה")
variants = [
    ("baseline (H only, no constraints)", dict(use_C=False, use_E=False, use_D=False)),
    ("+ C only (tag-overlap admission gate)", dict(use_C=True, use_E=False, use_D=False)),
    ("+ E only (per-stem reuse budget)", dict(use_C=False, use_E=True, use_D=False)),
    ("+ D only (stop at first exact pyramid)", dict(use_C=False, use_E=False, use_D=True)),
]

print(f"=== Isolating C, E, D individually, seed {SEED} ===\n")
for name, kwargs in variants:
    r = run(SEED, **kwargs)
    print(f"{name}")
    print(f"  bricks: {len(r['bricks'])}, flags closed: {len(r['flags'])}, stopped because: {r['stop']}")
    print(f"  flags: {sorted(r['flags'])}")
    print()
