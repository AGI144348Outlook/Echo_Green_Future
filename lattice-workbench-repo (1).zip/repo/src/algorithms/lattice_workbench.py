"""
Manual workbench: expose the frontier at each laid stem (candidate
next-stems + which flag/gloss motivates each) so a region can be built
by deliberate choice rather than the automated 'advances the most
flags' heuristic. I lay each brick myself and record why.
"""
import json, re
from collections import defaultdict
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize
from lattice_sequential import canon

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    return [w.strip("()[].;:") for w in words if w.strip("()[].;:")][:3]

ROOTS = {root: make_tags(pos, gloss) for root, (pos, gloss) in raw_roots.items()}
GLOSS = {root: gloss for root, (pos, gloss) in raw_roots.items()}

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index

vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

def flag_stems(f):
    return {canon(s, stem_m.slots) for s in flag_m.flags[f]["stems"]}

def workbench(laid, closed_flags):
    """Show, for every laid stem, what's on the frontier: candidate
    next-stems, which flag would motivate laying it, and that flag's
    gloss -- the human-readable version of what algo F computes
    numerically."""
    frontier = defaultdict(set)  # candidate_stem -> set of (via_flag, gloss)
    for stem in laid:
        for f in index.stem_to_flags.get(stem, set()):
            if f in closed_flags:
                continue
            for s in flag_stems(f):
                if s not in laid:
                    frontier[s].add((f, GLOSS.get(f, "")))
    return frontier

def lay(laid, closed_flags, stem):
    laid.add(stem)
    for f in flag_m.flags:
        if f not in closed_flags and flag_stems(f) <= laid:
            closed_flags.add(f)
    return laid, closed_flags


if __name__ == "__main__":
    # Seed choice: I'm picking (א,ה) deliberately -- both letters are
    # guttural/weak radicals that show up constantly in verbs of
    # perception, motion and speech, so the frontier should offer a
    # thematically rich set of choices rather than random noise.
    laid = set()
    closed = set()
    laid, closed = lay(laid, closed, canon(('א','ה'), stem_m.slots))
    print("SEED:", sorted(laid), "-- chosen for high branching (guttural pair)\n")

    for step in range(8):
        frontier = workbench(laid, closed)
        if not frontier:
            print("Frontier empty -- stopping.")
            break
        print(f"--- Step {step+1}: candidates on the frontier ---")
        for cand, via in sorted(frontier.items(), key=lambda kv: -len(kv[1])):
            via_list = sorted(via, key=lambda t: t[0])[:3]
            desc = "; ".join(f"{f}={g}" for f, g in via_list)
            print(f"  {cand}  (via {len(via)} flag(s): {desc})")

        # --- MY CHOICE (reasoned, not the greedy max-count heuristic) ---
        # I'm reading the glosses, not just counting. I want the region
        # to cohere around a semantic thread -- perception/cognition --
        # rather than just whatever stem touches the most flags.
        choice, reason = None, None
        for cand, via in frontier.items():
            for f, g in via:
                gl = g.lower()
                if any(w in gl for w in ["see", "hear", "know", "understand", "perceive", "look", "appear"]):
                    choice, reason = cand, f"{f} ({g}) -- fits the perception/cognition thread"
                    break
            if choice:
                break
        if not choice:
            # fall back to the candidate with the richest single gloss
            choice = max(frontier, key=lambda c: len(next(iter(frontier[c]))[1]))
            f, g = next(iter(frontier[choice]))
            reason = f"{f} ({g}) -- no perception hit this round, picked richest gloss instead"

        print(f"  >> LAYING {choice}  because: {reason}\n")
        laid, closed = lay(laid, closed, choice)

        if len(closed) >= 4 and len(laid) >= 6:
            print(f"REGION CLOSED after step {step+1}")
            break

    print("\n=== Final hand-built region ===")
    print(f"Bricks laid ({len(laid)}):", sorted(laid))
    print(f"Flags closed ({len(closed)}):")
    for f in sorted(closed):
        print(f"  {f}  -- {GLOSS.get(f,'')}")
