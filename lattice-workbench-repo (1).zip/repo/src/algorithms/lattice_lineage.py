"""
Lineage-tracked edge replanting.

Root seed רא grows exactly as before (live, on-demand differentiation
via the Flag/Stem Matrices, category-propagating, full alphabet).
Whenever a category-thread genuinely dies -- differentiate() returns
no further unlaid candidates for that (stem, category) token -- that
stem is tagged an EDGE. A new seed is planted there, using whichever
OTHER category actually lives at that edge stem (not yet used in this
lineage). Its lineage tag chains back to the root: (רא)-(edge_stem),
and if it dies at its own edge, -(edge_stem2), etc.

רא itself never stops being the root of the tree -- every generation
is a labeled child of it, not an independent lattice.
"""
import json, re
from collections import defaultdict
from lattice_prototype import VertexMatrix, FlagMatrix, StemMatrix, RadialStemMatrix, Index, GLYPHS, normalize

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)
with open("category_matrix.json", encoding="utf-8") as f:
    CATEGORY = json.load(f)

NOISE_MARKERS = ["proper name", "son of", "daughter of", "father of", "a levite",
                  "descendant of", "chief of", "city in", "in judah", "in benjamin",
                  "in simeon", "in babylonia"]
def is_noise(pos, gloss):
    return any(m in f"{pos} {gloss}".lower() for m in NOISE_MARKERS)

clean = {r: (pos, gloss) for r, (pos, gloss) in raw_roots.items() if not is_noise(pos, gloss)}

def make_tags(pos, gloss):
    words = re.split(r"[,\s]+", gloss.lower())
    return [w.strip("()[].;:") for w in words if w.strip("()[].;:")][:3]

ROOTS = {r: make_tags(pos, g) for r, (pos, g) in clean.items()}
GLOSS = {r: g for r, (pos, g) in clean.items()}

def build_pipeline(roots):
    vertex_m = VertexMatrix(GLYPHS); flag_m = FlagMatrix(); stem_m = StemMatrix(GLYPHS)
    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3 or any(g not in vertex_m.nodes for g in glyphs):
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)
    radial_m = RadialStemMatrix(stem_m); index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index

vertex_m, flag_m, stem_m, radial_m, index = build_pipeline(ROOTS)

def canonical_stem(a, b):
    return tuple(sorted((a, b)))

def differentiate(stem):
    a, b = stem
    flags = index.stem_to_flags.get((a, b), set()) | index.stem_to_flags.get((b, a), set())
    by_cat = defaultdict(set)
    for f in flags:
        by_cat[CATEGORY.get(f, "(untagged)")].add(f)
    return by_cat


def grow_thread(seed_stem, seed_cat, global_laid_stems, max_bricks=80):
    """Grow ONE category-thread from one stem until it genuinely dies.
    Returns the stems it laid, flags it closed, and the dead-end
    (edge) stems where no further same-category candidate existed."""
    laid = {seed_stem}
    closed_here = set()
    edges = set()

    for step in range(max_bricks):
        frontier = defaultdict(set)
        for stem in laid:
            by_cat = differentiate(stem)
            for f in by_cat.get(seed_cat, set()):
                for s in flag_m.flags[f]["stems"]:
                    cs = canonical_stem(*s)
                    if cs not in laid and cs not in global_laid_stems:
                        frontier[cs].add(f)
        if not frontier:
            edges.add(seed_stem if step == 0 else next(iter(laid)))
            break
        choice = max(frontier, key=lambda k: len(frontier[k]))
        laid.add(choice)

    # find true dead-end stems: laid stems whose OWN category-thread
    # has no unlaid same-category candidate left
    for stem in laid:
        by_cat = differentiate(stem)
        has_open_path = False
        for f in by_cat.get(seed_cat, set()):
            for s in flag_m.flags[f]["stems"]:
                cs = canonical_stem(*s)
                if cs not in laid and cs not in global_laid_stems:
                    has_open_path = True
        if not has_open_path:
            edges.add(stem)

    return laid, edges


def lineage_grow(root_stem, root_label, max_generations=3, max_children_per_gen=3):
    tree = []
    global_laid = set()
    frontier_seeds = [(root_stem, root_label, set())]  # (stem, lineage_label, used_categories_in_this_lineage)

    for generation in range(max_generations):
        next_frontier = []
        for stem, label, used_cats in frontier_seeds:
            by_cat = differentiate(stem)
            available_cats = [c for c in by_cat if c not in used_cats]
            if not available_cats:
                continue
            # grow the strongest available category thread from this stem
            cat = max(available_cats, key=lambda c: len(by_cat[c]))
            laid, edges = grow_thread(stem, cat, global_laid)
            global_laid |= laid
            tree.append({"label": label, "stem": stem, "category": cat,
                          "stems_laid": len(laid), "edges": edges})

            for edge_stem in list(edges)[:max_children_per_gen]:
                child_label = f"{label}-{edge_stem}"
                next_frontier.append((edge_stem, child_label, used_cats | {cat}))
        frontier_seeds = next_frontier
        if not frontier_seeds:
            break

    return tree


ROOT_STEM = ("ר", "א")
tree = lineage_grow(ROOT_STEM, "(רא)")

print("=== Lineage tree rooted at (רא) ===\n")
for node in tree:
    print(f"{node['label']}  category={node['category']}  stem={node['stem']}")
    print(f"   -> {node['stems_laid']} stems laid, {len(node['edges'])} edge(s) found: {sorted(node['edges'])}")
print()
print(f"Total distinct lineage nodes grown: {len(tree)}")
