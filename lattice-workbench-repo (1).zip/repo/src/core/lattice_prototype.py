"""
Prototype: Triconsonantal Root Lattice Pipeline
=================================================

Implements the Matrix/Index architecture as described:
  - Glyphic Nodal Vertex Matrix   (22 glyphs as parent nodes)
  - Stem Matrix                   (484-slot: every ordered 2-glyph combo)
  - Triangular Flag Matrix        (roots decomposed into 3-glyph triangles,
                                    carrying lexical/semantic payload)
  - Radial Stem Matrix            (Stem x Flag join -> differentiated stems)
  - Bidirectional Index           (Vertex <-> Stem <-> Flag)

Then: 5 variant "stitching" algorithms that try to grow polyhedral
Regions (min. 6 stems / 4 flags, per the pyramid rule) out of the
Radial Stem Matrix, allowing multiple copies ("bricks") of a stem to
be instantiated when needed.

This is a structural/computational prototype only -- the semantic tags
attached to sample roots are placeholder metadata for testing region
formation, not linguistic claims.
"""

from collections import defaultdict
from itertools import combinations
import random

random.seed(7)

# ---------------------------------------------------------------------------
# 0. Alphabet + sample data
# ---------------------------------------------------------------------------

GLYPHS = list("אבגדהוזחטיכלמנסעפצקרשת")  # 22 letters
assert len(GLYPHS) == 22

# Final-form letters normalize to their base glyph (22-glyph alphabet only)
FINAL_FORMS = {"ך": "כ", "ם": "מ", "ן": "נ", "ף": "פ", "ץ": "צ"}


def normalize(word):
    return "".join(FINAL_FORMS.get(ch, ch) for ch in word)

# Sample triconsonantal roots with placeholder semantic tags (for testing
# region formation only -- not asserted etymology).
SAMPLE_ROOTS = {
    "כתב": ["record", "inscribe"],
    "שמר": ["guard", "keep"],
    "מלך": ["rule", "authority"],
    "למד": ["learn", "cognition"],
    "אהב": ["affect", "bond"],
    "זכר": ["memory", "cognition"],
    "דבר": ["speech", "communication"],
    "קרא": ["call", "communication"],
    "שלח": ["send", "motion"],
    "פתח": ["open", "motion"],
    "סגר": ["close", "guard"],
    "ראה": ["perceive", "cognition"],
    "שמע": ["perceive", "communication"],
    "ילד": ["bond", "origin"],
    "עבד": ["labor", "authority"],
}

# ---------------------------------------------------------------------------
# 1. Core Matrices + Index
# ---------------------------------------------------------------------------

class VertexMatrix:
    """22 glyph nodes. Each accumulates the semantic/lexical tags routed
    to it once a root's triangular continuity is broken."""
    def __init__(self, glyphs):
        self.nodes = {g: {"tags": set(), "roots": set()} for g in glyphs}

    def deposit(self, glyph, root, tags):
        self.nodes[glyph]["tags"].update(tags)
        self.nodes[glyph]["roots"].add(root)


class FlagMatrix:
    """Triangular reconfiguration of each root: 3 glyphs -> 3 stems,
    load-bearing for lexical/semantic payload."""
    def __init__(self):
        self.flags = {}  # root -> dict(glyphs, stems, tags)

    def add(self, root, glyphs, tags):
        g1, g2, g3 = glyphs
        stems = [(g1, g2), (g2, g3), (g1, g3)]
        self.flags[root] = {"glyphs": glyphs, "stems": stems, "tags": set(tags)}


class StemMatrix:
    """484 ordered-pair slots (22x22). Undifferentiated until joined
    with the Flag Matrix."""
    def __init__(self, glyphs):
        self.slots = {(a, b): [] for a in glyphs for b in glyphs}  # -> list of flags referencing it

    def reference(self, stem, root):
        a, b = stem
        # normalize direction: store under both orderings' canonical slot
        if stem not in self.slots:
            stem = (b, a)
        self.slots[stem].append(root)


class RadialStemMatrix:
    """Differentiated stems: Stem Matrix slot joined bidirectionally with
    the Flag Matrix (the set of roots/flags that reference it)."""
    def __init__(self, stem_matrix):
        self.radial = {stem: set(flags) for stem, flags in stem_matrix.slots.items() if flags}


class Index:
    """Bidirectional lookups across Vertex <-> Stem <-> Flag."""
    def __init__(self, vertex_m, stem_m, flag_m):
        self.vertex_to_flags = defaultdict(set)
        self.flag_to_vertices = defaultdict(set)
        self.stem_to_flags = defaultdict(set)
        self.flag_to_stems = defaultdict(set)
        self.vertex_to_stems = defaultdict(set)
        self.stem_to_vertices = defaultdict(set)

        for root, flag in flag_m.flags.items():
            for g in flag["glyphs"]:
                self.vertex_to_flags[g].add(root)
                self.flag_to_vertices[root].add(g)
            for stem in flag["stems"]:
                canon = stem if stem in stem_m.slots else (stem[1], stem[0])
                self.stem_to_flags[canon].add(root)
                self.flag_to_stems[root].add(canon)
                for g in canon:
                    self.vertex_to_stems[g].add(canon)
                    self.stem_to_vertices[canon].add(g)


def build_pipeline(roots=SAMPLE_ROOTS):
    vertex_m = VertexMatrix(GLYPHS)
    flag_m = FlagMatrix()
    stem_m = StemMatrix(GLYPHS)

    for root, tags in roots.items():
        glyphs = list(normalize(root))
        if len(glyphs) != 3:
            continue
        flag_m.add(root, glyphs, tags)
        for g in glyphs:
            vertex_m.deposit(g, root, tags)
        for stem in flag_m.flags[root]["stems"]:
            stem_m.reference(stem, root)

    radial_m = RadialStemMatrix(stem_m)
    index = Index(vertex_m, stem_m, flag_m)
    return vertex_m, flag_m, stem_m, radial_m, index


# ---------------------------------------------------------------------------
# 2. Five stitching algorithm variants
# ---------------------------------------------------------------------------
# A "region" = a polyhedron: a set of >=4 flags whose shared stems
# perimeter an enclosed semantic space (per spec: min. pyramid = 3 base
# flags... actually 4 flags / 6 stems total for the pyramid case).

def shared_stem_pairs(flag_m):
    """All (root_a, root_b, shared_stem_count) where two flags share
    at least one stem."""
    pairs = []
    roots = list(flag_m.flags.keys())
    for r1, r2 in combinations(roots, 2):
        s1 = set(flag_m.flags[r1]["stems"])
        s1 = {tuple(sorted(s)) for s in s1}
        s2 = {tuple(sorted(s)) for s in flag_m.flags[r2]["stems"]}
        shared = s1 & s2
        if shared:
            pairs.append((r1, r2, len(shared)))
    return pairs


def algo_A_greedy_stem_closure(flag_m, index, min_flags=4, min_stems=6):
    """THIS ONE (as discussed): grow regions by greedily clustering
    flags that share stems (union-find), then keep clusters that meet
    the minimum pyramid threshold (>=4 flags, >=6 total distinct stems).
    Allows a stem to be 'reused' (multiple bricks) across regions."""
    parent = {r: r for r in flag_m.flags}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for r1, r2, _ in shared_stem_pairs(flag_m):
        union(r1, r2)

    clusters = defaultdict(set)
    for r in flag_m.flags:
        clusters[find(r)].add(r)

    regions = []
    for cluster in clusters.values():
        stems = set()
        for r in cluster:
            stems.update(tuple(sorted(s)) for s in flag_m.flags[r]["stems"])
        if len(cluster) >= min_flags and len(stems) >= min_stems:
            regions.append({"flags": cluster, "stems": stems})
    return regions


def algo_B_vertex_adjacency(flag_m, index, min_flags=4):
    """Variance 1: looser grouping via shared VERTICES instead of stems."""
    parent = {r: r for r in flag_m.flags}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    roots = list(flag_m.flags.keys())
    for r1, r2 in combinations(roots, 2):
        v1 = set(flag_m.flags[r1]["glyphs"])
        v2 = set(flag_m.flags[r2]["glyphs"])
        if v1 & v2:
            union(r1, r2)

    clusters = defaultdict(set)
    for r in flag_m.flags:
        clusters[find(r)].add(r)

    return [{"flags": c, "stems": None} for c in clusters.values() if len(c) >= min_flags]


def algo_C_semantic_weighted(flag_m, index, min_flags=4, min_stems=6, tag_overlap=1):
    """Variance 2: only connect two flags if they share a stem AND
    share at least `tag_overlap` semantic tags -- regions must be both
    structurally and semantically coherent."""
    parent = {r: r for r in flag_m.flags}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for r1, r2, _ in shared_stem_pairs(flag_m):
        t1 = flag_m.flags[r1]["tags"]
        t2 = flag_m.flags[r2]["tags"]
        if len(t1 & t2) >= tag_overlap:
            union(r1, r2)

    clusters = defaultdict(set)
    for r in flag_m.flags:
        clusters[find(r)].add(r)

    regions = []
    for cluster in clusters.values():
        stems = set()
        for r in cluster:
            stems.update(tuple(sorted(s)) for s in flag_m.flags[r]["stems"])
        if len(cluster) >= min_flags and len(stems) >= min_stems:
            regions.append({"flags": cluster, "stems": stems})
    return regions


def algo_D_strict_pyramid(flag_m, index):
    """Variance 3: conservative -- only accept EXACT 4-flag / 6-stem
    pyramids (3 base flags mutually sharing one stem each with a 4th
    apex flag), no looser transitive clustering."""
    roots = list(flag_m.flags.keys())
    regions = []
    for quad in combinations(roots, 4):
        stems = set()
        for r in quad:
            stems.update(tuple(sorted(s)) for s in flag_m.flags[r]["stems"])
        # pyramid rule: exactly 6 distinct stems shared across exactly 4 flags
        if len(stems) == 6:
            # require pairwise sharing (every flag shares >=1 stem with
            # at least one other, forming a connected tetrad)
            pair_shared = 0
            for a, b in combinations(quad, 2):
                sa = {tuple(sorted(s)) for s in flag_m.flags[a]["stems"]}
                sb = {tuple(sorted(s)) for s in flag_m.flags[b]["stems"]}
                if sa & sb:
                    pair_shared += 1
            if pair_shared >= 3:
                regions.append({"flags": set(quad), "stems": stems})
    return regions


def algo_E_multiplicity_bricks(flag_m, index, min_flags=4, min_stems=6, max_copies=3, trials=200):
    """Variance 4: explicit 'brick' model -- each stem can be
    instantiated as up to `max_copies` virtual bricks. Randomly sample
    flag subsets and check whether enough brick-copies exist to
    perimeter a region, simulating on-demand multiplicity."""
    stem_supply = defaultdict(lambda: max_copies)
    roots = list(flag_m.flags.keys())
    regions = []
    used_supply = defaultdict(int)

    for _ in range(trials):
        if len(roots) < min_flags:
            break
        candidate = set(random.sample(roots, min_flags))
        stems = set()
        for r in candidate:
            stems.update(tuple(sorted(s)) for s in flag_m.flags[r]["stems"])
        if len(stems) < min_stems:
            continue
        # check brick supply
        feasible = all(used_supply[s] < stem_supply[s] for s in stems)
        if feasible:
            for s in stems:
                used_supply[s] += 1
            regions.append({"flags": candidate, "stems": stems})
    # dedupe identical regions
    seen = set()
    unique = []
    for r in regions:
        key = frozenset(r["flags"])
        if key not in seen:
            seen.add(key)
            unique.append(r)
    return unique


# ---------------------------------------------------------------------------
# 3. Run + compare
# ---------------------------------------------------------------------------

def summarize(name, regions, flag_m):
    n = len(regions)
    if n == 0:
        print(f"[{name}] 0 regions formed")
        return
    avg_flags = sum(len(r["flags"]) for r in regions) / n
    stem_counts = [len(r["stems"]) for r in regions if r["stems"] is not None]
    avg_stems = sum(stem_counts) / len(stem_counts) if stem_counts else float("nan")
    print(f"[{name}] {n} region(s) | avg flags/region: {avg_flags:.1f} | avg stems/region: {avg_stems:.1f}")
    for i, r in enumerate(regions[:3]):
        print(f"    region {i+1}: {sorted(r['flags'])}")
    if n > 3:
        print(f"    ... +{n-3} more")


if __name__ == "__main__":
    vertex_m, flag_m, stem_m, radial_m, index = build_pipeline()

    print("=== Pipeline stats ===")
    print(f"Roots processed (flags): {len(flag_m.flags)}")
    print(f"Vertex Matrix nodes touched: {sum(1 for g in vertex_m.nodes if vertex_m.nodes[g]['roots'])} / {len(GLYPHS)}")
    print(f"Stem Matrix slots occupied: {sum(1 for s in stem_m.slots.values() if s)} / {len(stem_m.slots)}")
    print(f"Radial (differentiated) stems: {len(radial_m.radial)}")
    print()

    print("=== Algorithm A: greedy stem closure (the discussed approach) ===")
    regions_a = algo_A_greedy_stem_closure(flag_m, index)
    summarize("A: greedy stem closure", regions_a, flag_m)
    print()

    print("=== Algorithm B: vertex adjacency (variance) ===")
    regions_b = algo_B_vertex_adjacency(flag_m, index)
    summarize("B: vertex adjacency", regions_b, flag_m)
    print()

    print("=== Algorithm C: semantic-weighted stem closure (variance) ===")
    regions_c = algo_C_semantic_weighted(flag_m, index)
    summarize("C: semantic-weighted", regions_c, flag_m)
    print()

    print("=== Algorithm D: strict 4-flag/6-stem pyramid (variance) ===")
    regions_d = algo_D_strict_pyramid(flag_m, index)
    summarize("D: strict pyramid", regions_d, flag_m)
    print()

    print("=== Algorithm E: multiplicity/brick sampling (variance) ===")
    regions_e = algo_E_multiplicity_bricks(flag_m, index)
    summarize("E: multiplicity bricks", regions_e, flag_m)
