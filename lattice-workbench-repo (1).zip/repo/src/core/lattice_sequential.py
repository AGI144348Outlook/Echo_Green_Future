"""
Algorithm F: Sequential Frontier Stitching
===========================================

Implements the brick/rebar model as described:
  - A Stem and a Radial Stem are EQUAL WEIGHT as placed bricks (1 brick
    each). Differentiating a Stem into a Radial Stem doesn't add a
    brick -- it attaches a map.
  - The "map" is: for a laid Radial Stem, look at every Flag that
    touches it. Each such Flag's OTHER two stems are candidate next
    bricks (potential paths forward).
  - This is a sequential, one-brick-at-a-time placement process, not a
    batch clustering pass over the whole Flag Matrix.
  - A Region closes when enough Flags become fully perimetered (all 3
    of their stems have been laid as bricks) -- minimum 4 flags / 6
    distinct stems, per the pyramid rule.

Candidate-selection heuristic (a real design choice, stated plainly):
at each step, among the current frontier's candidate next-stems, we
lay down the one that appears in the most yet-unclosed flags -- i.e.
greedily prefer the brick most likely to help close multiple flags at
once. This is one reasonable policy, not the only one.
"""

from collections import deque, defaultdict
from lattice_prototype import build_pipeline, GLYPHS, SAMPLE_ROOTS


def canon(stem, stem_slots):
    return stem if stem in stem_slots else (stem[1], stem[0])


def sequential_stitch(flag_m, index, stem_m, seed_stem, min_flags=4, min_stems=6, max_bricks=30):
    seed_stem = canon(seed_stem, stem_m.slots)
    laid = {seed_stem}                      # bricks placed (stem == radial stem, 1 brick each)
    closed_flags = set()                    # flags fully perimetered by laid bricks
    frontier = deque([seed_stem])
    path = [{"brick": seed_stem, "reason": "seed"}]

    def flag_stems(f):
        return {canon(s, stem_m.slots) for s in flag_m.flags[f]["stems"]}

    def update_closed_flags():
        for f in flag_m.flags:
            if f not in closed_flags and flag_stems(f) <= laid:
                closed_flags.add(f)

    update_closed_flags()

    while frontier and len(laid) < max_bricks:
        current = frontier.popleft()
        touching_flags = index.stem_to_flags.get(current, set())

        # candidate next-bricks = the OTHER stems of every flag touching
        # the current (now-differentiated) radial stem
        candidate_counts = defaultdict(int)
        for f in touching_flags:
            if f in closed_flags:
                continue
            for s in flag_stems(f):
                if s not in laid:
                    candidate_counts[s] += 1  # tally how many open flags want this stem

        if not candidate_counts:
            continue  # dead end at this stem -- no unlaid paths out of it

        # heuristic: lay the candidate that would advance the most flags at once
        next_stem = max(candidate_counts, key=lambda s: candidate_counts[s])
        laid.add(next_stem)
        frontier.append(next_stem)
        path.append({"brick": next_stem, "reason": f"from {current}, advances {candidate_counts[next_stem]} flag(s)"})

        update_closed_flags()

        if len(closed_flags) >= min_flags and len(laid) >= min_stems:
            return {"closed": True, "bricks": laid, "closed_flags": closed_flags, "path": path}

    return {"closed": False, "bricks": laid, "closed_flags": closed_flags, "path": path}


if __name__ == "__main__":
    vertex_m, flag_m, stem_m, radial_m, index = build_pipeline()

    occupied_stems = [s for s, flags in stem_m.slots.items() if flags]
    print(f"Testing sequential stitching from all {len(occupied_stems)} occupied seed stems\n")

    results = []
    for seed in occupied_stems:
        r = sequential_stitch(flag_m, index, stem_m, seed)
        results.append((seed, r))

    closed = [r for _, r in results if r["closed"]]
    stalled = [r for _, r in results if not r["closed"]]

    print(f"Closed regions: {len(closed)} / {len(results)} seeds")
    print(f"Stalled (dead-ended before closure): {len(stalled)} / {len(results)}\n")

    if closed:
        best = max(closed, key=lambda r: len(r["closed_flags"]))
        print("=== Example CLOSED region (most flags closed) ===")
        print(f"Bricks laid: {len(best['bricks'])} -> {sorted(best['bricks'])}")
        print(f"Flags fully perimetered: {sorted(best['closed_flags'])}")
        print("Path taken:")
        for step in best["path"]:
            print(f"  {step['brick']}  <- {step['reason']}")
        print()

    if stalled:
        # show the stall that got furthest (most bricks laid before dying)
        worst = max(stalled, key=lambda r: len(r["bricks"]))
        print("=== Example STALLED walk (got furthest before dead-ending) ===")
        print(f"Seed: {worst['path'][0]['brick']}")
        print(f"Bricks laid before stalling: {len(worst['bricks'])} -> {sorted(worst['bricks'])}")
        print(f"Flags closed before stall: {sorted(worst['closed_flags'])} ({len(worst['closed_flags'])})")
        print()

    print("=== Distribution of bricks-laid-before-stopping across all seeds ===")
    from collections import Counter
    dist = Counter(len(r["bricks"]) for _, r in results)
    for n_bricks in sorted(dist):
        print(f"  {n_bricks} bricks: {dist[n_bricks]} seed(s)")
