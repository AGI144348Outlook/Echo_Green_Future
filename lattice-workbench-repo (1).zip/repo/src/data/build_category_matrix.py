"""
Category Matrix: WordNet's 45 fixed lexicographer categories, used as
the 'inert category list' the original spec called for (Vision,
Audio, Writing, etc.) -- except this one is a real, standard,
externally-defined taxonomy instead of something hand-picked.

Method: for each cleaned root, take its BDB part-of-speech (verb or
noun) to pick the right WordNet POS, look up each gloss word's most
common synset in that POS, and tally lexnames across the gloss. The
most frequent lexname becomes that root's category tag. Ties broken
by first occurrence -- this is a heuristic, not hand-verified sense
disambiguation.
"""
import json, re
from collections import defaultdict, Counter
from nltk.corpus import wordnet as wn

with open("bdb_roots.json", encoding="utf-8") as f:
    raw_roots = json.load(f)

NOISE_MARKERS = ["proper name", "son of", "daughter of", "father of", "a levite",
                  "descendant of", "chief of", "city in", "in judah", "in benjamin",
                  "in simeon", "in babylonia"]
def is_noise(pos, gloss):
    text = f"{pos} {gloss}".lower()
    return any(m in text for m in NOISE_MARKERS)

clean = {r: (pos, gloss) for r, (pos, gloss) in raw_roots.items() if not is_noise(pos, gloss)}

def wn_pos(bdb_pos):
    p = bdb_pos.lower()
    if "verb" in p:
        return wn.VERB
    if "noun" in p:
        return wn.NOUN
    if "adj" in p:
        return wn.ADJ
    return None

def categorize(pos, gloss):
    wpos = wn_pos(pos)
    words = [w.strip("()[].;:,") for w in re.split(r"[,\s]+", gloss.lower()) if w.strip("()[].;:,")]
    tally = Counter()
    for w in words:
        syns = wn.synsets(w, pos=wpos) if wpos else wn.synsets(w)
        if syns:
            tally[syns[0].lexname()] += 1
    if not tally:
        return None
    return tally.most_common(1)[0][0]

CATEGORY = {}   # root -> category (or None if untaggable)
for root, (pos, gloss) in clean.items():
    CATEGORY[root] = categorize(pos, gloss)

tagged = {r: c for r, c in CATEGORY.items() if c}
print(f"Tagged {len(tagged)} / {len(clean)} roots ({100*len(tagged)/len(clean):.0f}%)\n")

# Category Matrix: category -> set of roots (bidirectional with root -> category above)
CATEGORY_MATRIX = defaultdict(set)
for root, cat in tagged.items():
    CATEGORY_MATRIX[cat].add(root)

print("=== Category Matrix: roots per category (top 20 by size) ===")
for cat, roots in sorted(CATEGORY_MATRIX.items(), key=lambda kv: -len(kv[1]))[:20]:
    print(f"  {cat:20s} {len(roots):4d} roots")

print()
print("=== Sample: perception/cognition-relevant categories ===")
for cat in ["verb.cognition", "verb.perception", "verb.emotion", "verb.communication"]:
    roots = sorted(CATEGORY_MATRIX.get(cat, []))
    GLOSS = {r: g for r, (pos, g) in clean.items()}
    print(f"\n  [{cat}] ({len(roots)} roots) -- sample:")
    for r in roots[:8]:
        print(f"     {r}: {GLOSS.get(r,'')}")

with open("category_matrix.json", "w", encoding="utf-8") as f:
    json.dump({r: c for r, c in tagged.items()}, f, ensure_ascii=False)
print("\nSaved root->category map to category_matrix.json")
