"""
Extract triconsonantal root headwords from the unabridged Brown-Driver-Briggs
Hebrew Lexicon JSON (source: github.com/eliranwong/unabridged-BDB-Hebrew-lexicon),
INCLUDING the character-corruption fix discovered and applied during this session.

=== THE CORRUPTION ===
The source data has a font-mapping bug affecting a contiguous range of Strong's
numbers (roughly H6284+): every Pe (פ) in the Hebrew headword field was
silently replaced with Mem (מ), while the entry's own transliteration
("H6299. padah") stayed correct. This was discovered when פתח ("open") was
found completely missing, with a suspicious מתח ("spread out") sitting in
its place.

=== THE FIX ===
Entirely data-internal: for every entry whose transliteration starts with
"p" but whose Hebrew glyph starts with Mem, every Mem in that glyph is
un-substituted back to Pe. No external knowledge is used -- the source's
own transliteration field is the only ground truth.

=== THE SUBTLETY ===
A first-pass fix that simply deleted every Mem-glyph key touched by this
corruption was WRONG: several common Mem-words (מלא "be full", מלח "salt",
מלט "plaster") are legitimate, independently-encoded entries elsewhere in
the source that happen to collide, after corruption, with the same bare
spelling as a corrupted Pe-word. This script only removes a Mem key if NO
legitimate (transliteration genuinely starts with "m") record for that
exact spelling exists anywhere else in the source.

Run this against data/raw/DictBDB.json to reproduce data/processed/bdb_roots.json.
"""
import json
import re
import unicodedata

HEBREW_LETTERS = set('אבגדהוזחטיכלמנסעפצקרשתךםןףץ')
FINAL_FORMS = {'ך': 'כ', 'ם': 'מ', 'ן': 'נ', 'ף': 'פ', 'ץ': 'צ'}

FIRST_HEB_RE = re.compile(
    r'<heb><ref0 class="word" entry="([^"]+)"[^>]*><font[^>]*>[^<]*</font></ref0></heb>'
)
TWO_BOLD_RE = re.compile(r'<b>([^<]+)</b>\s*<b>([^<]+)</b>')
HEADER_P_RE = re.compile(r'<b>H\d+\.?\s*(p[a-z]+)</b>', re.IGNORECASE)
HEADER_ANY_RE = re.compile(r'<b>H\d+\.?\s*([a-zA-Z]+)</b>')
HEB_RE = re.compile(r'<heb><ref0 class="word" entry="([^"]+)"')


def bare_consonants(s: str) -> str:
    """Strip niqqud/cantillation (Unicode combining marks), keep only the
    22-letter consonantal skeleton, normalize final forms to base forms."""
    nfd = unicodedata.normalize('NFD', s)
    out = ''.join(c for c in nfd if c in HEBREW_LETTERS)
    return ''.join(FINAL_FORMS.get(c, c) for c in out)


def extract_base_roots(dictbdb_records):
    """Pass 1: standard extraction (matches the original session's method,
    before the corruption was discovered)."""
    roots = {}
    for rec in dictbdb_records:
        defhtml = rec.get('def', '')
        m = FIRST_HEB_RE.search(defhtml)
        if not m:
            continue
        bare = bare_consonants(m.group(1))
        if len(bare) != 3:
            continue
        rest = defhtml[m.end(): m.end() + 300]
        bm = TWO_BOLD_RE.search(rest)
        if not bm:
            continue
        pos, gloss = bm.group(1).strip(), bm.group(2).strip()
        gloss = re.sub(r'\[|\]', '', gloss)
        if bare not in roots:
            roots[bare] = [pos, gloss]
    return roots


def apply_pe_mem_correction(roots, dictbdb_records):
    """Pass 2: find and fix the Pe->Mem corruption, carefully preserving
    any legitimate Mem-word that happens to collide with a corrupted
    spelling."""
    recovered = {}
    corrupted_originals = set()
    for rec in dictbdb_records:
        defhtml = rec.get('def', '')
        hm = HEADER_P_RE.search(defhtml)
        if not hm:
            continue
        xm = HEB_RE.search(defhtml)
        if not xm:
            continue
        b = bare_consonants(xm.group(1))
        if not b or b[0] != 'מ':
            continue
        corrupted_originals.add(b)
        corrected = ''.join(FINAL_FORMS.get(c, c) for c in b.replace('מ', 'פ'))
        if len(corrected) != 3:
            continue
        rest = defhtml[xm.end(): xm.end() + 300]
        bm = TWO_BOLD_RE.search(rest)
        if not bm:
            continue
        pos, gloss = bm.group(1).strip(), bm.group(2).strip()
        if corrected not in recovered:
            recovered[corrected] = [pos, gloss]

    # remove corrupted duplicates...
    for k in corrupted_originals:
        if k in roots:
            del roots[k]
    # ...then restore any that turn out to be legitimate independent Mem-words
    for key in corrupted_originals:
        for rec in dictbdb_records:
            defhtml = rec.get('def', '')
            xm = HEB_RE.search(defhtml)
            if not xm or bare_consonants(xm.group(1)) != key:
                continue
            hm = HEADER_ANY_RE.search(defhtml)
            if not hm:
                continue
            if hm.group(1).lower().startswith('m'):
                rest = defhtml[xm.end(): xm.end() + 300]
                bm = TWO_BOLD_RE.search(rest)
                if bm:
                    pos, gloss = bm.group(1).strip(), bm.group(2).strip()
                    roots[key] = [pos, gloss]
                break

    for k, v in recovered.items():
        if k not in roots:
            roots[k] = v

    return roots, len(corrupted_originals), len(recovered)


def is_noise(pos, gloss):
    markers = ["proper name", "son of", "daughter of", "father of", "a levite",
               "descendant of", "chief of", "city in", "in judah", "in benjamin",
               "in simeon", "in babylonia"]
    text = f"{pos} {gloss}".lower()
    return any(m in text for m in markers)


if __name__ == "__main__":
    with open("../../data/raw/DictBDB.json", encoding="utf-8") as f:
        data = json.load(f)

    roots = extract_base_roots(data)
    print(f"Pass 1 (base extraction): {len(roots)} roots")

    roots, n_corrupted, n_recovered = apply_pe_mem_correction(roots, data)
    print(f"Pass 2 (Pe/Mem correction): removed/checked {n_corrupted} corrupted "
          f"keys, recovered {n_recovered} corrected Pe-roots")
    print(f"Final: {len(roots)} roots")

    with open("../../data/processed/bdb_roots.json", "w", encoding="utf-8") as f:
        json.dump(roots, f, ensure_ascii=False)
