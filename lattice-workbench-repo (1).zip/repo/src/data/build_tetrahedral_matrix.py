"""
Tetrahedral Matrix: finds every real closed tetrahedron (4 flags whose
combined stems total exactly 6, with pairwise stem-sharing on at least 3
of the 6 possible pairs) and cross-indexes it against the Category Matrix.

Scoped search: only checks combinations within a single stem's own
flag-list (tractable), skipping "mega-hub" stems with >25 referencing
flags. This means the result is NOT exhaustive -- it is blind to any
tetrahedron only reachable via a very densely-connected stem (this
session found strong evidence those are exactly the Resh-heavy stems).
"""
import json
from collections import defaultdict, Counter
from itertools import combinations

with open("../../data/processed/bdb_roots.json", encoding="utf-8") as f:
    roots = json.load(f)
with open("../../data/processed/category_matrix.json", encoding="utf-8") as f:
    CATEGORY = json.load(f)


def canonical_stem(a, b):
    return tuple(sorted((a, b)))


def flag_stems(root):
    return {canonical_stem(root[0], root[1]), canonical_stem(root[1], root[2]),
            canonical_stem(root[0], root[2])}


def is_exact_pyramid(quad):
    stems = set()
    for r in quad:
        stems.update(flag_stems(r))
    if len(stems) != 6:
        return False
    shared = sum(1 for a, b in combinations(quad, 2) if flag_stems(a) & flag_stems(b))
    return shared >= 3


def build_stem_index(roots):
    idx = defaultdict(list)
    for r in roots:
        if len(r) != 3:
            continue
        for s in flag_stems(r):
            idx[s].append(r)
    return idx


def find_tetrahedra(roots, max_hub_size=25):
    stem_index = build_stem_index(roots)
    seen = set()
    tetra_matrix = {}
    skipped = 0
    for stem, flags in stem_index.items():
        flags = list(set(flags))
        if len(flags) < 4:
            continue
        if len(flags) > max_hub_size:
            skipped += 1
            continue
        for quad in combinations(flags, 4):
            key = frozenset(quad)
            if key in seen:
                continue
            if is_exact_pyramid(quad):
                seen.add(key)
                cats = [CATEGORY.get(f) for f in quad]
                tetra_matrix['|'.join(quad)] = cats
    return tetra_matrix, skipped


if __name__ == "__main__":
    tetra_matrix, skipped = find_tetrahedra(roots)
    print(f"Tetrahedra found: {len(tetra_matrix)} (skipped {skipped} mega-hub stems)")

    category_to_tetra = defaultdict(list)
    lead_clusters = defaultdict(list)
    for key, cats in tetra_matrix.items():
        cat_counts = Counter(c for c in cats if c)
        for c in cat_counts:
            category_to_tetra[c].append(key)
        if cat_counts:
            dom_cat, dom_count = cat_counts.most_common(1)[0]
            if dom_count >= 3:
                lead_clusters[dom_cat].append(key)

    print(f"Categories represented: {len(category_to_tetra)}")
    print(f"Lead clusters (3+ of 4 flags sharing a category): {len(lead_clusters)}")
    for cat, tetras in sorted(lead_clusters.items(), key=lambda kv: -len(kv[1])):
        print(f"  [{cat}] {len(tetras)} lead tetrahedron(s)")

    with open("../../data/processed/tetra_matrix.json", "w", encoding="utf-8") as f:
        json.dump(tetra_matrix, f, ensure_ascii=False)
