"""
Anagram Matrix: groups every real root by its unordered 3-letter set, so
that e.g. גדל/גלד/דגל/דלג (4 different real words, same 3 letters, 4 of
the 6 possible orderings) are recognized as a family instead of 4
unrelated flags.

Cross-indexed with:
  - Stem Matrix: verified (not assumed) that every member of a family
    shares the exact same 3 possible undirected stems -- true by
    construction, but checked against real data here.
  - Category Matrix: measures whether a family's members tend to share
    meaning (coherent) or scatter across unrelated categories (the
    session found scattering to be the overwhelming majority: 361
    scattered families vs. 16 coherent ones).
"""
import json
from itertools import combinations
from collections import defaultdict

with open("../../data/processed/bdb_roots.json", encoding="utf-8") as f:
    roots = json.load(f)
with open("../../data/processed/category_matrix.json", encoding="utf-8") as f:
    CATEGORY = json.load(f)


def canonical_stem(a, b):
    return tuple(sorted((a, b)))


def build_anagram_matrix(roots):
    matrix = defaultdict(list)
    for r in roots:
        if len(r) == 3 and len(set(r)) == 3:
            matrix[frozenset(r)].append(r)
    return matrix


def cross_index(matrix, roots, category):
    root_to_family = {}
    family_category_diversity = {}
    stem_mismatches = 0

    for key, members in matrix.items():
        family_str = ''.join(sorted(key))
        for r in members:
            root_to_family[r] = family_str

        if len(members) >= 2:
            stem_sets = []
            for r in members:
                stems = {canonical_stem(r[0], r[1]), canonical_stem(r[1], r[2]),
                          canonical_stem(r[0], r[2])}
                stem_sets.append(stems)
            if not all(s == stem_sets[0] for s in stem_sets):
                stem_mismatches += 1

            cats = [category.get(r) for r in members]
            cats_known = [c for c in cats if c]
            diversity = len(set(cats_known))
            family_category_diversity[family_str] = (diversity, len(cats_known), len(members))

    return root_to_family, family_category_diversity, stem_mismatches


if __name__ == "__main__":
    matrix = build_anagram_matrix(roots)
    sizes = defaultdict(int)
    for members in matrix.values():
        sizes[len(members)] += 1

    total_sets = len(matrix)
    families = {k: v for k, v in matrix.items() if len(v) >= 2}
    print(f"Distinct 3-letter-sets with >=1 real root: {total_sets}")
    print(f"Genuine anagram families (2+ real roots): {len(families)} "
          f"({100*len(families)/total_sets:.1f}%)")
    for n in sorted(sizes):
        print(f"  {n}/6 real: {sizes[n]} letter-sets")

    root_to_family, diversity, mismatches = cross_index(matrix, roots, CATEGORY)
    print(f"\nStem-sharing structural check: {mismatches} mismatches (should be 0)")

    coherent = sum(1 for d, k, m in diversity.values() if k >= 2 and d == 1)
    scattered = sum(1 for d, k, m in diversity.values() if k >= 2 and d > 1)
    print(f"Coherent families (share one category): {coherent}")
    print(f"Scattered families (span multiple categories): {scattered}")

    out = {
        'letterset_to_roots': {''.join(sorted(k)): v for k, v in matrix.items()},
        'root_to_family': root_to_family,
        'family_category_diversity': {k: list(v) for k, v in diversity.items()},
    }
    with open("../../data/processed/anagram_matrix_indexed.json", "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False)
