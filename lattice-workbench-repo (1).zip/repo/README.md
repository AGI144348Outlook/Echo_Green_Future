# The Lattice Workbench — Hebrew Triconsonantal Root Ontology Engine

A bottom-up, data-driven ontology-engineering pipeline over the Hebrew
Bible's triconsonantal root system. Roots decompose into glyph
vertices, reassemble into triangular "Flags," differentiate into
category-tagged "Radial Stems," and can be grown, meshed, and
recursively subdivided into nested tetrahedral regions — all validated
against real lexical data, not hand-authored rules.

This repo is a full snapshot of one extended working session. It is
meant to be handed to a fresh conversation (with an AI assistant or a
human collaborator) so work can resume without re-deriving anything.

## Start here

Read the docs in this order:

1. **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** — the Matrix/Index
   system: Vertex, Stem, Flag, Radial Stem, Category, Tetrahedral, and
   Anagram Matrices, and how they cross-reference each other.
2. **[docs/DATA_PROVENANCE.md](docs/DATA_PROVENANCE.md)** — where the
   data comes from, and a real character-encoding corruption that was
   found and fixed in the source lexicon (important: re-read this
   before trusting any letter/word count from this pipeline).
3. **[docs/ALGORITHMS.md](docs/ALGORITHMS.md)** — every growth,
   differentiation, fractal-recursion, meshing, and feedback algorithm
   built and tested, in the order they were tried, with what each one
   taught.
4. **[docs/FINDINGS.md](docs/FINDINGS.md)** — the empirical discoveries
   worth remembering: which letters dominate, why, and what's still
   open.
5. **[docs/SESSION_LOG.md](docs/SESSION_LOG.md)** — a roughly
   chronological narrative of the whole session, for context on *why*
   each thing was built, not just *what* it does.

## Repo layout

```
├── docs/                     Documentation (read this first)
├── src/
│   ├── core/                 Base Matrix/Index classes (Vertex, Stem,
│   │                         Flag, Radial Stem, bidirectional Index)
│   ├── data/                 Scripts that BUILD the data matrices
│   │                         (extraction, category tagging, tetrahedral
│   │                         search, anagram grouping)
│   ├── algorithms/           Every growth/region/fractal/mesh/feedback
│   │                         algorithm tested
│   └── workbench/            The interactive HTML artifact's template
│       (needs data injected — see below)
├── data/
│   ├── raw/DictBDB.json      Original source (unabridged BDB lexicon,
│   │                         ~24MB, from eliranwong/unabridged-BDB-
│   │                         Hebrew-lexicon on GitHub)
│   ├── processed/            All built matrices, ready to use directly
│   │                         (bdb_roots.json, category_matrix.json,
│   │                         tetra_matrix.json, anagram matrices, etc.)
│   └── workbench_data.json   The compact bundle embedded in the HTML
│                             workbench artifact
└── outputs/
    └── lattice_workbench.html   The final built interactive artifact —
                                 open this directly in a browser
```

## Quick start for a new session

**If you just want to keep experimenting with the data** — everything
in `data/processed/` is ready to load directly:

```python
import json
with open("data/processed/bdb_roots.json", encoding="utf-8") as f:
    roots = json.load(f)          # {root: [pos, gloss]}, 1717 entries
with open("data/processed/category_matrix.json", encoding="utf-8") as f:
    categories = json.load(f)     # {root: WordNet category}
```

**If you want to rebuild from source** (e.g. to extend the extraction
or fix another gap): run the scripts in `src/data/` in this order —
`extract_bdb.py` → `build_category_matrix.py` →
`build_tetrahedral_matrix.py` → `build_anagram_matrix.py`. Each reads
from `data/raw/` or `data/processed/` and writes back to
`data/processed/`. (They use relative paths assuming you run them from
inside `src/data/` — adjust if running from elsewhere.)

**If you want the interactive workbench**: `outputs/lattice_workbench.html`
is the fully-built artifact, ready to open in any browser. To rebuild
it after changing the data or template, re-inject `data/workbench_data.json`
into `src/workbench/workbench_template.html` (replace the
`__DATA_JSON__` placeholder with the JSON file's contents) and save as
a new `.html` file.

**If you want to run an algorithm**: everything in `src/algorithms/`
is a standalone script with a `__main__` block — just run it directly.
Each has a module docstring explaining what it does and what it found.
Most import from `src/core/` for the base Matrix classes; a few
(`fractal_centroid.py`, `mesh_algorithm.py`, `feedback_loops.py`) are
self-contained and read `data/processed/bdb_roots.json` directly.

## What this is NOT (yet)

- Not exhaustive. Several searches (tetrahedra, fractal recursion) were
  deliberately scoped/sampled for tractability — see each script's
  docstring for exactly what was skipped and why.
- Not linguistically verified. Category tagging uses automatic WordNet
  sense-picking on English glosses, which has a real, acknowledged
  error rate (documented in ARCHITECTURE.md).
- Not a finished ontology-engineering system in the sense the GPT
  document (referenced in SESSION_LOG.md) describes — there's no
  authored rulebook of semantic/structural/geometric relations, only
  empirical discovery against real lexical data. That's a deliberate
  choice, not an oversight — see FINDINGS.md for why.
