# Data Provenance

## Source

`data/raw/DictBDB.json` — the unabridged Brown-Driver-Briggs Hebrew
Lexicon (1906), digitized as structured JSON by Eliran Wong:
https://github.com/eliranwong/unabridged-BDB-Hebrew-lexicon

BDB is public-domain (1906); the JSON structuring/formatting is the
maintainer's own work. ~24MB, 8,091 records, each with a Strong's
number, transliteration, Hebrew headword, and HTML-formatted
definition.

## Why this source instead of a hand-picked dictionary

The person explicitly did not want to test the pipeline against a
small, curated word list — wanted real, large-scale lexical data. BDB
was chosen because it's freely available, well-structured, and
directly downloadable/parseable via `bash_tool` (both `github.com` and
`raw.githubusercontent.com` are on the environment's allowed-domains
list).

## Extraction method (`src/data/extract_bdb.py`)

For every BDB entry: take the entry's first Hebrew headword, strip
niqqud/cantillation marks (keep only the 22-letter consonantal
skeleton), keep it only if exactly 3 letters remain, and pull the
entry's own part-of-speech + gloss as its tags. **This is a heuristic
extraction, not hand-verified lexicography** — some entries are
proper names or mis-parsed sub-senses (filtered where recognizable,
via `is_noise()`), and it's a citation-form extraction (Qal perfect 3ms
for verbs, standard practice), not a claim about which sense is
"the" root meaning.

Clean count after noise filtering: ~1,577 of 1,717 total roots (noise
= proper names, gentilics, "son of X" / "daughter of X" patterns,
place-names).

## THE CORRUPTION (important — read before trusting letter-frequency claims)

### What was found
פתח ("open") was completely missing from the extraction. In its
place: מתח, glossed "spread out" — suspiciously exactly what a
corrupted פתח would look like.

### The actual bug
The **source data itself** has a character-encoding corruption: a
contiguous range of Strong's numbers (roughly H6284 onward — the
whole Pe-letter section of the lexicon) has every **Pe (פ)** in the
Hebrew headword field silently replaced with **Mem (מ)**, while the
entry's own transliteration field ("H6299. padah") stayed correct.
This is almost certainly a leftover font-glyph-mapping error from
however the original PDF was digitized. **314 entries** matched this
exact pattern (transliteration starts with "p", Hebrew glyph starts
with Mem).

### The fix
Entirely internal to the source data — no external knowledge used.
For every entry where the transliteration says "p..." but the glyph
shows a Mem, every Mem in that glyph is un-substituted back to Pe
(verified: the substitution is consistent across the whole word, not
just the first letter — e.g. transliteration "padah" ↔ corrupted glyph
מדה ↔ corrected פדה, all three letters consistently swapped).
**83 real triconsonantal Pe-roots recovered** this way, including
פתח itself.

### The subtlety that made the first fix wrong
A first-pass fix that simply *deleted* every Mem-key touched by this
corruption was **incorrect**: several common Mem words (מלא "be
full", מלח "salt", מלט "plaster") are **legitimate, independently
encoded entries elsewhere in the source** (earlier Strong's numbers,
correctly formatted) that happen, after the later corruption, to
collide with the same bare spelling as a corrupted Pe-word (e.g.
H6381 "pala" → should be פלא "be wonderful" → corrupted to display as
מלא, colliding with the genuine, separate מלא "be full").

**The correct fix** (implemented in `extract_bdb.py`): only remove a
Mem-key if NO legitimate record (transliteration genuinely starts with
"m") exists anywhere else in the source for that exact spelling. Of
74 initially-flagged keys, **36 were legitimate and restored**; 38
were confirmed pure corruption artifacts and correctly removed.

### Final numbers
- Before any correction: 1,673 roots (1,537 after noise filtering)
- After correction: **1,717 roots** (net +44: +82 recovered Pe-roots,
  -38 genuine corruption artifacts removed, +36 restored legitimate
  entries that a too-blunt first pass would have wrongly deleted)

### Scope of what was NOT checked
This fix addresses the **Pe→Mem pattern specifically**. There is no
evidence one way or the other about whether other letter-pairs have
similar font-mapping corruption elsewhere in this lexicon — only this
one pattern was investigated, because it happened to be conspicuous
(a very common word, פתח, going missing). A spot-check after the fix
(`Roots by first letter` distribution) showed no other letter at a
suspiciously low count, which is reassuring but not a rigorous
guarantee. **Any future "letter X barely appears" finding should be
treated with the same suspicion פ initially was**, not taken at face
value.

## Category tagging (WordNet)

`src/data/build_category_matrix.py` uses NLTK's WordNet interface: for
each root's gloss, look up each gloss word's most common synset in the
POS matching BDB's own part-of-speech tag (verb glosses → WordNet
VERB, etc.), and tally which of WordNet's 45 fixed lexicographer
categories comes up most. This is automatic sense-disambiguation with
a real, documented error rate — see `docs/ARCHITECTURE.md` for a
concrete example of a mis-tag.
