# Key Findings

## 1. Resh (ר) is a structural hub — confirmed many independent ways

Every test that included Resh, regardless of method, showed it near
the top:
- Directional stem tests (רצ/רע/רפ and reversed): every Resh-containing
  stem grew to 43-87% of the corpus, far more than any non-Resh stem
  tested.
- Fractal centroid ignition (permanent-exclusion variant): tied for
  first (84 centroids) with Shin.
- Fractal centroid (proportional-cap + cycle-prevention variant): Ayin
  actually topped this version (222), with Resh close second (202) —
  the ranking among "living" letters is method-dependent, but Resh is
  *always* in the top tier, never absent from it.
- Mesh experiment: Resh's tree merged into the single unified
  component along with every other living glyph.

The person independently reported noticing Resh standing out in prior,
separate "HebrewAI" experiments before this session, and associates it
with "Identity."

## 2. Sefer Yetzirah's Mother/Double/Simple classification partially, not fully, matches the data

Traditional classification (confirmed via source lookup, not just
recall): **Mothers** = א,מ,ש (air/water/fire); **Doubles** =
ב,ג,ד,כ,פ,ר,ת; **Simples** = the other 12.

- 2 of 3 Mothers (מ,ש) were in the empirical top tier — but the third,
  **Aleph, scored dead last** in the permanent-exclusion ignition test
  (0 fractal centroids), directly contradicting its traditional status
  as the most primal letter.
- Of 7 Doubles, only Resh reached the top tier; the other tested
  doubles (ב,ג,ד,פ) were low or zero.
- Aleph's role flipped completely once REUSE was allowed with
  category-proportional caps: in the מאד/ה/ר experiment, Aleph became
  the single most-used letter of the whole run (2,229 uses out of
  ~3,000) — not because it can *ignite* structure (it can't, per
  finding above), but because once other letters cap out, Aleph is the
  only thing left that can keep participating. **Two different roles,
  not a contradiction**: Resh/Shin/Mem/Heh are igniters; Aleph is a
  sustainer.
- Caveat: that 2,229-use number was later found to be mostly (99.7%)
  three repeated loops through 5 tetrahedra, not genuine new discovery
  — see the cycle-prevention finding below.

## 3. "Unbounded growth" is usually a loop, not real exploration

The single most important methodological finding of the session.
Every time an algorithm was given room to reuse glyphs/stems without a
cycle-detection mechanism, apparent "unbounded" or "explosive" growth
turned out to be mostly the same small set of structures being
revisited over and over:
- Cooldown-reuse fractal test: hit an arbitrary 6,000-node safety cap
  every time for every glyph that ignited at all.
- The מאד/ה/ר experiment under naive reuse: 98.8% of 3,000 "new"
  centroids were 5 tetrahedra in a repeating loop.
- Adding a permanent Tetrahedron-index (deny re-opening any logged
  tetrahedron) collapsed the same experiment to **29 genuinely novel
  tetrahedra**, terminating naturally.

Lesson: a system with no memory of where it's already been will always
eventually loop, given enough reuse allowance — and the loop will look
identical to "productive unbounded growth" unless you specifically
check for repeats.

## 4. Naive feedback/reinforcement causes collapse, not improvement

Biasing growth toward "relations that worked in the previous
generation" shrank the discovered structure from 351 to 97 tetrahedra
in one generation — the classic reward-shaping/mode-collapse failure
mode, reproduced here in miniature and cleanly measurable. A
second-order controller that detects and throttles this DOES work
(self-corrects its own bias weight), but only partially, because it
was still learning from its own damaged output rather than a clean
baseline. See ALGORITHMS.md Part 5 for the mechanism.

## 5. Anagram families almost never share meaning

Of 377 letter-sets with 2+ real-word orderings, only 16 have members
that land in the same WordNet category — 361 scatter across unrelated
meanings (e.g. אבד "perish" / אדב [uncertain] / בדא "invent, feign" /
דאב "pine, grieve" — 4 real words, same 3 letters, 4 different
semantic domains). Anagram relatedness in this lexicon is almost
entirely a structural coincidence, not a semantic one.

## 6. The corpus's semantic character is real, not an artifact

Early in the session, dark/gloomy-seeming example words (fear, curse,
mourn, judge) were flagged as a possible pattern. Investigation
concluded this is mostly genuine: BDB is a lexicon of the Hebrew
Bible, which spends enormous textual weight on covenant, judgment,
lament, and exile — this vocabulary is not rare or cherry-picked in
that source, it's core. Some of the apparent skew was also acknowledged
as the assistant's own example-selection bias (picking vivid glosses
over neutral ones for illustration), which is a separate, non-data
issue.

## 7. The source lexicon has at least one real character-corruption bug

See DATA_PROVENANCE.md — a Pe→Mem substitution affecting ~314 entries,
found and fixed. Not yet checked: whether other letter-pairs have
similar corruption elsewhere in the source.
