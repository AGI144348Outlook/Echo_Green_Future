# Architecture: The Matrix / Index System

## Core concept

A triconsonantal Hebrew root (e.g. ר-א-ה, "see") is decomposed and
reassembled through a pipeline of Matrices, each holding a different
granularity of structure. Every Matrix is "inert" — pure storage, no
transformation logic of its own. Transformation happens in the
algorithms that read from and write to them (`src/algorithms/`).

## The Matrices, in build order

### 1. Vertex Matrix (`VertexMatrix` in `src/core/lattice_prototype.py`)
22 nodes, one per Hebrew consonant glyph. Each accumulates the
semantic tags of every root that touches it, once that root's
triangular continuity is "broken" (decomposed into separate letters).

### 2. Stem Matrix (`StemMatrix`)
484 slots (22×22 ordered pairs) — every possible 2-glyph combination.
Undifferentiated: a slot just lists which flags reference it.

**Important historical note**: the original implementation treated
`(a,b)` and `(b,a)` as distinct slots (order-sensitive, matching the
literal left-to-right spelling of each root). This was later found to
be an unintended asymmetry — `lattice_bidirectional.py` fixes it by
reading a stem's frontier in both directions, treating a stem as an
undirected letter-pair for the purposes of growth, while still
preserving the original directional data for anything that needs it.

### 3. Flag Matrix (`FlagMatrix`)
One entry per real triconsonantal root. A Flag is fully defined by its
3 boundary stems and carries the root's part-of-speech, gloss, and
(later) WordNet category. **The Flag is where meaning actually lives**
in this system — the "perimetered interior" the original spec asked
about turned out, mechanically, to just be the Flag object itself,
since it has no existence apart from its 3-stem boundary plus its
attached semantic payload.

**Known gap**: no object exists yet representing a *Region's*
(multi-flag) emergent meaning, distinct from the sum of its component
flags' individual tags. Every "region" built this session is really a
bag of independently-tagged flags that happen to share stems — nothing
aggregates what they mean *together*.

### 4. Radial Stem Matrix (`RadialStemMatrix`)
A Stem Matrix slot "differentiated" by joining it against the Flag
Matrix — i.e., which flags reference this stem. This is where a plain
Stem becomes distinguishable from another Stem with the same letters
but different surrounding flags.

### 5. Fine-Grained Radial Stem tokens (`src/algorithms/differentiate_radial_stems.py`)
A further split: instead of one Radial Stem per letter-pair, split it
into one token PER DISTINCT CATEGORY among the touching flags. Stem
(ר,ע) isn't one brick — it's ~18 separate category-flavored bricks
(verb.motion, verb.contact, verb.emotion...), each with only the flags
in that category. **This can be computed two ways**: precomputed once
for the whole alphabet (`differentiate_radial_stems.py`'s
`FINE_RADIAL_STEMS` table), or computed live, on-demand, only for
stems actually visited during a growth walk (the `differentiate()`
function used throughout `src/algorithms/lattice_*.py`) — the latter
is architecturally cleaner (no precomputed table needed, degrades
gracefully if the underlying data changes mid-run) and was verified
byte-identical to the precomputed version for spot-checked stems.

### 6. Category Matrix (`src/data/build_category_matrix.py`)
Root → WordNet lexicographer category (one of 45 fixed categories:
verb.cognition, verb.perception, noun.artifact, etc.), chosen via
automatic sense-picking on the English gloss (BDB's own part-of-speech
tag selects which WordNet POS to search). **97% coverage** (1,489 of
1,537 roots tagged, pre-correction numbers; re-run after the data fix
for current counts). **Known error rate**: automatic sense-picking is
occasionally wrong — e.g. ברא "shape, create" landed in verb.cognition
via a spurious sense match on "create," not genuine cognitive content.
Treat category tags as a strong signal, not ground truth.

### 7. Tetrahedral Matrix (`src/data/build_tetrahedral_matrix.py`)
Every real "closed" 4-flag / 6-stem region found in the corpus
(9,774 found in a scoped search — see script docstring for exactly
what was excluded), cross-indexed with the Category Matrix to find
"lead clusters" — tetrahedra where 3+ of the 4 flags already share one
category.

### 8. Anagram Matrix (`src/data/build_anagram_matrix.py`)
Groups every root by its UNORDERED 3-letter set. Any 3 distinct
letters have 3! = 6 possible orderings; most letter-sets have 0 or 1
real word among those 6, but some have several — e.g. גדל/גלד/דגל/דלג
(4 of 6 slots filled, from the single root "grow"). Cross-indexed
against the Stem Matrix (verified: every family member shares
identical stems, as expected) and the Category Matrix (measures
whether a family shares meaning — **rare**: only 16 of 377 multi-member
families share a category; 361 scatter across unrelated meanings).

### 9. The Index (`Index` class in `lattice_prototype.py`)
Bidirectional lookup tables: vertex↔stem, stem↔flag, vertex↔flag, in
both directions. This is what every growth algorithm actually queries.

## The growth substrate

On top of the Matrices sits a family of growth algorithms
(`src/algorithms/`), all sharing the same basic move: given a set of
already-"laid" stems (bricks), find candidate next-stems by looking at
what flags touch the current frontier, score the candidates by some
rule (theme match, category-bridging, branching factor...), lay the
winner, repeat. See `docs/ALGORITHMS.md` for the full family tree —
there are at least 12 named variants (A through L) plus the fractal
centroid / mesh / feedback-loop family built later.

## The Region Integrity Infrastructure (tetrahedral subdivision)

A separate, later addition: when 4 flags close into a valid
tetrahedron (6 shared stems, pairwise sharing on 3+ pairs), a Null/
Inert "centroid" vertex can be instantiated at its center, connected
to all 4 outer vertices, opening up to C(4,2)=6 new interior faces.
If any of the 4 resulting sub-tetrahedra also close, that recursively
triggers a new centroid — inward, fractal subdivision. See
`src/algorithms/fractal_centroid.py` for every reuse-policy variant
tested and what each one revealed (the tetrahedron-index cycle
prevention fix, in particular, is important — read its docstring
before running any variant that allows glyph reuse).
