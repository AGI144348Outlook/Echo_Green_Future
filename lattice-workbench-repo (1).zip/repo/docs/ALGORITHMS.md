# Algorithms

Every growth, region-building, and recursion algorithm tested this
session, roughly in the order they were built. Each taught something
the previous one didn't — later algorithms exist specifically because
an earlier one revealed a problem.

## Part 1: Region-growth family (single tetrahedron / small regions)

All operate on the same basic move: given laid stems (bricks), find
candidate next-stems from flags touching the frontier, score
candidates by some rule, lay the winner, repeat.

| ID | File | Rule | What it revealed |
|----|------|------|-------------------|
| A | `lattice_real_data.py` | Greedy stem closure (union-find on shared stems) | At full corpus density, collapses into ONE giant cluster — batch clustering isn't meaningful at scale. |
| B | `lattice_real_data.py` | Vertex adjacency (share any glyph) | Even looser than A; confirms adjacency alone is too permissive. |
| C | `lattice_real_data.py` | Semantic tag-overlap gate | Alone: inert (rarely blocks anything). Combined with E: causes starvation (see I). |
| D | `lattice_real_data.py` | Stop at first exact 4-flag/6-stem pyramid | The only variant that reliably produces small, coherent regions. |
| E | `lattice_real_data.py` | Per-stem reuse budget (brick supply cap) | Alone: an *exploration booster*, not a brake — throttling one hub forces discovery elsewhere. |
| F | `lattice_sequential.py` | Sequential frontier walk, theme-agnostic | On 15 sample roots: stalls immediately (data too sparse). On full corpus: closes almost everywhere (too dense). |
| G | `lattice_themed_regions.py` | Theme-locked walk (word-boundary keyword match) | Produces coherent small regions; formalizes what "hand-picking flags" was already doing. |
| H | `lattice_crosstalk_growth.py` | Cross-talk-seeking (prefer candidates touching the most themes at once) | Explodes fast (57→169 flags); most of what it pulls in is off-theme filler, not genuine bridges. |
| I | `lattice_bounded_growth.py` | H + C(gate) + E(budget) + D(stop), combined | Over-constrained: died at 1 flag. C+E interact multiplicatively — isolating them (see `lattice_isolate_constraints.py`) showed neither alone causes this; only their combination starves the frontier. |
| J | `lattice_pulse_growth.py` | D as a CHECKPOINT (reset E's budget) instead of a hard stop | Never reaches a first checkpoint — dies from the same C+E starvation before D can ever fire. Needs a bootstrap phase. |
| — | `lattice_pulse_growth.py` (patched) | J + unconstrained bootstrap until first region, then C+E+D | Works: 8 regions, 30 flags — but regions turned out to be overlapping variations on ONE dense neighborhood, not 8 distinct topics. |
| K | `lattice_distinct_regions.py` | Grow several regions from separately-seeded, novelty-maximizing starting points | 5 distinct regions found — but 2 of them still share actual member flags despite deliberate seed separation; novelty-seeding controls *where a region starts*, not *where it ends up*. |
| L | `lattice_bidirectional.py` | Fix: read a stem's frontier in BOTH letter-orders | Confirmed correct (reversed seeds now produce near-identical growth) — but small residual divergence traced to Python's `max()` tie-break on equal scores, an implementation artifact, not a real signal. |

## Part 2: Category-aware growth (after WordNet Category Matrix built)

- **Fine-grained differentiation** (`differentiate_radial_stems.py`):
  splits each Stem into category-tagged tokens instead of one
  generic brick. Growth then propagates a SINGLE category forward
  from a laid token, giving coherence without an alphabet-boundary
  hack.
- **On-demand (live) differentiation**: same logic, computed fresh
  per-stem at the moment it's visited, no precomputed table. Verified
  byte-identical to the precomputed version for spot-checked stems;
  final walk totals differ slightly between the two implementations
  due to the same `max()` tie-break sensitivity as L.

## Part 3: Seed-locality experiments

- **Seed-bound growth**: restrict every new stem to use only letters
  already in the seed's own sub-alphabet. First attempt (only ONE
  letter needs to be in-alphabet) was far too loose (58% of corpus).
  Strict version (BOTH letters must be in-alphabet) still captured
  18% — because an n-letter sub-alphabet caps you at roughly
  `(n/22)³` of the corpus by pure combinatorics, not by anything the
  algorithm does. The real lever for region size is how many distinct
  letters the seed uses, not the traversal rule.
- **Directional stem analysis** (Resh-Aleph case study): the SAME
  2-letter stem read in opposite literal spelling order can have
  wildly different branching factor — ר-א→ had only 2 real
  completions; א-ר→ had 10. Growing from the "poorer" direction
  produced a small, legible 123-flag region; growing from the
  "richer" direction produced an 1,310-flag near-total-corpus
  collapse (85%). More starting options made things WORSE, not
  better — richer branching is dangerous, not helpful, once
  unconstrained.

## Part 4: The Region Integrity Infrastructure (fractal centroid family)

See `fractal_centroid.py`'s extensive module docstring for the full
detail. Summary of the 4 variants tried, in order:

1. **Permanent exclusion** — each glyph usable once, ever, anywhere in
   the recursion. Bounded (max ~84 for the strongest glyphs) but
   conceptually wrong (a Vertex token isn't consumed by use).
2. **Cooldown reuse** (glyph eligible again after N levels) — removed
   the wrong constraint, but revealed genuinely unbounded behavior:
   every glyph that ignites at all hit an arbitrary safety cap (6,000)
   every time, because nothing stopped it from re-entering the same
   small neighborhood repeatedly.
3. **Tetrahedron-index cycle prevention** (a global index permanently
   denies re-opening any already-logged 4-vertex tetrahedron) — this
   is the fix that actually mattered. Without it, one specific test
   found that 98.8% of 3,000 "new" centroids were really just 5
   tetrahedra being revisited in a loop. With it, the same seed
   naturally terminates at 29 genuinely novel tetrahedra and stops on
   its own.
4. **Category-proportional caps** (Sefer Yetzirah inspired: Mothers /
   Doubles / Simples get different usage budgets, see FINDINGS.md) —
   combined with cycle prevention, this is the most defensible
   variant tested, and the one used in the final 22-glyph and mesh
   experiments.

## Part 5: Meshing and feedback

- **Mesh algorithm** (`mesh_algorithm.py`): Union-Find merging of
  multiple glyphs' independent fractal trees, sharing ONE global
  Tetrahedron index and budget instead of 8 separate ones. Result: all
  8 "living" glyphs (the ones that ignite at all) merged into a single
  connected component — 351 tetrahedra, 312 mesh events, dominated by
  a handful of "confluence" tetrahedra that each pulled in multiple
  unrelated branches at once.
- **Feedback loops** (`feedback_loops.py`): naive positive
  reinforcement of "what worked" caused mode collapse (351→97
  tetrahedra), not growth — a real, demonstrated instance of the
  same failure mode reinforcement-learning systems are known for. A
  second-order meta-controller that monitors the primary loop's own
  performance and throttles its bias weight on detected collapse DOES
  self-correct (0.5→0.032, stabilizing) — but only partially:
  it stabilized at 46, far below the 351 baseline, because it kept
  learning from its own already-damaged output instead of a clean
  reference point. The identified (but not yet implemented) fix:
  separate what the meta-loop *monitors* (current generation, for
  collapse detection) from what it *learns from* (should stay anchored
  to the last known-healthy generation).

## What's designed but not fully built

- **The corrected feedback-loop fix** (anchor learning to a healthy
  baseline, not the current possibly-collapsed generation) — designed,
  not implemented.
- **A step-by-step runtime scheduler** that alternates outward growth
  and inward Region-Integrity work on a strict turn budget (discussed
  extensively, never coded as a real scheduler — the fractal_centroid
  and mesh experiments run one phase to completion before the other,
  not truly interleaved).
- **The semantic/structural/geometric failure-mode separation**
  proposed by an external GPT critique (see SESSION_LOG.md) — every
  `sub_tet_closes()` check in this codebase still conflates all three
  into one boolean. Flagged as the single most valuable next
  architectural improvement.
