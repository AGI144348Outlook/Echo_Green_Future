/* Caches the page, ECHO's Python package, Pyodide and fonts after the first visit, so ECHO runs offline. */
const VERSION = "echo-notebook-0.4.1";
const SHELL = ["./", "./index.html", "./manifest.webmanifest", "./css/notebook.css", "./js/nve.js", "./js/stage.js", "./js/widgets.js",
  "./js/bridge.js", "./js/io.js", "./js/forge.js", "./js/panels.js", "./js/app.js", "./js/study.js", "./js/worker.js", "./data/geosensory_registry.json",
  "./icons/icon-192.png", "./icons/icon-512.png", "./echo/manifest.json"];
self.addEventListener("install", ev => ev.waitUntil((async () => {
  const c = await caches.open(VERSION); await c.addAll(SHELL);
  try { const m = await (await fetch("./echo/manifest.json", { cache: "no-cache" })).json(); await c.addAll(m.files.map(f => `./${f}?v=${m.version}`)); } catch (e) {}
  self.skipWaiting();
})()));
self.addEventListener("activate", ev => ev.waitUntil((async () => {
  for (const k of await caches.keys()) if (k !== VERSION) await caches.delete(k);
  await self.clients.claim();
})()));
self.addEventListener("fetch", ev => {
  const req = ev.request; if (req.method !== "GET") return;
  const u = new URL(req.url), same = u.origin === self.location.origin;
  const cdn = (u.hostname === "cdn.jsdelivr.net" && u.pathname.startsWith("/pyodide/")) || u.hostname === "fonts.googleapis.com" || u.hostname === "fonts.gstatic.com";
  if (!same && !cdn) return;
  if (same && u.pathname.endsWith("/echo/manifest.json")) { ev.respondWith(fetch(req).then(r => { put(req, r.clone()); return r; }).catch(() => caches.match(req))); return; }
  ev.respondWith(caches.match(req).then(hit => hit || fetch(req).then(r => { if (r.ok) put(req, r.clone()); return r; })
    .catch(() => req.mode === "navigate" ? caches.match("./index.html") : Response.error())));
});
function put(req, res) { caches.open(VERSION).then(c => c.put(req, res)).catch(() => {}); }
