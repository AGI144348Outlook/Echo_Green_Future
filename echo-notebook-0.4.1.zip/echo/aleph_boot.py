"""The א bootstrap as an executable model. Every rule in the design is enforced here, not just described.

Actors and authority
  001              un-presentiated Governor. May only perform the steps listed in its permit (alg-003),
                   exactly once each, in order. Nothing else.
  ר-alg-001        001 presentiated into ר. Same identity as 001 (Presentiation never changes identity);
                   authority attaches to the presence in ר, and that presence has executive scope.
Records
  every object has an immutable origin (where it was first placed) and a current location, a content hash of
  what it actually contains, and a lineage hash chaining it to the record that created it.
Transactions
  a multi-part change (relocation) is applied to a copy and committed only if every check passes;
  on any failure the previous valid state is kept.
alg-002 is the boolean system check at the end.

Honest limits: hashes give tamper evidence, not authentication. Real signatures need keys, which this model
does not manage.
"""
import copy, hashlib, json

from .kernel import HEBREW_LETTER_INDEX as H
from .operators.lhea import LETTER_ORDER

STANDARD = [H[n]["glyph"] for n in LETTER_ORDER]                          # א ... ת (22)
FINALS = [H[n]["glyph"] for n in ("kaf-sofit", "mem-sofit", "nun-sofit", "pe-sofit", "tsadi-sofit")]   # ך ם ן ף ץ
ALL27 = STANDARD + FINALS


def h(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]


# The DSL's actual contents: operators with their signatures and the procedures they bind to.
def involution_check(f, samples):
    return all(f(f(x)) == x for x in samples)

INVERT = lambda p: (p[1], p[0], p[3], p[2])                               # % on a proportion a:b::c:d -> b:a::d:c
DSL_DEFINITION = {
    "name": "EMEL",
    "operators": {
        ":":           {"arity": 2, "meaning": "relational anchor"},
        "::":          {"arity": 2, "meaning": "comparison of comparisons (proportion)"},
        "|...|":       {"arity": 1, "meaning": "bounded operand"},
        "{...}":       {"arity": 1, "meaning": "grouping scope"},
        "%":           {"arity": 1, "meaning": "inversion (involution: %(%(x)) = x)", "binds": "aleph_boot.INVERT"},
        "PRESENTIATE": {"arity": 3, "meaning": "same identity at a new locus", "binds": "aleph_boot.World.presentiate"},
    },
}

# alg-003: the permit. The only operations 001 may perform, in this order, once each.
PERMIT_003 = [
    ("instantiate", "DNS"),
    ("seed", "PRESENTIATE"),
    ("instantiate", "א"),
    ("presentiate", "DSL", "א"),
    ("instantiate", "ר"),
    ("presentiate", "001", "ר"),
]


class BootError(Exception):
    pass


class World:
    def __init__(self):
        self.dns = None                     # root namespace registry
        self.matrices = {}                  # glyph -> {"records": {...}}
        self.records = {}                   # id -> record
        self.presences = {}                 # (identity, glyph) -> presence
        self.permit_pos = 0
        self.log = []
        self.genesis = h({"alg": "001", "role": "governor_indexing_alg"})
        self.records["001"] = {"id": "001", "content_hash": self.genesis, "origin": None, "location": None,
                               "lineage": h(["genesis", self.genesis])}

    # ---- authority -----------------------------------------------------------------------------
    def executive(self, actor):
        p = self.presences.get(("001", "ר"))
        return actor == "ר-alg-001" and p is not None and p["authority"] == "executive"

    def authorize(self, actor, step):
        if actor == "001":
            if self.permit_pos >= len(PERMIT_003):
                raise BootError("001's permit is used up; it has no further authority")
            want = PERMIT_003[self.permit_pos]
            if step != want:
                raise BootError(f"permit 003 allows {want} next, not {step}")
            self.permit_pos += 1
            return
        if not self.executive(actor):
            raise BootError(f"{actor} has no executive authority")

    def _log(self, actor, step, **kw):
        prev = self.log[-1]["hash"] if self.log else self.genesis
        entry = {"n": len(self.log) + 1, "actor": actor, "step": list(step), **kw}
        entry["hash"] = h([prev, entry])
        self.log.append(entry)

    # ---- operations -------------------------------------------------------------------------------
    def instantiate(self, actor, target):
        step = ("instantiate", target)
        self.authorize(actor, step)
        if target == "DNS":
            if self.dns is not None: raise BootError("DNS already exists")
            self.dns = {"primitives": {}}
        elif target in ALL27:
            if target in self.matrices: raise BootError(f"{target} already exists")
            self.matrices[target] = {"records": {}}
        else:
            raise BootError(f"{target} is not one of the 27 sub-matrices")
        self._log(actor, step)

    def seed(self, actor, primitive):
        step = ("seed", primitive)
        self.authorize(actor, step)
        if self.dns is None: raise BootError("cannot seed before DNS exists")
        if self.dns["primitives"]: raise BootError("DNS may hold only the Presentiation primitive at boot")
        self.dns["primitives"][primitive] = {"binds": "World.presentiate"}
        self._log(actor, step)

    def presentiate(self, actor, subject, glyph):
        step = ("presentiate", subject, glyph)
        self.authorize(actor, step)
        if self.dns is None or "PRESENTIATE" not in self.dns["primitives"]:
            raise BootError("Presentiation is not seeded yet")
        if glyph not in self.matrices: raise BootError(f"{glyph} does not exist yet")
        if subject == "DSL" and "DSL" not in self.records:
            content = copy.deepcopy(DSL_DEFINITION)
            if not involution_check(INVERT, [(1, 2, 3, 4), ("a", "b", "c", "d")]):
                raise BootError("% failed its involution test; the DSL is not admitted")
            # the subject's own lineage: its origin record, separate from the requester's identity
            self.records["DSL"] = {"id": "DSL", "content": content, "content_hash": h(content), "origin": glyph,
                                   "location": glyph, "requested_by": actor,
                                   "lineage": h([self.records["001"]["lineage"], "DSL", h(content)])}
        if subject not in self.records: raise BootError(f"no record for {subject}")
        rec = self.records[subject]
        authority = "executive" if (subject, glyph) == ("001", "ר") else "local"
        self.presences[(subject, glyph)] = {"identity": rec["content_hash"], "locus": glyph, "authority": authority,
                                           "requested_by": actor}
        self.matrices[glyph]["records"][subject] = rec["content_hash"]
        self._log(actor, step, identity=rec["content_hash"], authority=authority)

    def relocate(self, actor, subject, dest, fail_after_remove=False):
        """Atomic: all parts commit together or the previous valid state stays."""
        step = ("relocate", subject, dest)
        self.authorize(actor, step)
        before = copy.deepcopy((self.matrices, self.records, self.presences))
        try:
            rec = self.records[subject]; src = rec["location"]
            if dest not in self.matrices: raise BootError(f"destination {dest} does not exist")
            del self.matrices[src]["records"][subject]
            if fail_after_remove: raise BootError("simulated failure mid-relocation")
            self.matrices[dest]["records"][subject] = rec["content_hash"]
            p = self.presences.pop((subject, src))
            self.presences[(subject, dest)] = {**p, "locus": dest}
            rec["location"] = dest                      # origin is never touched
            if h(rec["content"]) != rec["content_hash"]: raise BootError("content changed during relocation")
        except Exception:
            self.matrices, self.records, self.presences = before
            raise
        self._log(actor, step)

    # ---- alg-002: the system check ----------------------------------------------------------------
    def alg_002(self):
        dsl = self.records.get("DSL")
        checks = {
            "all 27 sub-matrices exist": set(self.matrices) == set(ALL27),
            "permit 003 fully and only used": self.permit_pos == len(PERMIT_003),
            "ר-alg-001 has executive presence": self.executive("ר-alg-001"),
            "ר-alg-001 is the same identity as 001": self.presences.get(("001", "ר"), {}).get("identity") == self.genesis,
            "DSL lives in ם": bool(dsl) and dsl["location"] == "ם" and "DSL" in self.matrices.get("ם", {}).get("records", {}),
            "DSL origin is still א": bool(dsl) and dsl["origin"] == "א",
            "DSL contents match their hash": bool(dsl) and h(dsl["content"]) == dsl["content_hash"],
            "DSL binds PRESENTIATE and %": bool(dsl) and {"PRESENTIATE", "%"} <= set(dsl["content"]["operators"]),
            "log hash chain intact": self._chain_ok(),
        }
        wk = getattr(self, "walker", None)
        if wk is not None:
            checks["walk followed the order exactly"] = wk.path == WALK
            checks["ת second to last, ם last"] = wk.path[-2:] == ["ת", "ם"]
            checks["ר never visited by the DSL"] = "ר" not in wk.path
        return all(checks.values()), checks

    def _chain_ok(self):
        prev = self.genesis
        for e in self.log:
            body = {k: v for k, v in e.items() if k != "hash"}
            if h([prev, body]) != e["hash"]: return False
            prev = e["hash"]
        return True


# ---- the % walk: ר001 creates the remaining folders by alternating two inversions --------------------
# Order (Tim): forwards from א through ש, skipping ר; then ך ן ף ץ; then ת second to last; then ם last.
WALK = ["א"] + [g for g in STANDARD[1:-1] if g != "ר"] + ["ך", "ן", "ף", "ץ", "ת", "ם"]
NEXT = dict(zip(WALK, WALK[1:]))
PREV = {b: a for a, b in NEXT.items()}

# States of the carrier: ("at", L) = the DSL seated in L; ("lifted", L) = L/(DSL), lifted out of L.
def lift(state):
    """σ: (DSL L) <-> L/(DSL). An involution."""
    kind, L = state
    return ("lifted", L) if kind == "at" else ("at", L)

def seat(state):
    """τ: L/(DSL) <-> (DSL next(L)). An involution; the two ends of the walk are its fixed points."""
    kind, L = state
    if kind == "lifted" and L in NEXT: return ("at", NEXT[L])
    if kind == "at" and L in PREV: return ("lifted", PREV[L])
    return state

def forward(state): return seat(lift(state))        # (ר001)%(DSL L) = L/(DSL), then (ר001)%{L/(DSL)} = (DSL next)
def backward(state): return lift(seat(state))       # the same two mirrors in the opposite order

def notation(state):
    kind, L = state
    return f"(DSL{L})" if kind == "at" else f"{L}/(DSL)"


class Walker:
    """ר001 walks the DSL through the alphabet. Each seat on a new letter creates that folder."""
    def __init__(self, world):
        self.w = world
        self.state = ("at", "א")
        self.path = ["א"]

    def step(self, direction="forward"):
        w = self.w
        w.authorize("ר-alg-001", ("walk", direction))
        before = copy.deepcopy((w.matrices, w.records, w.presences, self.state, self.path))
        try:
            s0 = self.state
            if direction == "forward": s1 = lift(s0); s2 = seat(s1); pinned = s2 == s1
            else: s1 = seat(s0); s2 = lift(s1); pinned = s1 == s0
            if pinned: raise BootError("the walk is at its end in that direction")   # seat has no partner here
            L = s2[1]
            if L == "ר": raise BootError("the walk must skip ר")
            if L not in w.matrices:
                if direction != "forward": raise BootError("walking backwards never creates folders")
                w.matrices[L] = {"records": {}}
            rec = w.records["DSL"]; src = rec["location"]
            del w.matrices[src]["records"]["DSL"]
            w.matrices[L]["records"]["DSL"] = rec["content_hash"]
            p = w.presences.pop(("DSL", src)); w.presences[("DSL", L)] = {**p, "locus": L}
            rec["location"] = L
            self.state = s2; self.path.append(L)
            if h(rec["content"]) != rec["content_hash"]: raise BootError("content changed during the walk")
        except Exception:
            w.matrices, w.records, w.presences, self.state, self.path = before
            raise
        w._log("ר-alg-001", ("walk", direction), notation=[f"(ר001)%{notation(s0)}={notation(s1)}", f"(ר001)%{{{notation(s1)}}}={notation(s2)}"])
        return s2

    def run(self):
        while self.state != ("at", "ם"):
            self.step("forward")
        return self.path


def boot():
    """001's six permitted steps, then ר001 walks the DSL from א to ם, creating the other 25 folders."""
    w = World()
    w.instantiate("001", "DNS")
    w.seed("001", "PRESENTIATE")
    w.instantiate("001", "א")
    w.presentiate("001", "DSL", "א")
    w.instantiate("001", "ר")
    w.presentiate("001", "001", "ר")
    w.walker = Walker(w)
    w.walker.run()
    return w


def boot_by_relocation():
    """The earlier sequence (kept for comparison). ם must exist before the DSL can move there."""
    w = World()
    w.instantiate("001", "DNS")
    w.seed("001", "PRESENTIATE")
    w.instantiate("001", "א")
    w.presentiate("001", "DSL", "א")
    w.instantiate("001", "ר")
    w.presentiate("001", "001", "ר")
    w.instantiate("ר-alg-001", "ם")
    w.relocate("ר-alg-001", "DSL", "ם")
    for g in ALL27:
        if g not in w.matrices: w.instantiate("ר-alg-001", g)
    return w
