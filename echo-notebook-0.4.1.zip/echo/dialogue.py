"""ECHO's dialogue engine: who he is talking with, what has been said, and replies he can stand behind.

- People are residents: each speaker has a record of what they have told him. Their claims are kept as
  theirs, separate from what he can verify, until his audits support them.
- He tracks the current topic and his own open question, so an answer can close it.
- Yes/no questions are answered from his audits; "why" is answered by walking his dictionary's is-a path.
- A string of Hebrew letters is met with his registries only: each letter's registered operation and value,
  their sum, the reversed string, relations to other strings, and dictionary words his own Latin-to-Hebrew
  decomposition spells the same way. Then it is registered as a candidate with its meaning unassigned, and
  he asks what it means. He does not assign a meaning himself.
The fixed phrasings below are templates; the facts inside them come from his dictionary, registries and audits.
"""
import re
from .language.lexicon import GLYPHS
from .kernel import HEBREW_LETTER_INDEX
from .operators.lhea import decompose, glyphs as lhea_glyphs

VAL = {v["glyph"]: v["val"] for v in HEBREW_LETTER_INDEX.values()}
HEB = re.compile(r"[\u05D0-\u05EA]+")
def art(w): return "an" if w[:1] in "aeiou" else "a"
def out(kind, text, **kw): return {"actor": "echo", "kind": kind, "text": text, "refs": kw.pop("refs", []), **kw}


class Dialogue:
    def __init__(self, rt, state):
        self.rt = rt
        self.people = state.get("people", {})
        self.speaker = state.get("speaker")
        self.pending = state.get("pending")            # ["word", w] | ["glyph", s] | ["name"]
        self.topic = state.get("topic")
        self.strings = state.get("glyph_strings", {})  # candidate Glyph String Registry
        self._spell = None

    def state(self):
        return {"people": self.people, "speaker": self.speaker, "pending": self.pending, "topic": self.topic,
                "glyph_strings": self.strings}

    def person(self):
        name = self.speaker or "you"
        return self.people.setdefault(name, {"claims": [], "messages": 0})

    # ---- one turn ---------------------------------------------------------------------------
    def turn(self, text):
        t = re.sub(r"\b(?:a )?(?:kind|type|sort) of ", "", text.strip(), flags=re.I)
        low = t.lower().rstrip("?.! ")
        self.person()["messages"] += 1
        if HEB.search(t): return self.glyphs(t)
        m = re.match(r"^(?:hi|hello|hey|shalom|good (?:morning|evening|afternoon))\b", low)
        if m:
            if self.speaker: return [out("text", f"Hello, {self.speaker}.")]
            self.pending = ["name"]; return [out("text", "Hello. Who am I speaking with?")]
        m = re.match(r"^(?:i am|i'm|my name is|this is|call me)\s+([a-z][a-z'-]*)", low)
        if m or (self.pending == ["name"] and re.fullmatch(r"[a-z][a-z'-]*", low)):
            name = (m.group(1) if m else low).capitalize()
            old = self.people.pop(self.speaker or "you", None)
            self.speaker = name; self.people.setdefault(name, old or {"claims": [], "messages": 0}); self.pending = None
            return [out("text", f"I will remember you as {name}.")]
        if re.match(r"^(?:who are you|what are you)$", low):
            return [out("text", "I am ECHO. My Governor is \u05e8, A-000. I know the words in my dictionary and only say what my audits support.")]
        if re.match(r"^(?:what do you know about me|what did i tell you|what have i told you)$", low):
            c = self.person()["claims"]
            if not c: return [out("text", "You have not told me anything I am holding for you yet.")]
            return [out("text", "You told me: " + "; ".join(f"{x['text']} ({x['status']})" for x in c[-6:]) + ".")]
        m = re.match(r"^(?:what is|what's|what are) (?:an? |the )?([a-z][a-z -]*)$", low)
        if m: return self.whatis(m.group(1))
        m = re.match(r"^why (?:is|are) (?:an? |the )?([a-z][a-z -]*?) (?:an? |the )?([a-z][a-z -]*)$", low)
        if m: return self.why(m.group(1), m.group(2))
        m = re.match(r"^(?:is|are) (?:an? |the )?([a-z][a-z-]*) (?:an? |the )?([a-z][a-z -]*)$", low)
        if m: return self.yesno(m.group(1), m.group(2))
        if self.pending and self.pending[0] in ("word", "glyph"):
            m = re.match(r"^(?:it(?:'s| is) |it means |an? )?(?:an? )?([a-z][a-z -]*)$", low)
            if m and not re.search(r"\b(is|are|what|why|who)\b", low):
                subj = self.pending[1]; self.pending = None
                if subj and HEB.fullmatch(subj):
                    self.strings.setdefault(subj, {})["meanings"] = self.strings[subj].get("meanings", []) + [{"by": self.speaker or "you", "text": m.group(1)}]
                    owner = f"{self.speaker}'s" if self.speaker else "your"
                    return [out("text", f"I will hold that {subj} means '{m.group(1)}', as {owner} meaning. I cannot verify meanings for glyph strings yet.")]
                return self.claim(subj, m.group(1))
        m = re.match(r"^(?:an? |the )?([a-z][a-z-]*) (?:is|are) (?:an? |the )?([a-z][a-z -]*)$", low)
        if m: return self.claim(m.group(1), m.group(2))
        return None

    # ---- claims, yes/no, why ----------------------------------------------------------------------
    def _verdict(self, x, y):
        D = self.rt.K
        kx, ky = D.key(x), D.key(y)
        if not kx: return "gap", x
        if not ky: return "gap", y
        r = D.relate(kx, ky)
        if r and r[0] == "is_a": return "supported", r[1]
        if r and r[0] == "includes": return "reversed", r[1]
        return "no path", None

    def claim(self, x, y):
        v, d = self._verdict(x, y)
        text = f"{art(x).capitalize()} {x} is {art(y)} {y}"
        if v == "supported":
            s = self.rt._speak(self.rt.K.key(x), "is_a", self.rt.K.key(y))
            return [out("text", (s["english"] if s else text + ".") + f" My dictionary agrees, {d} step{'s' if d > 1 else ''} up.", refs=[x, y])]
        who = self.speaker or "you"
        status = {"reversed": "my dictionary has it the other way", "no path": "my dictionary has no path", "gap": f"'{d}' is not in my dictionary"}[v]
        self.person()["claims"].append({"text": text, "status": status})
        if v == "gap": self.rt.study.note_gap(d)
        if v == "reversed": msg = f"My dictionary has it the other way: {art(y)} {y} is a kind of {x}. I will keep your version as yours."
        elif v == "gap": msg = f"I do not know '{d}' yet. I will keep '{text}' as something {who} told me, and study the word when I can."
        else: msg = f"My dictionary has no path from {x} to {y}. I will keep it as something {who} told me, not as something I know."
        return [out("text", msg, refs=[x, y])]

    def yesno(self, x, y):
        v, d = self._verdict(x, y)
        self.topic = x
        mine = [c for c in self.person()["claims"] if c["text"].lower() == f"{art(x)} {x} is {art(y)} {y}"]
        if v == "supported": return [out("text", f"Yes. {art(x).capitalize()} {x} is {art(y)} {y}, {d} step{'s' if d > 1 else ''} up in my dictionary.", refs=[x, y])]
        if v == "reversed": return [out("text", f"No. It is the other way: {art(y)} {y} is {art(x)} {x}.", refs=[x, y])]
        if v == "gap":
            if mine: return [out("text", f"I cannot check that myself: '{d}' is not in my dictionary. You told me it is, and I am holding that as yours.")]
            self.pending = ["word", d]; self.rt.study.note_gap(d)
            return [out("text", f"I do not know. '{d}' is not in my dictionary. What is {art(d)} {d}?")]
        return [out("text", "I do not know. My dictionary has no path from " + f"{x} to {y}." + (" You told me it is, and I am holding that as yours." if mine else ""), refs=[x, y])]

    def whatis(self, x):
        D = self.rt.K; k = D.key(x); self.topic = k or x
        if not k:
            self.pending = ["word", x]; self.rt.study.note_gap(x)
            return [out("text", f"I do not know what {art(x)} {x} is. Can you tell me?")]
        o = []
        for parent in D.chain(k)[:3]:
            s = self.rt._speak(k, "is_a", parent) if " " not in parent else None
            if s: o.append(out("text", s["english"], refs=[k, parent])); break
        o.append(out("status", f"My dictionary defines {k} as: {D.define(k, 'n') or D.define(k)}.", refs=[k]))
        return o

    def why(self, x, y):
        D = self.rt.K
        kx, ky = D.key(x), D.key(y)
        path = D.path(kx, ky) if kx and ky and hasattr(D, "path") else []
        if len(path) < 2: return [out("text", f"I cannot say why. I have no path from {x} to {y}.")]
        links = [f"{art(a)} {a} is {art(b)} {b}" for a, b in zip(path, path[1:])]
        return [out("text", "Because " + (", ".join(links[:-1]) + ", and " + links[-1] if len(links) > 1 else links[0]) + ".", refs=path)]

    # ---- glyph strings: his registries only ------------------------------------------------------
    def spellings(self):
        if self._spell is None:
            self._spell = {}
            for w in self.rt.D.idx if self.rt.D else self.rt.K.order:
                if re.fullmatch(r"[a-z]+", w):
                    self._spell.setdefault(lhea_glyphs(decompose(w)), []).append(w)
        return self._spell

    def glyphs(self, text):
        toks = [m.group(0) for m in HEB.finditer(text)]
        o = []
        for s in toks:
            letters = [(g, GLYPHS[g]["operation"] if g in GLYPHS else "unregistered", VAL.get(g, 0)) for g in s]
            total = sum(v for _, _, v in letters)
            rev = s[::-1]
            facts = [f"{s}: " + ", ".join(f"{g} is {op} ({v})" for g, op, v in letters) + f". Together they sum to {total}."]
            facts.append(f"Reversed it reads {rev}" + (", the same string." if rev == s else "."))
            counts = {g: s.count(g) for g in dict.fromkeys(s) if s.count(g) > 1}
            if counts: facts.append("Repeated: " + ", ".join(f"{g} {n} times" for g, n in counts.items()) + ".")
            for other in toks + list(self.strings):
                if other != s and len(other) < len(s) and _subseq(other, s):
                    facts.append(f"It contains {other} in order."); break
            words = self.spellings().get(s, [])
            facts.append(f"In my dictionary, {', '.join(words[:6])} spell{'s' if len(words) == 1 else ''} it the same way." if words
                         else "No word in my dictionary spells it that way.")
            known = self.strings.get(s)
            if known and known.get("meanings"):
                facts.append("I am holding a meaning for it from " + ", ".join(f"{m['by']}: '{m['text']}'" for m in known["meanings"]) + ".")
            else:
                self.strings.setdefault(s, {"author": self.speaker or "you", "status": "candidate, meaning unassigned",
                                            "constituents": [op for _, op, _ in letters], "sum": total})
            o.append(out("text", " ".join(facts)))
        unknown = [s for s in toks if not self.strings.get(s, {}).get("meanings")]
        if unknown:
            self.pending = ["glyph", unknown[0]]
            o.append(out("text", f"I have no meaning registered for {unknown[0]}. What does it mean?"))
        return o


def _subseq(a, b):
    it = iter(b)
    return all(ch in it for ch in a)
