"""ECHO's dictionary: all of WordNet 3.0 (built by build_dictionary.py), loaded from data/dictionary.json.gz.
Same interface as the 900-word snapshot in knowledge.py, so audits, the Lobby and conversation read from it
the moment it is attached."""
import gzip, json
from functools import lru_cache

MORPH = {"n": [("ses", "s"), ("xes", "x"), ("zes", "z"), ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y"), ("s", "")],
         "v": [("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""), ("ing", "e"), ("ing", ""), ("s", "")],
         "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")]}


class Dictionary:
    label = "dictionary (WordNet 3.0)"

    def __init__(self, path):
        with gzip.open(path, "rb") as f:
            d = json.loads(f.read().decode("utf-8"))
        self.syn, self.idx, self.source = d["syn"], d["idx"], d["source"]
        self.order, self.defs = [], {}          # filled by the runtime with his Lobby vocabulary

    def key(self, w):
        w = (w or "").lower().strip().replace("_", " ")
        if w in self.idx: return w
        for pos in ("n", "v", "a"):
            for suf, rep in MORPH[pos]:
                if w.endswith(suf) and len(w) > len(suf) + 1:
                    base = w[: -len(suf)] + rep
                    if base in self.idx and any(self.syn[s][0] == pos for s in self.idx[base]): return base
        return None

    def has(self, w): return self.key(w) is not None
    def lemma(self, w): return self.key(w) or w
    def senses(self, w, pos=None, top=None):
        k = self.key(w); s = self.idx.get(k, []) if k else []
        if pos: s = [i for i in s if self.syn[i][0] == pos]
        return s[:top] if top else s
    def define(self, w, pos=None):
        s = self.senses(w, pos, 1) or self.senses(w, None, 1)
        return self.syn[s[0]][1] if s else ""
    def pos_of(self, w): return sorted({self.syn[i][0] for i in self.senses(w)})

    @lru_cache(maxsize=200000)
    def ancestors(self, i):
        """{ancestor index: steps up} following hypernyms (and instance hypernyms)."""
        out, frontier, d = {}, [i], 0
        while frontier and d < 20:
            d += 1; nxt = []
            for s in frontier:
                for h in self.syn[s][2]:
                    if h not in out: out[h] = d; nxt.append(h)
            frontier = nxt
        return out

    def relate(self, a, b, top=2, pos=("n",)):
        """('is_a', d) when b is d steps above a, using each word's most common senses; ('includes', d) the other way.
        Nouns only by default: his Lobby and his sentences are built of nouns."""
        best = None
        for sa in [x for x in self.senses(a) if self.syn[x][0] in pos][:top]:
            for sb in [x for x in self.senses(b) if self.syn[x][0] == self.syn[sa][0]][:top]:
                d = self.ancestors(sa).get(sb)
                if d and (best is None or d < best[1]): best = ("is_a", d, sa, sb)
                d = self.ancestors(sb).get(sa)
                if d and (best is None or d < best[1]): best = ("includes", d, sa, sb)
        return best[:2] if best else None

    def path(self, a, b, top=2):
        """The chain of words from a up to b (both included), or []."""
        for sa in [x for x in self.senses(a) if self.syn[x][0] in ("n", "v")][:top]:
            for sb in [x for x in self.senses(b) if self.syn[x][0] == self.syn[sa][0]][:top]:
                if sb in self.ancestors(sa):
                    chain, cur = [sa], sa
                    while cur != sb:
                        nxt = min((h for h in self.syn[cur][2] if h == sb or sb in self.ancestors(h)), key=lambda h: 0 if h == sb else self.ancestors(h)[sb])
                        chain.append(nxt); cur = nxt
                    return [self.syn[c][3][0] for c in chain]
        return []

    def chain(self, w, limit=12):
        s = self.senses(w, "n", 1) or self.senses(w, "v", 1)
        if not s: return []
        out, cur = [], s[0]
        while self.syn[cur][2] and len(out) < limit:
            cur = self.syn[cur][2][0]; out.append(self.syn[cur][3][0])
        return out
