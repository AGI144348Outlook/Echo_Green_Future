"""The Forge: description -> WidgetSpec made only of registered parts. No generated code runs.

Parts:    clock, timer, notes, number, slider, toggle, input, button, output, list, resident,
          query, preview, feed, ask
Actions:  calc (arithmetic over number/slider parts), ask (send to ECHO), resolve, query,
          fetch (a crawler source), clear
The page validates the spec again before it builds anything.
"""
import re

NUM_WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5}
OPS = [(r"\b(multipl\w*|times|product)\b", "*", "Multiply"), (r"\b(divid\w*|ratio|quotient)\b", "/", "Divide"),
       (r"\b(subtract\w*|minus|difference)\b", "-", "Subtract"), (r"\b(averag\w*|mean)\b", "avg", "Average"),
       (r"\b(add\w*|sums?|plus|total)\b", "+", "Add")]
FEEDS = {"solar wind": "NOAA_SWPC_SOLAR_WIND_MAG", "kp": "NOAA_SWPC_KP_INDEX", "geomagnetic": "NOAA_SWPC_KP_INDEX",
         "x-ray": "NOAA_SWPC_XRAY", "xray": "NOAA_SWPC_XRAY", "aurora": "NOAA_SWPC_AURORA", "earthquake": "USGS_EARTHQUAKES_4_5_DAY",
         "quake": "USGS_EARTHQUAKES_4_5_DAY", "plasma": "NOAA_SWPC_PLASMA", "significant": "USGS_EARTHQUAKES_SIGNIFICANT"}
FILLER = set("a an the and with that for me my widget tool make build forge create which shows show can to of in on it one please "
             "window panel box some that's showing lets let's i want need called named titled".split())


def compose(text):
    t = (text or "").strip(); low = t.lower()
    title = None
    m = re.search(r"\b(?:called|named|titled)\s+[\"']?([^\"',.]+)", t, re.I)
    if m: title = m.group(1).strip(); low = low.replace(m.group(0).lower(), " ")
    controls, bindings, used = [], [], set()
    def add(kind, **kw):
        cid = f"{kind}{sum(1 for c in controls if c['kind'] == kind) + 1}"
        controls.append({"id": cid, "kind": kind, **kw}); return cid
    def mark(*words): used.update(words)

    if re.search(r"\b(clock|time now|current time)\b", low): add("clock", label="Time"); mark("clock", "time", "current", "now")
    if re.search(r"\b(timer|stopwatch|countdown)\b", low): add("timer", label="Timer"); mark("timer", "stopwatch", "countdown")
    if re.search(r"\b(notes?|notepad|scratch ?pad|journal)\b", low): add("notes", label="Notes"); mark("note", "notes", "notepad", "scratch", "pad", "journal")
    op = next(((sym, name) for pat, sym, name in OPS if re.search(pat, low)), None)
    if op or re.search(r"\b(calculator|number inputs?|numbers)\b", low):
        cnt = 2
        m = re.search(r"\b(one|two|three|four|five|\d)\s+(?:number|numeric|value|input)", low)
        if m: cnt = int(m.group(1)) if m.group(1).isdigit() else NUM_WORDS[m.group(1)]
        sym, name = op or ("+", "Add")
        ids = [add("number", label=f"Value {i + 1}", value=0) for i in range(max(1, min(cnt, 6)))]
        b = add("button", label=name); o = add("output", label="Result")
        bindings.append({"on": b, "do": "calc", "op": sym, "inputs": ids, "into": o})
        mark("calculator", "number", "numbers", "inputs", "input", "value", "values", "button", "output", "result", *NUM_WORDS,
             *[w for pat, _, _ in OPS for w in re.findall(r"[a-z]+", pat)])
        used.update(w for w in re.findall(r"[a-z]+", low) if any(re.fullmatch(p.replace("\\b", ""), w) for p, _, _ in OPS))
    if re.search(r"\bslider\b", low): add("slider", label="Slider", min=0, max=100, value=50); mark("slider")
    if re.search(r"\b(toggle|switch)\b", low): add("toggle", label="Toggle"); mark("toggle", "switch")
    if re.search(r"\b(checklist|to-?do|list)\b", low): add("list", label="List"); mark("checklist", "todo", "to-do", "list")
    if re.search(r"\b(preview|html)\b", low): add("preview", label="Preview"); mark("preview", "html")
    if re.search(r"\b(ask|talk|chat|converse)\b", low):
        i = add("input", label="Say to ECHO"); b = add("button", label="Ask"); o = add("output", label="ECHO")
        bindings.append({"on": b, "do": "ask", "inputs": [i], "into": o}); mark("ask", "talk", "chat", "converse", "echo")
    m = re.search(r"\b(?:resolve|define|look up|lookup|dictionary|explore|explorer for|generali[sz]ations? of)\s+(?:of\s+)?([a-z]+)?", low)
    if m or re.search(r"\b(dictionary|resident|word card)\b", low):
        word = (m.group(1) if m and m.group(1) and m.group(1) not in FILLER else "") if m else ""
        i = add("input", label="Word", value=word); c = add("resident", label="Resident", word=word)
        bindings.append({"on": i, "do": "resolve", "inputs": [i], "into": c})
        mark("resolve", "define", "look", "up", "lookup", "dictionary", "explore", "explorer", "resident", "word", "card",
             "generalization", "generalizations", "generalisations", word)
    if re.search(r"\b(query|formula|matrix|matrices|analogy|proportion)\b", low):
        mid = next((x for x in ("lobby", "registry", "glyphs", "hexagrams", "algorithms") if x in low), "lobby")
        q = add("query", label="Governor query", matrix=mid, formula="|{dog:canine::cat:x}|")
        mark("query", "formula", "matrix", "matrices", "analogy", "proportion", "governor", mid)
    for key, src in FEEDS.items():
        if key in low:
            add("feed", label=key.title() + " feed", source=src); mark(*key.split(), "feed", "sensor", "data", "live"); break
    else:
        if re.search(r"\b(feed|sensor|geosensory)\b", low):
            add("feed", label="Kp index feed", source="NOAA_SWPC_KP_INDEX"); mark("feed", "sensor", "geosensory", "data", "live")
    words = [w for w in re.findall(r"[a-z][a-z-]+", low) if w not in FILLER and w not in used and not w.isdigit()]
    if not controls:
        add("notes", label="Notes")
    return {"title": (title or _title(controls))[:48], "controls": controls[:24], "bindings": bindings,
            "unrecognized": sorted(set(words))[:8], "source": t[:300], "spec": "echo.widget/0.1"}


def _title(controls):
    kinds = [c["kind"] for c in controls]
    if "button" in kinds and "input" in kinds and "output" in kinds and "number" not in kinds: return "Ask ECHO"
    for k, name in (("feed", "Live feed"), ("query", "Governor query"), ("resident", "Resident explorer"),
                    ("clock", "Clock"), ("timer", "Timer"), ("number", "Calculator"), ("preview", "Preview"), ("notes", "Notes")):
        if k in kinds: return name
    return "Widget"
