"""Build ECHO's offline knowledge snapshot: the 900-word Lobby vocabulary (same frontier as E7/E12),
definitions, the two most common noun senses per word with their is-a ancestors, and noun lemmas."""
import json
from nltk.corpus import wordnet as wn
from lemminflect import getLemma
from echo.matrix.registry import Registry
reg = Registry(); frontier, seen, order = list(reg.canonical), set(), []
while frontier and len(seen) < 900:
    w = frontier.pop(0)
    if w in seen: continue
    ss = wn.synsets(w.replace(" ", "_"), "n")
    if not ss: continue
    seen.add(w); order.append(w); d = ss[0].definition()
    for tok in d.replace(",", " ").replace(";", " ").split():
        t = tok.lower().strip("()'\"")
        if t.isalpha() and len(t) > 3 and t not in seen and wn.synsets(t, "n"): frontier.append(t)
syn_ix, syns = {}, []
def sid(s):
    if s not in syn_ix: syn_ix[s] = len(syns); syns.append(s)
    return syn_ix[s]
senses, defs, lemma = {}, {}, {}
for w in order:
    ss = wn.synsets(w.replace(" ", "_"), "n")
    defs[w] = ss[0].definition()
    lemma[w] = getLemma(w, upos="NOUN")[0] if " " not in w else w
    out = []
    for s in ss[:2]:
        anc = {}
        for path in s.hypernym_paths():
            for i, a in enumerate(reversed(path)):
                if i and (a.name() not in anc or i < anc[a.name()]): anc[a.name()] = i
        out.append([sid(s.name()), {str(sid(a)): d for a, d in anc.items()}])
    senses[w] = out
json.dump({"version": 1, "source": "WordNet 3.0 via NLTK", "order": order, "definitions": defs, "lemma": lemma,
           "synsets": syns, "senses": senses}, open("echo/data/lobby_snapshot.json", "w"), separators=(",", ":"))
import os; print(len(order), "words |", len(syns), "senses |", os.path.getsize("echo/data/lobby_snapshot.json") // 1024, "KB")
