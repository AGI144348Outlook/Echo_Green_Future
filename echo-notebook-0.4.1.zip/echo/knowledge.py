"""ECHO's offline knowledge: the 900-word Lobby snapshot (definitions, common senses, is-a ancestry).
Built from WordNet 3.0 in CPython (experiments/build_snapshot.py); read-only here."""
import json, os

_PATH = os.path.join(os.path.dirname(__file__), "data", "lobby_snapshot.json")


class Knowledge:
    label = "lobby snapshot"

    def __init__(self):
        with open(_PATH, encoding="utf-8") as f:
            d = json.load(f)
        self.order, self.defs, self.lemmas, self.syn = d["order"], d["definitions"], d["lemma"], d["synsets"]
        self.senses = {w: [(s, {int(k): v for k, v in anc.items()}) for s, anc in lst] for w, lst in d["senses"].items()}
        self.by_lemma = {}
        for w in self.order:
            self.by_lemma.setdefault(self.lemmas.get(w, w), w)

    def key(self, w):
        w = (w or "").lower().strip()
        if w in self.senses: return w
        return self.by_lemma.get(w)

    def has(self, w): return self.key(w) is not None
    def define(self, w): k = self.key(w); return self.defs.get(k, "") if k else ""
    def lemma(self, w): k = self.key(w); return self.lemmas.get(k, w) if k else w

    def relate(self, a, b):
        """('is_a', d) when b is d steps above a in a common sense; ('includes', d) the other way."""
        ka, kb = self.key(a), self.key(b)
        if not ka or not kb: return None
        best = None
        for sa, anc_a in self.senses[ka]:
            for sb, anc_b in self.senses[kb]:
                if sb in anc_a and (best is None or anc_a[sb] < best[1]): best = ("is_a", anc_a[sb])
                if sa in anc_b and (best is None or anc_b[sa] < best[1]): best = ("includes", anc_b[sa])
        return best

    def chain(self, w, limit=12):
        """The first sense's hypernym path, as synset names, nearest first."""
        k = self.key(w)
        if not k: return []
        anc = self.senses[k][0][1]
        return [self.syn[s].split(".")[0].replace("_", " ") for s, d in sorted(anc.items(), key=lambda t: t[1])][:limit]


_K = None
_DICT = None
def get():
    """The full dictionary once attached; the 900-word snapshot until then."""
    global _K
    if _DICT is not None: return _DICT
    if _K is None: _K = Knowledge()
    return _K

def snapshot():
    global _K
    if _K is None: _K = Knowledge()
    return _K

def attach_dictionary(path):
    global _DICT
    from .dictionary import Dictionary
    _DICT = Dictionary(path)
    return _DICT
