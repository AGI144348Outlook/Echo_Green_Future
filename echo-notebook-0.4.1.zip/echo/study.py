"""ECHO's self-study of his dictionary, and his Map Matrix.

He chooses what to study from his own state, in this order:
  1. gaps: words he met in conversation and could not place
  2. frontier: dictionary words that appear in the most definitions already in his Lobby
     (his kernel's own record of which words his definitions lean on)
Studying a word = his kernel indexes its dictionary definition; every few words his Lobby is rebuilt by
his own Lobby code, so new ties form by the same rule as all his others. Each study is recorded in the
Map Matrix: what he studied, why he chose it, the ties it formed, the is-a paths he can verify, and the
sentences about it that pass his audits.
"""
import re
from collections import Counter

STOP = set("that which with from this have been were their there they them than then into over such other when what where "
           "used also more most some made make only very each both many much being does done having your about these those "
           "whose while upon onto".split())


class Study:
    def __init__(self, rt, state):
        self.rt = rt
        self.studied = state.get("studied", [])            # words, in the order he studied them
        self.maps = state.get("maps", [])                  # the Map Matrix
        self.gaps = state.get("gaps", [])
        self.pending = []                                  # studied since the last Lobby rebuild

    def note_gap(self, w):
        w = w.lower()
        if w not in self.gaps and w not in self.studied and self.rt.D and self.rt.D.has(w): self.gaps.append(w)

    def frontier(self, n=1):
        """Dictionary words his Lobby's definitions use most, that he has not yet admitted."""
        D, km, lobby = self.rt.D, self.rt.km, self.rt.lobby
        use = Counter()
        for w, agent in lobby.agents.items():
            for t in km.transitions.get(w, {}):
                if t not in lobby.agents and len(t) > 3 and t.isalpha() and t not in STOP: use[t] += 1
        done = set(self.studied)
        ranked = [(c, t) for t, c in use.items()
                  if D.has(t) and D.key(t) not in done and D.key(t) not in lobby.agents and "n" in D.pos_of(t)]
        ranked.sort(key=lambda x: (-x[0], x[1]))
        return ranked[:n]

    def step(self):
        """Study one word he chooses. Returns the Map Matrix record."""
        D = self.rt.D
        if D is None: return {"ok": False, "reason": "my dictionary is not loaded yet"}
        src, why, w = None, "", None
        while self.gaps and w is None:
            g = self.gaps.pop(0); k = D.key(g)
            if k and k not in self.rt.lobby.agents and k not in self.studied: w, src, why = k, "gap", f"you used '{g}' and I could not place it"
        if w is None:
            f = self.frontier(1)
            if not f: return {"ok": False, "reason": "no word left that my definitions lean on"}
            c, t = f[0]; w = D.key(t); src = "frontier"
            users = [a for a in self.rt.lobby.agents if t in self.rt.km.transitions.get(a, {})][:4]
            why = f"{c} of my definitions use it ({', '.join(users)})"
        pos = D.pos_of(w)
        definition = D.define(w, "n") or D.define(w)
        self.rt.km.index_dictionary_entry(w, definition, pos="noun" if "n" in pos else ("verb" if "v" in pos else "adjective"), category="study")
        self.studied.append(w); self.pending.append(w)
        rec = {"n": len(self.studied), "word": w, "source": src, "why": why, "definition": definition, "pos": pos,
               "chain": D.chain(w)[:6], "ties": [], "verified": [], "turn": self.rt.rec.turn}
        self.maps.append(rec)
        if len(self.pending) >= 8: self.consolidate()
        return {"ok": True, "record": rec}

    def consolidate(self):
        """Rebuild his Lobby with his own code, then record what each newly studied word connected to."""
        if not self.pending: return []
        self.rt.rebuild_lobby()
        done = []
        for w in self.pending:
            rec = next((m for m in reversed(self.maps) if m["word"] == w), None)
            if not rec: continue
            ties = sorted(self.rt.rec.ties.get(w, []))[:12]
            rec["ties"] = ties
            for t in ties[:12]:
                r = self.rt.D.relate(w, t)
                if r and r[1] <= 3:
                    s = self.rt._speak(w, r[0], t)
                    if s: rec["verified"].append(s["english"])
            done.append(w)
        self.pending = []
        return done

    def summary(self):
        return {"studied": len(self.studied), "lobby words": len(self.rt.lobby.agents), "lobby ties": len(self.rt.lobby.ties),
                "gaps waiting": len(self.gaps), "maps": len(self.maps),
                "sentences verified in maps": sum(len(m["verified"]) for m in self.maps)}

    def state(self):
        return {"studied": self.studied, "maps": self.maps[-2000:], "gaps": self.gaps[:200]}
