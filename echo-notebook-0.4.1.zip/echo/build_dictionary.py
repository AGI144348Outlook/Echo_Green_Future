"""Build ECHO's dictionary (all of WordNet 3.0: nouns, verbs, adjectives, adverbs) as one gzip JSON file.
  syn[i] = [pos, definition, [hypernym indices], [lemmas]]     idx[lemma] = [synset indices, most common first]
WordNet is (c) Princeton University, distributed under the WordNet 3.0 license (free use with notice)."""
import json, gzip, os
from nltk.corpus import wordnet as wn
syns = list(wn.all_synsets())
ix = {s.name(): i for i, s in enumerate(syns)}
syn = [[s.pos().replace("s", "a"), s.definition(), [ix[h.name()] for h in s.hypernyms() + s.instance_hypernyms()],
        [l.name().replace("_", " ").lower() for l in s.lemmas()]] for s in syns]
idx = {}
for lemma in wn.all_lemma_names():
    key = lemma.replace("_", " ").lower()
    idx[key] = [ix[s.name()] for s in wn.synsets(lemma)]
data = {"v": 1, "source": "WordNet 3.0, Princeton University (via NLTK). License: WordNet 3.0 license, free use with notice.",
        "syn": syn, "idx": idx}
raw = json.dumps(data, separators=(",", ":"), ensure_ascii=False).encode()
out = os.path.join(os.path.dirname(__file__), "data", "dictionary.json.gz")
with gzip.open(out, "wb", compresslevel=9) as f: f.write(raw)
print(len(syn), "senses |", len(idx), "words |", len(raw) // 2**20, "MB raw |", os.path.getsize(out) // 2**20, "MB gzip")
