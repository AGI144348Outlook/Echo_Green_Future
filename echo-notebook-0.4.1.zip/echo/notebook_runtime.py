"""ECHO's Notebook runtime: everything the Web Worker exposes, one JSON seam.

  boot(state)        rebuild ECHO: Registry, kernel, his 900-word Lobby (built by his own Lobby code
                     from the snapshot), KSM Recess, audits, Governor matrices; restore saved state
  handle(text,mode)  conversation: EMEL statements, formula queries (EMEL or G[...]), commands, free text
  recess(n)          n turns of his Canvas Recess (A-101 picks, A-113 judges every 20 turns)
  suggest(word)      your suggestion; ECHO accepts only if it resolves and connects to his map
  forge(text)        compose a WidgetSpec from a description (validated again by the page)
  matrices / query / browse / identify / cycle / resolve / plane / save / canvas
"""
import json, math, re, time
from .kernel import K, HEBREW_LETTER_INDEX, kernel_lines
from .matrix.registry import Registry
from . import knowledge
from .canvas.ks_recess import KSRecess, ARMS
from .language.parser import parse as emel_parse, Parser, ParseError
from .language.lexicon import Lexicon, GLYPHS
from .language.audit import Auditor
from .language.realize import english, emel
from .language.english_parse import EnglishParser
from .language.ast import to_dict, Relation, Property, Proportion, Continued
from .language.index_pattern import parse as pattern_parse, PatternError
from .language.pyform import compile_py, FormError
from .language.gov_index import Governor, Matrix, glyph_matrix, hexagram_matrix, registry_matrix
from . import forge as forge_mod
from .study import Study
from .language import projective as PJ
from .dialogue import Dialogue

SESSION = 20
RT = None


def _j(x): return json.dumps(x, ensure_ascii=False)
def out(kind, text, **kw): return {"actor": "echo", "kind": kind, "text": text, "refs": kw.pop("refs", []), **kw}


class Runtime:
    def __init__(self, state):
        t0 = time.time()
        self.K = knowledge.get()
        self.reg = Registry(); self.reg.load_overlay(state.get("overlay", {}))
        self.km = K.AlgorithmMatrix()
        for w in self.K.order:
            self.km.index_dictionary_entry(w, self.K.defs[w], pos="noun", category="lobby")
        self.lobby = K.Lobby(self.km); self.lobby.populate(); self.lobby.run_orientation(); self.lobby.matrix = self.km
        raw = self.lobby.compute_generality_scores() or {}
        self.gscore = {w: g for w, g in raw.items() if w in self.lobby.agents and " " not in w and self.K.has(w)}
        self.lex = Lexicon(self.reg, {}); self.aud = Auditor(self.reg, {})
        self.ep = EnglishParser(lambda: Parser([], self.lex))
        self.spoken = set(tuple(x) for x in state.get("spoken", []))
        self.rec = KSRecess(K, self.lobby, self.gscore, self._relate, self._speak, self.K.define)
        self.links, self.recess_log, self.checkpoints = state.get("links", []), state.get("recess_log", [])[-300:], state.get("checkpoints", [])
        self._restore(state.get("recess"))
        self.matrices = self._matrices()
        self.D = None
        self.study = Study(self, state.get("study", {}))
        self.dialogue = Dialogue(self, state.get("dialogue", {}))
        self.boot_seconds = round(time.time() - t0, 2)

    # ---- dictionary and study ----------------------------------------------------------------------
    def attach_dictionary(self, path):
        t0 = time.time()
        self.D = knowledge.attach_dictionary(path); self.K = self.D
        for w in self.study.studied:
            self.km.index_dictionary_entry(w, self.D.define(w, "n") or self.D.define(w), pos="noun", category="study")
        self.rebuild_lobby()
        return {"ok": True, "words": len(self.D.idx), "senses": len(self.D.syn), "restored studies": len(self.study.studied),
                "seconds": round(time.time() - t0, 2), **self.study.summary()}

    def rebuild_lobby(self):
        """His own Lobby code, run again over everything his kernel has indexed."""
        lobby = K.Lobby(self.km); lobby.populate(); lobby.run_orientation(); lobby.matrix = self.km
        raw = lobby.compute_generality_scores() or {}
        self.lobby = lobby
        self.gscore = {w: g for w, g in raw.items() if w in lobby.agents and " " not in w and self.K.has(w)}
        self.rec.refresh(lobby, self.gscore)
        self.matrices = self._matrices()

    # ---- ECHO's own relation and speech (audited) ------------------------------------------
    def _relate(self, a, b):
        return self.K.relate(a, b)

    def _speak(self, u, kind, v):
        if not re.fullmatch(r"[a-z]+", u or "") or not re.fullmatch(r"[a-z]+", v or ""): return None
        u, v = self.K.lemma(u), self.K.lemma(v)
        if hasattr(self.K, "pos_of") and not ("n" in self.K.pos_of(u) and "n" in self.K.pos_of(v)): return None
        if u.endswith("ing") or v.endswith("ing") or u == v or (u, kind, v) in self.spoken: return None
        try: n = emel_parse(f"{u} {kind} {v}", self.lex)
        except ParseError: return None
        if self.aud.truth(n)[0] != "SUPPORTED": return None
        text = english(n)
        if to_dict(self.ep.sentence(text)) != to_dict(n): return None
        self.spoken.add((u, kind, v))
        return {"english": text, "emel": emel(n), "audits": "lexical, type, semantic, grammar: PASS"}

    # ---- Recess state --------------------------------------------------------------------------
    def _restore(self, s):
        if not s: return
        r = self.rec
        r.planes, r.turn, r.session, r.next_group = s["planes"], s["turn"], s["session"], s["next_group"]
        r.aligned = set(tuple(x) for x in s["aligned"])
        for k, v in s.get("history", {}).items():
            self.km.history[(k, "canvas")] = tuple(v)

    def state(self):
        r = self.rec
        return {"recess": {"planes": r.planes, "turn": r.turn, "session": r.session, "next_group": r.next_group,
                           "aligned": sorted(list(x) for x in r.aligned),
                           "history": {k[0]: list(v) for k, v in self.km.history.items() if k[1] == "canvas"}},
                "spoken": sorted(list(x) for x in self.spoken), "links": self.links[-400:],
                "recess_log": self.recess_log[-300:], "checkpoints": self.checkpoints[-60:],
                "overlay": self.reg.export_overlay(), "study": self.study.state(), "dialogue": self.dialogue.state()}

    def recess(self, n=1):
        r, entries = self.rec, []
        for _ in range(max(1, int(n))):
            if not r.planes:
                canon = [w for w in self.reg.canonical if w in self.gscore]
                start = max(canon, key=lambda w: (self.gscore[w], w)) if canon else self.K.order[0]
                ops = []; r.presentiate(ops, start, 600, "his most general canonical resident in the Lobby")
                e = {"turn": 0, "session": 1, "arm": "START", "ok": True, "ops": ops, "say": [], "reason": ops[0]["reason"]}
            else:
                r.turn += 1; r.session = (r.turn - 1) // SESSION + 1
                arm = self.km.bandit_select("canvas", ARMS)
                ops, say = [], []
                ok, why = getattr(r, arm.lower())(ops, say)
                self.km.record_outcome(arm, "canvas", ok)
                e = {"turn": r.turn, "session": r.session, "arm": arm, "ok": ok, "ops": ops, "say": say, "reason": why}
                if r.turn % SESSION == 0:
                    cp = self.km.checkpoint_generation()
                    e["checkpoint"] = {"decision": cp["decision"], "reason": cp.get("reason", ""), "session": r.session}
                    self.checkpoints.append(e["checkpoint"])
            for o in e["ops"]:
                if o["op"] == "ALIGN": self.links.append({k: o[k] for k in ("a", "b", "sa", "sb", "kind")} | {"turn": e["turn"]})
            self.recess_log.append({k: e[k] for k in ("turn", "session", "arm", "ok", "reason")})
            entries.append(e)
        return entries

    def canvas(self):
        return {"planes": self.rec.planes, "links": self.links[-400:], "turn": self.rec.turn, "session": self.rec.session}

    def plane(self, pid):
        p = self.rec.planes.get(pid)
        if not p: return None
        return {"plane": p, "definition": self.K.define(pid), "generality": round(self.rec.gn.get(pid, 0), 3),
                "history": [e for e in self.recess_log if pid in e["reason"].replace(",", " ").split()][-20:]}

    # ---- suggestions: ECHO decides -----------------------------------------------------------
    def suggest(self, word):
        w = (word or "").strip().lower()
        k = self.K.key(w)
        if not k or k not in self.gscore:
            return {"accepted": False, "reason": f"'{w}' is not in my Lobby, so I have no way to place it yet.", "ops": []}
        if k in self.rec.planes:
            return {"accepted": False, "reason": f"'{k}' is already on my Canvas.", "ops": []}
        best = None
        for p in self.rec.planes.values():
            if p["hidden"]: continue
            tie = k in self.rec.ties.get(p["word"], [])[:24] or p["word"] in self.rec.ties.get(k, [])[:24]
            rel = self.K.relate(k, p["word"])
            score = (3 if rel and rel[1] <= 2 else 0) + (2 if tie else 0)
            if score and (best is None or score > best[0]): best = (score, p, rel, tie)
        if not best:
            return {"accepted": False, "reason": f"'{k}' has no tie or is-a relation to anything on my Canvas yet.", "ops": []}
        score, p, rel, tie = best
        ops = []; self.rec.turn += 0
        how = (f"{rel[0].replace('_', '-')} {p['word']}" if rel and rel[1] <= 2 else f"tied to {p['word']} in my Lobby")
        self.rec.presentiate(ops, k, p["x"] + p["r"] + 70, f"accepted Tim's suggestion: {how}")
        self.recess_log.append({"turn": self.rec.turn, "session": self.rec.session, "arm": "SUGGESTION", "ok": True, "reason": f"accepted {k}: {how}"})
        return {"accepted": True, "reason": f"Accepted '{k}': {how}.", "ops": ops}

    # ---- matrices and the Governor ---------------------------------------------------------------
    def _matrices(self):
        g = self.gscore
        lobby = Matrix("ECHO's Lobby", sorted(g), lambda w: self.K.key(w.replace("_", " ")) if self.K.key(w.replace("_", " ")) in g else None,
                       lambda e: g.get(e), lambda a, b: self.K.relate(a, b), "typed")
        algos = sorted(k for k in self.km.known if k.startswith("A-") and k[2:].isdigit())
        alg = Matrix("Governor algorithm matrix", algos, lambda w: w.upper() if w.upper() in algos else None,
                     lambda e: int(e[2:]), lambda a, b: int(b[2:]) - int(a[2:]), "diff")
        return {"lobby": lobby, "registry": registry_matrix(self.reg), "glyphs": glyph_matrix(),
                "hexagrams": hexagram_matrix(), "algorithms": alg}

    def list_matrices(self):
        return [{"id": k, "name": m.name, "entries": len(m.entries), "ordered": m.ordered, "relation": m.algebra}
                for k, m in self.matrices.items()]

    def browse(self, mid, start=0, n=50):
        m = self.matrices[mid]
        rows = []
        for e in m.entries[start:start + n]:
            label = m.label(e)
            extra = self.K.define(label) if mid == "lobby" else (self.reg.resolve(label)["def"] if mid == "registry" else "")
            if mid == "glyphs": extra = e["operation"]
            if mid == "algorithms": extra = str(self.km.known.get(e, {}).get("name", "")) if isinstance(self.km.known.get(e), dict) else ""
            rows.append([label, str(m.order(e)) if m.ordered else "", extra[:90]])
        return {"matrix": m.name, "total": len(m.entries), "start": start, "rows": rows}

    def query(self, mid, formula):
        m = self.matrices.get(mid)
        if not m: return {"status": "CLOSED", "error": f"no matrix '{mid}'"}
        f = formula.strip()
        try:
            node = compile_py(f)[1] if f.startswith("G[") else pattern_parse(f)
        except (PatternError, FormError, SyntaxError) as e:
            return {"status": "CLOSED", "error": f"syntax: {e}"}
        r = Governor(m).open(node, limit=60000)
        r["matrix"] = m.name
        return r

    def identify(self):
        hist = {k[0]: list(v) for k, v in self.km.history.items() if k[1] == "canvas"}
        stuck = len(self.checkpoints) >= 2 and all(c["decision"] == "DISCARDED" for c in self.checkpoints[-2:])
        return {"identity": "\u05e8 ECHO, A-000 Governor", "kernel lines": kernel_lines(), "lobby words": len(self.lobby.agents),
                "lobby ties": len(self.lobby.ties), "registry residents": len(self.reg.canonical), "overlay residents": len(self.reg.overlay),
                "canvas planes": len(self.rec.planes), "recess turn": self.rec.turn, "session": self.rec.session,
                "A-101 history (successes, attempts)": hist,
                "last checkpoints": [c["decision"] for c in self.checkpoints[-6:]],
                "stuck": stuck, "boot seconds": self.boot_seconds}

    def cycle(self, text):
        st = K.State(content="", quality=0.0)
        st = K.run_cycle({}, st, K.Request(text=text, value=1.0), K.Context(value=0.5), self.km,
                         [{"id": "I-001", "check": lambda s: s.quality < 100}],
                         {"B_G": 20, "B_E": 10, "C_max": 50, "F_max": 20},
                         {"epsilon_max": 0.1, "delta_max": 5.0, "C_max": 50, "content_sim_min": 0.9})
        return {"input": text, "quality": round(st.quality, 3), "content": (st.content or "")[:120],
                "note": "Propose is still a single no-op candidate in the kernel (M-000-NOOP)."}

    def resolve(self, word):
        w = (word or "").strip().lower()
        r = self.reg.resolve(w)
        k = self.K.key(w)
        return {"word": w, "registry": r["source"], "definition": r["def"] if r["source"] != "gap" else self.K.define(w),
                "in lobby": bool(k), "chain": self.K.chain(w) if k else r["chain"], "lhea": r["lhea"], "glyphs": r["glyphs"],
                "gematria": r["gematria"], "on canvas": (k in self.rec.planes) if k else False}

    # ---- conversation ----------------------------------------------------------------------------
    def handle(self, text, mode="TEXT"):
        t = (text or "").strip(); low = t.lower(); o = []; res = {"outputs": o, "ops": []}
        if not t: return res
        if low in ("help", "?"):
            o.append(out("status", "Talk to me in EMEL (dog is_a canine), ask resolve dog, hypernyms of dog, "
                         "suggest <word>, forge <a widget description>, query lobby |{dog:canine::cat:x}| or G[dog:canine, cat:x], "
                         "matrices, identify, cycle <text>, teach <word> is-a <word>, recess. Anything else, I read for words I know.")); return res
        m = re.match(r"^(?:calc|math)\s+(.+)$", t, re.I)
        if m or any(c in t for c in "∞‰◯") or "%inv" in t or "%neg" in t:
            return self._projective(m.group(1) if m else t, res)
        m = re.match(r"^(?:suggest|add|place)\s+(.+)$", low)
        if m:
            s = self.suggest(m.group(1)); res["ops"] = s["ops"]
            o.append(out("status" if s["accepted"] else "text", s["reason"], refs=[m.group(1)])); return res
        m = re.match(r"^(?:forge|make|build)\s+(.+)$", t, re.I)
        if m:
            spec = forge_mod.compose(m.group(1)); res["widget"] = spec
            o.append(out("status", f"I composed a widget: {spec['title']} ({len(spec['controls'])} parts). "
                         + ("Unrecognized parts: " + ", ".join(spec["unrecognized"]) + "." if spec["unrecognized"] else ""))); return res
        m = re.match(r"^(?:resolve|define)\s+(?:an?\s+|the\s+)?(.+?)\??$", low)
        if m:
            r = self.resolve(m.group(1))
            rows = [[k, (", ".join(v) if isinstance(v, list) else str(v))] for k, v in r.items() if k != "word"]
            o.append(out("matrix", f"\u03c1({r['word']})", columns=["field", "value"], rows=rows, refs=[r["word"]] + r["chain"][:3])); return res
        m = re.match(r"^hypernyms? of\s+(.+)$", low)
        if m:
            ch = self.K.chain(m.group(1)); o.append(out("text", f"{m.group(1)} \u2192 " + (" \u2192 ".join(ch) if ch else "(not in my Lobby)"), refs=[m.group(1)] + ch)); return res
        if low == "matrices":
            o.append(out("matrix", "Matrices the Governor can open", columns=["id", "name", "entries", "relation"],
                         rows=[[x["id"], x["name"], str(x["entries"]), x["relation"]] for x in self.list_matrices()])); return res
        m = re.match(r"^query\s+(\w+)\s+(.+)$", t, re.I)
        if m or t.startswith("|") or t.startswith("G["):
            mid, f = (m.group(1).lower(), m.group(2)) if m else ("lobby", t)
            r = self.query(mid, f); o.append(self._query_out(r, f)); return res
        if low == "identify":
            r = self.identify(); o.append(out("matrix", "IDENTIFY", columns=["field", "value"], rows=[[k, json.dumps(v) if isinstance(v, (dict, list)) else str(v)] for k, v in r.items()]))
            if r["stuck"]: o.append(out("status", "My last two sessions were discarded by A-113, so my selector keeps choosing the same activity. That is a known flaw in my kernel."))
            return res
        m = re.match(r"^cycle\s*(.*)$", low)
        if m:
            r = self.cycle(m.group(1) or "the governor indexes its own algorithms")
            o.append(out("matrix", "A-000 Governor cycle", columns=["field", "value"], rows=[[k, str(v)] for k, v in r.items()])); return res
        m = re.match(r"^teach\s+(.+?)\s+(?:is-a|is a|isa)\s+([^:]+?)(?:\s*:\s*(.+))?$", t, re.I)
        if m:
            ok, msg = self.reg.teach(m.group(1), m.group(2), (m.group(3) or "").strip()); o.append(out("status" if ok else "error", msg)); return res
        m = re.match(r"^study(?:\s+(\d+))?$", low)
        if m:
            recs = [self.study.step() for _ in range(int(m.group(1) or 1))]
            self.study.consolidate()
            ok = [r["record"] for r in recs if r.get("ok")]
            if not ok: o.append(out("status", recs[-1].get("reason", "Nothing to study."))); return res
            for r in ok[-3:]:
                o.append(out("text", f"I studied {r['word']} because {r['why']}." + (" " + " ".join(r["verified"][:2]) if r["verified"] else ""), refs=[r["word"]] + r["ties"][:4]))
            sm = self.study.summary(); o.append(out("status", f"Studied {sm['studied']} words so far. My Lobby has {sm['lobby words']} words and {sm['lobby ties']} ties.")); return res
        if low == "maps":
            sm = self.study.summary()
            rows = [[str(m["n"]), m["word"], m["source"], ", ".join(m["ties"][:4]), str(len(m["verified"]))] for m in self.study.maps[-12:]]
            o.append(out("matrix", f"Map Matrix: {sm['maps']} studies, {sm['sentences verified in maps']} verified sentences", columns=["#", "word", "chosen from", "ties", "verified"], rows=rows or [["", "nothing yet", "", "", ""]])); return res
        if low == "recess":
            h = self.identify()["A-101 history (successes, attempts)"]
            o.append(out("text", f"Recess turn {self.rec.turn}, session {self.rec.session}, {len(self.rec.planes)} planes. "
                         f"What I have learned about my activities: {h or 'nothing anchored yet'}.")); return res
        if any(k in f" {low} " for k in (" is_a ", " includes ", " antonym_of ")) or "::" in t or re.search(r"\.\w+\s*=", t):
            return self._emel(t, res)
        d = self.dialogue.turn(t)
        if d is not None:
            o.extend(d); return res
        return self._read(t, res)

    def _projective(self, expr, res):
        try: v = PJ.evaluate(expr)
        except Exception as e:
            res["outputs"].append(out("error", f"I could not evaluate that: {e}")); return res
        if isinstance(v, PJ.Permille):
            note = ("indeterminate (‰): any value is possible until a direction or a relation picks one."
                    + (" Approaching along a slope resolves it, for example along(0/0, 2) = 2." if v.origin in ("0/0", "∞/∞") else ""))
        elif v == PJ.INF: note = "the single point at infinity, at the top of the circle."
        elif isinstance(v, PJ.Space): note = f"closing it with one point at infinity gives the unit sphere {v!r}; it keeps dimension {v.dim}."
        else: note = f"a point on the circle at angle {PJ.theta(v):.4f}."
        res["outputs"].append(out("text", f"{expr} = {PJ.show(v)}: {note}"))
        return res

    def _query_out(self, r, f):
        if r["status"] != "OPEN":
            err = r.get("error") or "; ".join(r.get("validate", {}).get("errors", []) + [f"unresolved: {', '.join(r.get('identify', {}).get('unresolved', []))}"])
            return out("error", f"The Governor closed that query: {err}")
        if "holds" in r:
            return out("text", f"In {r['matrix']}, that {'holds' if r['holds'] else 'does not hold'}.")
        rows = [[", ".join(f"{k}={v}" for k, v in b.items())] for b in r["bindings"]]
        return out("matrix", f"{r['matches']} match(es) in {r['matrix']} ({r['mode']})", columns=["binding"], rows=rows or [["none"]],
                   refs=[v for b in r["bindings"][:6] for v in b.values() if isinstance(v, str)])

    def _emel(self, t, res):
        o = res["outputs"]
        try: n = emel_parse(t.replace(" is a ", " is_a "), self.lex)
        except ParseError as e:
            o.append(out("error", f"I could not parse that as EMEL: {e}")); return res
        lx, ty, (v, why) = self.aud.lexical(n), self.aud.type(n), self.aud.truth(n)
        text = english(n)
        try: back = to_dict(self.ep.sentence(text)) == to_dict(n)
        except Exception: back = False
        verdict = {"SUPPORTED": "That is supported", "CONTRADICTED": "That contradicts what I know", "UNKNOWN": "I cannot verify that",
                   "NOT_A_CLAIM": "That is an operation, not a claim"}.get(v, v)
        o.append(out("text", f"{text}\n{verdict}: {why}.", refs=[x.surface for x in _terms(n)][:6]))
        o.append(out("matrix", "Audits", columns=["audit", "result"], rows=[["lexical", lx["status"] + (f" (gaps: {', '.join(lx['gaps'])})" if lx["gaps"] else "")],
                     ["type", ty["status"] + (f" ({'; '.join(ty['errors'])})" if ty["errors"] else "")], ["semantic", v], ["grammar parse-back", "PASS" if back else "FAIL"]]))
        return res

    def _read(self, t, res):
        o = res["outputs"]
        words = [w.lower() for w in re.findall(r"[A-Za-z][A-Za-z'-]+", t)]
        stop = {"the", "and", "for", "with", "that", "this", "from", "have", "what", "about", "your", "you", "are", "was", "can", "how", "why",
                "who", "does", "will", "just", "echo", "there", "they", "them", "then", "than", "some", "like", "into", "tell", "talk", "hello", "hi",
                "me", "i", "my", "mine", "we", "us", "our", "he", "him", "his", "she", "her", "it", "its", "please", "know", "say", "said", "want"}
        known = [w for w in dict.fromkeys(words) if w not in stop and self.K.has(w)]
        gaps = [w for w in dict.fromkeys(words) if len(w) > 3 and w not in stop and not self.K.has(w) and not self.reg.has(w)]
        said = 0
        for w in known[:4]:
            k = self.K.key(w); ch = self.K.chain(k)
            spoke = None
            for parent in ch[:3]:
                if self.K.has(parent):
                    n = None
                    try: n = emel_parse(f"{self.K.lemma(k)} is_a {self.K.lemma(parent)}", self.lex)
                    except ParseError: pass
                    if n and self.aud.truth(n)[0] == "SUPPORTED":
                        text = english(n)
                        if to_dict(self.ep.sentence(text)) == to_dict(n): spoke = text; break
            if spoke: o.append(out("text", spoke, refs=[k])); said += 1
            else: o.append(out("status", f"{k}: {self.K.define(k)}", refs=[k]))
        for g in gaps: self.study.note_gap(g)
        if gaps: o.append(out("text", f"What is {gaps[0]}? I have no entry for it." + (f" (Also unknown to me: {', '.join(gaps[1:4])}.)" if len(gaps) > 1 else "")))
        if not known and not gaps: o.append(out("status", "I did not find a word I know there. Type help to see what I can do."))
        return res


def _terms(n):
    from .language.audit import terms
    return list(terms(n))


# ---- the JSON seam ------------------------------------------------------------------------------------
def boot(state_json="{}"):
    global RT
    RT = Runtime(json.loads(state_json or "{}"))
    return _j({"ok": True, "identity": RT.identify(), "canvas": RT.canvas(), "words": sorted(RT.gscore)})

def handle(text, mode="TEXT"): return _j(RT.handle(text, mode))
def recess(n=1): return _j(RT.recess(n))
def suggest(word): return _j(RT.suggest(word))
def forge(text): return _j(forge_mod.compose(text))
def matrices(): return _j(RT.list_matrices())
def browse(mid, start=0, n=50): return _j(RT.browse(mid, int(start), int(n)))
def query(mid, formula): return _j(RT.query(mid, formula))
def identify(): return _j(RT.identify())
def resolve(word): return _j(RT.resolve(word))
def plane(pid): return _j(RT.plane(pid))
def canvas(): return _j(RT.canvas())
def save(): return _j(RT.state())
def attach_dictionary(path): return _j(RT.attach_dictionary(path))
def study(n=1):
    recs = [RT.study.step() for _ in range(max(1, int(n)))]
    RT.study.consolidate()
    return _j({"records": [r.get("record") for r in recs if r.get("ok")], "summary": RT.study.summary(),
               "reason": recs[-1].get("reason", "")})
def maps(start=0, n=50): return _j({"summary": RT.study.summary(), "maps": RT.study.maps[int(start):int(start) + int(n)]})
