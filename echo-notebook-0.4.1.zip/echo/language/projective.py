"""Projective geometry for EMEL: numbers on a circle, % as mirrors, ‰ as the indeterminate, closure, parallels,
and lines on a sphere.

Numbers live on the projective line: every rational number plus one ∞. Each point sits on a circle at angle
theta = 2*atan(x): 0 at the bottom (0), 1 at pi/2, ∞ at the top (pi), -1 at -pi/2.
  %neg  x -> -x    reflection theta -> -theta        fixes 0 and ∞
  %inv  x -> 1/x   reflection theta -> pi - theta    fixes 1 and -1, swaps 0 and ∞
Two different mirrors compose to a rotation; the order of the pair sets the direction.
‰ is the indeterminate (0/0, ∞/∞, 0·∞, ∞-∞): a set of candidate values that context narrows.
"""
import ast, math, re
from fractions import Fraction as Fr


class Inf:
    def __repr__(self): return "∞"
    def __eq__(self, o): return isinstance(o, Inf)
    def __hash__(self): return hash("∞")
INF = Inf()


class Permille:
    """‰: indeterminate. For numbers its candidates are the whole projective line; a direction of approach
    (slope) picks one. For meanings, candidates are any finite set that relations narrow."""
    def __init__(self, origin, candidates=None):
        self.origin, self.candidates = origin, candidates
    def __repr__(self): return f"‰({self.origin})"
    def __eq__(self, o): return isinstance(o, Permille) and o.origin == self.origin and o.candidates == self.candidates
    def __hash__(self): return hash(("‰", self.origin))
    def along(self, slope):
        """Blow-up: approaching 0/0 or ∞/∞ along y = slope*x resolves the ratio to that slope."""
        if self.origin in ("0/0", "∞/∞"): return num(slope)
        return self
    def narrow(self, keep):
        """Meaning-slot use: keep only candidates that satisfy a relation. Returns (new ‰ or value, bits gained)."""
        if self.candidates is None: return self, 0.0
        before = len(self.candidates); after = [c for c in self.candidates if keep(c)]
        bits = math.log2(before / len(after)) if after else float("inf")
        if len(after) == 1: return after[0], bits
        return Permille(self.origin, after), bits


def num(x):
    if isinstance(x, (Inf, Permille)): return x
    return Fr(x)

def is_num(x): return isinstance(x, Fr)

# ---- arithmetic on the projective line -----------------------------------------------------------
def neg(x):
    x = num(x)
    return x if isinstance(x, (Inf, Permille)) else -x

def inv(x):
    x = num(x)
    if isinstance(x, Permille): return x
    if x == INF: return Fr(0)
    return INF if x == 0 else 1 / x

def mul(a, b):
    a, b = num(a), num(b)
    if isinstance(a, Permille) or isinstance(b, Permille): return a if isinstance(a, Permille) else b
    if (a == INF and b == 0) or (a == 0 and b == INF): return Permille("0·∞")
    if a == INF or b == INF: return INF
    return a * b

def div(a, b):
    a, b = num(a), num(b)
    if isinstance(a, Permille) or isinstance(b, Permille): return a if isinstance(a, Permille) else b
    if a == 0 and b == 0: return Permille("0/0")
    if a == INF and b == INF: return Permille("∞/∞")
    return mul(a, inv(b))

def add(a, b):
    a, b = num(a), num(b)
    if isinstance(a, Permille) or isinstance(b, Permille): return a if isinstance(a, Permille) else b
    if a == INF and b == INF: return Permille("∞+∞")      # sign-free ∞: ∞+∞ and ∞-∞ are both indeterminate
    if a == INF or b == INF: return INF
    return a + b

def sub(a, b): return add(a, neg(b))

# ---- the circle picture -------------------------------------------------------------------------------
def theta(x):
    x = num(x)
    return math.pi if x == INF else 2 * math.atan(float(x))

def from_theta(t):
    t = math.remainder(t, 2 * math.pi)
    if abs(abs(t) - math.pi) < 1e-12: return INF
    return math.tan(t / 2)

def reflect(a):
    """The mirror of the circle across the axis at angle a: theta -> 2a - theta."""
    return lambda x: from_theta(2 * a - theta(x))

def rotation_between(f, g, samples=(0.3, 1.7, -2.2)):
    """Angle by which g∘f turns the circle (if it is a rotation), in (-pi, pi]; None otherwise."""
    shifts = [math.remainder(theta(g(f(s))) - theta(s), 2 * math.pi) for s in samples]
    same = all(abs(math.remainder(x - shifts[0], 2 * math.pi)) < 1e-9 for x in shifts)   # +pi and -pi are one turn
    return shifts[0] if same else None

def cross(a, b, c, d):
    """Cross-ratio (a,b;c,d) = (c-a)(d-b) / ((c-b)(d-a)), with ∞ handled by limits. Invariant under
    every Möbius transformation, including %neg and %inv."""
    a, b, c, d = map(num, (a, b, c, d))
    def diff(p, q):   # p - q with ∞ contributing a factor that cancels in the ratio
        return None if (p == INF or q == INF) else p - q
    terms = [diff(c, a), diff(d, b), diff(c, b), diff(d, a)]
    top = [t for t in terms[:2] if t is not None]; bot = [t for t in terms[2:] if t is not None]
    if len(top) != len(bot): return INF if len(top) > len(bot) else Fr(0)
    n = Fr(1); m = Fr(1)
    for t in top: n *= t
    for t in bot: m *= t
    return div(n, m)

# ---- closure: an infinite space plus one point at ∞ becomes one unit sphere -------------------------------
class Space:
    def __init__(self, name, dim, closed=False): self.name, self.dim, self.closed = name, dim, closed
    def __repr__(self): return f"S{self.dim}" if self.closed else self.name
    def __eq__(self, o): return isinstance(o, Space) and (o.dim, o.closed) == (self.dim, self.closed)
    card = "continuum"          # line, plane and space have the same number of points; dimension differs
SPACES = {"line": Space("line", 1), "plane": Space("plane", 2), "space": Space("space", 3)}
def close(s): return Space(f"S{s.dim}", s.dim, True)

# ---- parallel lines: shared ideal point (invariant), distance (variant) --------------------------------------
class Line:
    def __init__(self, angle, offset): self.angle, self.offset = angle % math.pi, offset
    def ideal(self): return round(self.angle, 12)          # its point at infinity: the direction, nothing else
def parallel(L, d): return Line(L.angle, L.offset + d)
def distance(L1, L2): return abs(L2.offset - L1.offset) if L1.ideal() == L2.ideal() else 0.0

# ---- lines on a sphere: great circles ----------------------------------------------------------------------
def _norm(v): n = math.sqrt(sum(x * x for x in v)); return tuple(x / n for x in v)
def _cross3(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
def great_circle(normal): return _norm(normal)
def meet(A, B):
    p = _norm(_cross3(A, B)); return p, tuple(-x for x in p)
def arcs(A, B):
    """Lengths of A's two pieces between the meeting points (unit sphere)."""
    p, q = meet(A, B)
    ang = math.atan2(math.sqrt(sum(x * x for x in _cross3(p, q))), sum(x * y for x, y in zip(p, q)))   # stable near pi
    return ang, 2 * math.pi - ang
def circumference(): return 2 * math.pi

# ---- the DSL evaluator: Python parses the text, a whitelist checks it, nothing is executed as code --------------
FUNCS = {"inv": inv, "neg": neg, "cross": cross, "close": close, "along": lambda p, m: p.along(m) if isinstance(p, Permille) else p,
         "theta": theta}
NAMES = {"INF": INF, **SPACES}

def evaluate(src):
    s = src.replace("%inv", "inv").replace("%neg", "neg").replace("∞", "INF").replace("◯", "close").replace("·", "*")
    s = s.replace("‰", "PERMILLE")
    tree = ast.parse(s, mode="eval")
    ok = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Call, ast.Name, ast.Load, ast.Constant,
          ast.Add, ast.Sub, ast.Mult, ast.Div, ast.USub)
    for n in ast.walk(tree):
        if not isinstance(n, ok): raise ValueError(f"not allowed in a formula: {type(n).__name__}")
        if isinstance(n, ast.Name) and n.id not in NAMES and n.id not in FUNCS and n.id != "PERMILLE":
            raise ValueError(f"unknown name {n.id}")
        if isinstance(n, ast.Call) and not (isinstance(n.func, ast.Name) and n.func.id in FUNCS):
            raise ValueError("only registered functions may be called")
    def ev(n):
        if isinstance(n, ast.Expression): return ev(n.body)
        if isinstance(n, ast.Constant):
            if isinstance(n.value, (int, float)): return Fr(str(n.value))
            raise ValueError("only numbers")
        if isinstance(n, ast.Name): return Permille("given") if n.id == "PERMILLE" else NAMES[n.id]
        if isinstance(n, ast.UnaryOp): return neg(ev(n.operand))
        if isinstance(n, ast.BinOp):
            a, b = ev(n.left), ev(n.right)
            return {ast.Add: add, ast.Sub: sub, ast.Mult: mul, ast.Div: div}[type(n.op)](a, b)
        if isinstance(n, ast.Call): return FUNCS[n.func.id](*[ev(x) for x in n.args])
    return ev(tree)

def show(v):
    if isinstance(v, Fr): return str(v)
    return repr(v)
