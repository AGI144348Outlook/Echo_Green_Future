# ECHO Notebook 0.4 — Pyodide, the whole system

Open `index.html` over http(s). The first visit downloads Pyodide 0.28.3 (about 10 MB) and caches it;
after that ECHO runs offline. Tested end to end in Chromium on a phone viewport: 42/42.

## What is in it
- **ECHO in a Web Worker** (`js/worker.js`): Pyodide 0.28.3 runs his Python; the screen never waits on him.
- **Talk** (`js/io.js` + `echo/notebook_runtime.py`): EMEL statements are parsed, audited and answered in
  English that must parse back to the same tree; free text is read for words he knows; gaps become questions.
  Commands: help, resolve, hypernyms of, suggest, forge, query, matrices, identify, cycle, teach, recess.
- **Canvas Recess on the KSM** (`echo/canvas/ks_recess.py`, `js/stage.js`): ECHO places, aligns, nests and folds
  knowledge planes on his own. A-101 chooses, A-113 judges every 20 turns. You watch, drag (your layer only),
  inspect, and suggest words he may accept or decline.
- **Learning that persists**: his A-101 history, Canvas, taught words, conversation and layout are saved on
  the device (IndexedDB) and restored on the next visit. Export/import in "Notebook data".
- **Forge** (`echo/forge.py` composes, `js/forge.js` validates and builds): widgets from registered parts only
  (clock, timer, notes, numbers, slider, toggle, list, resident card, Governor query, HTML preview, live feed,
  ask ECHO). Nothing generated runs as code.
- **Matrices and registries**: the Governor opens ECHO's Lobby (900 words), the Registry, the Hebrew Glyph
  Registry, the I Ching and his algorithm matrix, by EMEL `|{a:b::c:x}|` or Python `G[a:b, c:x]`.
- **Crawler and Cloudflare**: probes the 16 geosensory sources and calls the live Worker (`/health`,
  `/agent/`, `/ties/`, `/search`). Sources that refuse browser requests show as blocked.

## New in 0.4
- **Dictionary**: all of WordNet 3.0 (147,306 words, 117,659 senses; `echo/data/dictionary.json.gz`, 4 MB), loaded in
  the background after ECHO boots and cached for offline use. His audits, Lobby and conversation read from it.
- **Study** (toolbar): ECHO studies on his own. He chooses each word himself: first words from your conversations he
  could not place, then the dictionary words his own Lobby definitions use most (nouns only, a stated rule). His
  kernel indexes each definition and his own Lobby code rebuilds every 8 words, so new ties form by his usual rule.
- **Map Matrix** (menu): every study recorded: the word, why he chose it, the ties it formed, and the sentences
  about it that passed his audits. Saved on the device with everything else; included in exports.
- **Dialogue**: he asks who he is talking with and remembers; answers yes/no and why from his dictionary; keeps
  your claims as yours until he can verify them; asks about gaps and remembers your answers; reads Hebrew glyph
  strings from his registries only (letters, operations, values, reversal, containment, dictionary spellings),
  registers them as candidates with no meaning assigned, and asks what they mean.

## Cloudflare storage for his studies
The live Worker is read-only today. Saving his Map Matrix to Cloudflare needs a write endpoint on the Worker
(for example `POST /maps`, storing to D1 or KV) guarded by the gateway's authentication. No keys belong in this
page. Until then his studies persist on the device and in "Export notebook".

## Deploy (Cloudflare Workers static assets, as the repo already does)
Put this folder's contents where the deploy step picks them up (for `pwa-hosting-environment`, the `pwa/`
directory, with `index.html` at its root), then deploy. No build step and no secrets.

## Known limits, stated plainly
- His kernel's A-113 can discard a session when a new activity is harder, and A-101 then keeps choosing it
  (the "stuck" state the Governor widget flags). Fixing it means changing his kernel; not done here.
- Offline vocabulary is the 900-word Lobby snapshot (WordNet 3.0) plus the Registry. Words outside it are gaps.
- His grammar has no mass nouns yet ("A knowledge is an abstraction.") and only is / includes / proportions.
- The Forge understands a fixed vocabulary of parts; unrecognized words are reported, not guessed.
- The codices are not ingested yet; the kernel's Propose step is still a single no-op candidate.
- Dialogue phrasings are fixed templates; the facts inside them come from his dictionary, registries and audits.

WordNet 3.0 Copyright 2006 by Princeton University. Used under the WordNet 3.0 license; see WORDNET_LICENSE.
