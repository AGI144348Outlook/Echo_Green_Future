/* ECHO's Web Worker: Pyodide and his whole Python runtime live here, off the screen's thread.
   Messages in: {id, fn, args, base}. Out: {id, ok, result | error} and {type: "status", text}. */
let R = null;
const say = text => postMessage({ type: "status", text });
self.onmessage = async ev => {
  const { id, fn, args = [], base } = ev.data;
  try {
    if (fn === "init") {
      say("Loading Python (Pyodide)");
      importScripts(base + "pyodide.js");
      const py = await loadPyodide({ indexURL: base }); self.pyFS = py.FS;
      const root = new URL("../", self.location.href);
      const man = await (await fetch(new URL("echo/manifest.json", root), { cache: "no-cache" })).json();
      let n = 0;
      for (const f of man.files) {
        const res = await fetch(new URL(f + "?v=" + man.version, root));
        if (!res.ok) throw new Error("missing " + f + " (" + res.status + ")");
        const dir = "/home/pyodide/" + f.split("/").slice(0, -1).join("/");
        py.FS.mkdirTree(dir);
        py.FS.writeFile("/home/pyodide/" + f, new Uint8Array(await res.arrayBuffer()));
        if (++n % 5 === 0) say(`Loading ECHO ${n}/${man.files.length}`);
      }
      py.runPython("import sys\nif '/home/pyodide' not in sys.path: sys.path.insert(0, '/home/pyodide')");
      say("ECHO is building his Lobby");
      R = py.pyimport("echo.notebook_runtime");
      postMessage({ id, ok: true, result: JSON.parse(R.boot(args[0] || "{}")) });
      return;
    }
    if (!R) throw new Error("ECHO is not running yet");
    if (fn === "dictionary") {
      say("Loading ECHO's dictionary");
      const root = new URL("../", self.location.href);
      const res = await fetch(new URL("echo/data/dictionary.json.gz?v=1", root));
      if (!res.ok) throw new Error("dictionary missing (" + res.status + ")");
      self.pyFS.writeFile("/home/pyodide/echo/data/dictionary.json.gz", new Uint8Array(await res.arrayBuffer()));
      postMessage({ id, ok: true, result: JSON.parse(R.attach_dictionary("/home/pyodide/echo/data/dictionary.json.gz")) });
      return;
    }
    if (typeof R[fn] !== "function") throw new Error("unknown call " + fn);
    postMessage({ id, ok: true, result: JSON.parse(R[fn](...args)) });
  } catch (e) {
    postMessage({ id, ok: false, error: String((e && e.message) || e) });
  }
};
