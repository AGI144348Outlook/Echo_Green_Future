/* Bridge to ECHO's Web Worker. Every call returns a Promise; the screen never waits on Python. */
(function (E) {
  "use strict";
  const PYODIDE = "0.28.3";
  const qs = new URLSearchParams(location.search);
  const BASE = qs.get("pyodide") || `https://cdn.jsdelivr.net/pyodide/v${PYODIDE}/full/`;
  const B = E.bridge = { ready: false, status: "idle", detail: "", events: new EventTarget(), start, call, busy: 0 };
  let worker = null, seq = 0;
  const pending = new Map();
  function set(status, detail) {
    B.status = status; B.detail = detail || "";
    B.events.dispatchEvent(new CustomEvent("status", { detail: { status, detail: B.detail } }));
  }
  function call(fn, ...args) {
    if (!worker) return Promise.reject(new Error("ECHO is not running"));
    const id = ++seq; B.busy++;
    return new Promise((resolve, reject) => {
      pending.set(id, { resolve, reject });
      worker.postMessage({ id, fn, args });
    });
  }
  function start(state) {
    if (worker) worker.terminate();
    B.ready = false;
    set("loading", "Starting ECHO's worker");
    worker = new Worker("./js/worker.js");
    worker.onmessage = ev => {
      const m = ev.data;
      if (m.type === "status") { set(B.ready ? "ready" : "loading", m.text); return; }
      const p = pending.get(m.id); if (!p) return;
      pending.delete(m.id); B.busy = Math.max(0, B.busy - 1);
      m.ok ? p.resolve(m.result) : p.reject(new Error(m.error));
    };
    worker.onerror = e => { set("error", e.message || "worker failed"); };
    const id = ++seq;
    return new Promise((resolve, reject) => {
      pending.set(id, {
        resolve: r => { B.ready = true; set("ready", "ECHO is online"); resolve(r); },
        reject: e => { set("error", e.message); reject(e); },
      });
      worker.postMessage({ id, fn: "init", args: [JSON.stringify(state || {})], base: BASE });
    });
  }
})(window.ECHO = window.ECHO || {});
