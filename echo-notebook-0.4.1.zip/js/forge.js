/* The Forge factory: validates a WidgetSpec and builds it from registered parts only.
   Nothing in a spec is executed as code. */
(function (E) {
  "use strict";
  const esc = t => E.stage.esc(t);
  const KINDS = ["clock", "timer", "notes", "number", "slider", "toggle", "input", "button", "output", "list", "resident", "query", "preview", "feed"];
  const ACTIONS = ["calc", "ask", "resolve", "query", "clear"];
  const F = E.forge = { validate, KINDS, ACTIONS };

  function validate(spec) {
    const errs = [];
    if (!spec || typeof spec !== "object") return ["not a widget spec"];
    if (!Array.isArray(spec.controls) || !spec.controls.length) errs.push("no parts");
    const ids = new Set();
    (spec.controls || []).slice(0, 24).forEach(c => {
      if (!KINDS.includes(c.kind)) errs.push(`unknown part ${c.kind}`);
      if (!/^[a-z]+\d{1,2}$/.test(c.id || "")) errs.push(`bad part id ${c.id}`);
      if (ids.has(c.id)) errs.push(`duplicate part id ${c.id}`); ids.add(c.id);
      for (const k of ["label", "value", "word", "formula"]) if (c[k] != null && String(c[k]).length > 200) errs.push(`${k} too long`);
    });
    (spec.bindings || []).forEach(b => {
      if (!ACTIONS.includes(b.do)) errs.push(`unknown action ${b.do}`);
      if (!ids.has(b.on)) errs.push(`binding on missing part ${b.on}`);
      if (b.into && !ids.has(b.into)) errs.push(`binding into missing part ${b.into}`);
      (b.inputs || []).forEach(i => { if (!ids.has(i)) errs.push(`binding reads missing part ${i}`); });
      if (b.do === "calc" && !["+", "-", "*", "/", "avg"].includes(b.op)) errs.push(`unknown arithmetic ${b.op}`);
    });
    return errs;
  }

  function build(body, w) {
    const spec = w.binding && w.binding.spec;
    const errs = validate(spec);
    if (errs.length) { body.innerHTML = `<p class="err pad">The Governor refused this widget: ${esc(errs.join("; "))}.</p>`; return; }
    w.timers = w.timers || [];
    const part = {};
    body.classList.add("forged");
    for (const c of spec.controls) {
      const row = document.createElement("div"); row.className = "part part-" + c.kind; row.dataset.id = c.id;
      const label = c.label ? `<span class="plabel">${esc(c.label)}</span>` : "";
      if (c.kind === "clock") { row.innerHTML = `${label}<span class="bigtime"></span>`; const t = row.querySelector(".bigtime");
        const tick = () => t.textContent = new Date().toLocaleTimeString(); tick(); w.timers.push(setInterval(tick, 1000)); }
      else if (c.kind === "timer") { row.innerHTML = `${label}<span class="bigtime">0:00.0</span><div class="prow"><button>Start</button><button>Reset</button></div>`;
        let t0 = 0, acc = 0, h = null; const out = row.querySelector(".bigtime"), [bs, br] = row.querySelectorAll("button");
        const show = () => { const ms = acc + (h ? Date.now() - t0 : 0), s = ms / 1000; out.textContent = `${Math.floor(s / 60)}:${(s % 60).toFixed(1).padStart(4, "0")}`; };
        bs.onclick = () => { if (h) { acc += Date.now() - t0; clearInterval(h); h = null; bs.textContent = "Start"; } else { t0 = Date.now(); h = setInterval(show, 100); w.timers.push(h); bs.textContent = "Stop"; } };
        br.onclick = () => { acc = 0; t0 = Date.now(); show(); }; }
      else if (c.kind === "notes") { row.innerHTML = `${label}<textarea rows="4" aria-label="${esc(c.label || "Notes")}"></textarea>`;
        const ta = row.querySelector("textarea"), key = `forge:${w.id}:${c.id}`;
        E.nve.get(key).then(v => { if (v) ta.value = v; }); ta.addEventListener("input", () => E.nve.set(key, ta.value)); }
      else if (c.kind === "number") row.innerHTML = `${label}<input type="number" inputmode="decimal" value="${esc(c.value ?? 0)}">`;
      else if (c.kind === "slider") { row.innerHTML = `${label}<input type="range" min="${+c.min || 0}" max="${+c.max || 100}" value="${+c.value || 50}"><span class="sval"></span>`;
        const r = row.querySelector("input"), s = row.querySelector(".sval"); const show = () => s.textContent = r.value; show(); r.addEventListener("input", show); }
      else if (c.kind === "toggle") row.innerHTML = `<label class="tog"><input type="checkbox"> ${esc(c.label || "Toggle")}</label>`;
      else if (c.kind === "input") row.innerHTML = `${label}<input type="text" value="${esc(c.value || "")}" enterkeyhint="go">`;
      else if (c.kind === "button") row.innerHTML = `<button class="pbtn">${esc(c.label || "Run")}</button>`;
      else if (c.kind === "output") row.innerHTML = `${label}<div class="pout" aria-live="polite">\u2014</div>`;
      else if (c.kind === "list") { row.innerHTML = `${label}<div class="prow"><input type="text" placeholder="Add an item"><button>Add</button></div><ul class="plist"></ul>`;
        const key = `forge:${w.id}:${c.id}`, ul = row.querySelector("ul"), inp = row.querySelector("input");
        let items = []; const draw = () => { ul.innerHTML = items.map((x, i) => `<li><label><input type="checkbox" data-i="${i}" ${x.d ? "checked" : ""}> ${esc(x.t)}</label></li>`).join(""); E.nve.set(key, items); };
        E.nve.get(key).then(v => { items = v || []; draw(); });
        row.querySelector("button").onclick = () => { if (inp.value.trim()) { items.push({ t: inp.value.trim(), d: false }); inp.value = ""; draw(); } };
        ul.addEventListener("change", ev => { items[ev.target.dataset.i].d = ev.target.checked; draw(); }); }
      else if (c.kind === "resident") { row.innerHTML = `${label}<div class="pcard">\u2014</div>`; if (c.word) setTimeout(() => fillResident(row, c.word), 0); }
      else if (c.kind === "query") { row.innerHTML = `${label}<div class="prow"><select>${["lobby", "registry", "glyphs", "hexagrams", "algorithms"].map(m => `<option ${m === c.matrix ? "selected" : ""}>${m}</option>`).join("")}</select></div>
        <input type="text" value="${esc(c.formula || "")}" aria-label="Formula"><button class="pbtn">Ask the Governor</button><div class="pout">\u2014</div>`;
        row.querySelector("button").onclick = async () => { const o = row.querySelector(".pout"); o.textContent = "\u2026";
          try { o.innerHTML = queryHTML(await E.bridge.call("query", row.querySelector("select").value, row.querySelector("input").value)); } catch (e) { o.textContent = e.message; } }; }
      else if (c.kind === "preview") { row.innerHTML = `${label}<textarea rows="3" placeholder="HTML to preview"></textarea><button class="pbtn">Render</button><iframe sandbox="allow-scripts" title="Preview"></iframe>`;
        row.querySelector("button").onclick = () => row.querySelector("iframe").srcdoc = row.querySelector("textarea").value; }
      else if (c.kind === "feed") { row.innerHTML = `${label}<button class="pbtn">Refresh</button><div class="pout">\u2014</div>`;
        const go = () => E.crawler.sample(c.source).then(t => row.querySelector(".pout").textContent = t); row.querySelector("button").onclick = go; go(); }
      body.appendChild(row); part[c.id] = row;
    }
    const val = id => { const r = part[id]; const i = r && r.querySelector("input,textarea"); return i ? i.value : ""; };
    const put = (id, text, isHTML) => { const r = part[id]; if (!r) return; const o = r.querySelector(".pout,.pcard"); if (o) isHTML ? (o.innerHTML = text) : (o.textContent = text); };
    for (const b of spec.bindings || []) {
      const src = part[b.on]; if (!src) continue;
      const run = async () => {
        if (b.do === "calc") {
          const xs = b.inputs.map(i => parseFloat(val(i))).filter(x => !isNaN(x));
          let r = xs.length ? xs.reduce((a, x) => b.op === "+" ? a + x : b.op === "-" ? a - x : b.op === "*" ? a * x : b.op === "/" ? a / x : a + x) : NaN;
          if (b.op === "avg") r = r / xs.length;
          put(b.into, isFinite(r) ? String(+r.toFixed(10)) : "Not a number");
        } else if (b.do === "ask") { put(b.into, "\u2026"); try { const r = await E.bridge.call("handle", val(b.inputs[0]), "TEXT"); put(b.into, r.outputs.map(o => o.text).join("\n")); } catch (e) { put(b.into, e.message); } }
        else if (b.do === "resolve") fillResident(part[b.into], val(b.inputs[0]));
        else if (b.do === "clear") b.inputs.forEach(i => { const inp = part[i] && part[i].querySelector("input,textarea"); if (inp) inp.value = ""; });
      };
      const btn = src.querySelector("button"), inp = src.querySelector("input");
      if (btn) btn.addEventListener("click", run);
      else if (inp) { inp.addEventListener("change", run); inp.addEventListener("keydown", ev => { if (ev.key === "Enter") run(); }); }
    }
  }
  async function fillResident(row, word) {
    if (!row || !word) return; const card = row.querySelector(".pcard"); card.textContent = "\u2026";
    try { const r = await E.bridge.call("resolve", word);
      card.innerHTML = `<b>${esc(r.word)}</b><div class="small">${esc(r.definition || "Not in my Lobby or Registry.")}</div>` +
        (r.chain && r.chain.length ? `<div class="small muted">${esc(r.chain.slice(0, 6).join(" \u2192 "))}</div>` : "") +
        `<div class="small muted">${esc(r.glyphs || "")} ${r.gematria ? esc(r.gematria) : ""}${r["on canvas"] ? " \u00b7 on his Canvas" : ""}</div>`;
    } catch (e) { card.textContent = e.message; }
  }
  function queryHTML(r) {
    if (r.status !== "OPEN") return esc(r.error || ("Closed: " + JSON.stringify(r.validate || r.identify)));
    if ("holds" in r) return esc(`${r.holds ? "Holds" : "Does not hold"} in ${r.matrix}.`);
    return `${esc(r.matches)} match(es) in ${esc(r.matrix)}<br>` + r.bindings.map(b => esc(Object.entries(b).map(([k, v]) => `${k}=${v}`).join(", "))).join("<br>");
  }
  F.queryHTML = queryHTML;
  E.widgets.register("FORGED", {
    title: "Widget", icon: "\u2692", titleFor: w => (w.binding && w.binding.spec && w.binding.spec.title) || "Widget",
    build, onClose(w) { (w.timers || []).forEach(clearInterval); },
  });
})(window.ECHO = window.ECHO || {});
