/* ECHO's self-study loop and his Map Matrix widget. He chooses every word; this only paces him. */
(function (E) {
  "use strict";
  const esc = t => E.stage.esc(t), W = E.widgets, $ = s => document.querySelector(s);
  const ST = E.study = { on: false, timer: null, dictionary: false, summary: null, start, spoken: new Set() };
  function set(on) {
    ST.on = on; $("#study").textContent = on ? "Pause Study" : "Study";
    $("#study").setAttribute("aria-pressed", String(on)); E.nve.set("study-on", on);
    clearTimeout(ST.timer); if (on) tick();
  }
  async function tick() {
    if (!ST.on) return;
    if (E.bridge.ready && ST.dictionary && document.visibilityState === "visible") {
      try {
        const r = await E.bridge.call("study", 1);
        ST.summary = r.summary;
        for (const rec of r.records) {
          E.recessLog.push({ turn: rec.turn, session: "study", arm: "STUDY", ok: true, reason: `studied ${rec.word}: ${rec.why}` });
        }
        const recent = (await E.bridge.call("maps", Math.max(0, r.summary.maps - 12), 12)).maps;
        for (const m of recent) for (const s of m.verified) {
          if (ST.spoken.has(s)) continue;
          ST.spoken.add(s); E.io.emit({ actor: "echo", kind: "text", text: s, refs: [m.word] });
        }
        if (W.items.has("maps")) W.refresh("maps");
        if (!r.records.length) { E.app.toast(r.reason || "Nothing left to study right now"); set(false); return; }
        E.app.saveSoon();
      } catch (e) { E.app.toast("Study paused: " + e.message); set(false); return; }
    }
    ST.timer = setTimeout(tick, 2600 / (E.app.recess.speed || 1));
  }
  async function start(resume) {
    try {
      const r = await E.bridge.call("dictionary");
      ST.dictionary = true; ST.summary = r;
      try { (await E.bridge.call("maps", 0, 5000)).maps.forEach(m => m.verified.forEach(v => ST.spoken.add(v))); } catch (e) {}
      E.io.emit({ actor: "echo", kind: "status", text: `My dictionary is loaded: ${r.words.toLocaleString()} words and ${r.senses.toLocaleString()} senses. I have studied ${r.studied} of them on my own so far; my Lobby has ${r["lobby words"]} words.` });
      $("#study").disabled = false;
      if (resume) set(true);
    } catch (e) { E.io.emit({ actor: "system", kind: "error", text: "ECHO's dictionary did not load: " + e.message }); }
  }
  W.register("MAPS", {
    title: "Map Matrix", icon: "\u2638",
    async build(body) {
      if (!E.bridge.ready || !ST.dictionary) { body.innerHTML = `<p class="muted pad">Opens once ECHO's dictionary is loaded.</p>`; return; }
      const r = await E.bridge.call("maps", 0, 2000), s = r.summary, ms = r.maps.slice().reverse();
      body.innerHTML = `<div class="pad"><p class="small muted">Every word ECHO chose to study, why he chose it, what it tied to in his Lobby, and the sentences about it that passed his audits.</p>
        <div class="kv"><span>studied</span><span>${s.studied} words</span></div><div class="kv"><span>his Lobby</span><span>${s["lobby words"]} words, ${s["lobby ties"]} ties</span></div>
        <div class="kv"><span>verified</span><span>${s["sentences verified in maps"]} sentences</span></div><div class="kv"><span>waiting</span><span>${s["gaps waiting"]} words from your conversations</span></div>
        <ul class="hist">${ms.slice(0, 150).map(m => `<li><b>${esc(m.word)}</b> <span class="small muted">(#${m.n}, ${m.source === "gap" ? "from your conversation" : "his frontier"})</span><div class="small">${esc(m.why)}</div>
          ${m.ties.length ? `<div class="chips">${m.ties.slice(0, 8).map(t => `<button class="chip" data-word="${esc(t)}">${esc(t)}</button>`).join("")}</div>` : ""}
          ${m.verified.map(v => `<div class="io-text voice small">${esc(v)}</div>`).join("")}</li>`).join("") || "<li>Start Study to see his choices.</li>"}</ul></div>`;
      body.addEventListener("click", ev => { const c = ev.target.closest(".chip"); if (c) E.app.focusWord(c.dataset.word); });
    },
  });
  E.study.set = set;
})(window.ECHO = window.ECHO || {});
