/* Widgets: Inspector, Governor, Matrices, Recess log, Forge, Crawler, Data. */
(function (E) {
  "use strict";
  const esc = t => E.stage.esc(t), W = E.widgets;
  const kv = (k, v) => `<div class="kv"><span>${esc(k)}</span><span>${v}</span></div>`;
  const notReady = body => { body.innerHTML = `<p class="muted pad">ECHO is ${esc(E.bridge.status)}. This opens once he is online.</p>`; return !E.bridge.ready; };

  // ---- Inspector: a plane ECHO placed ------------------------------------------------------
  W.register("INSPECTOR", {
    title: "Plane", icon: "\u25ce", titleFor: w => "Plane: " + ((w.binding && w.binding.id) || ""),
    async build(body, w) {
      if (!E.bridge.ready) return notReady(body);
      const id = w.binding && w.binding.id; body.innerHTML = `<p class="muted pad">Reading ${esc(id)}\u2026</p>`;
      const r = await E.bridge.call("plane", id);
      if (!r) { body.innerHTML = `<p class="muted pad">${esc(id)} is not on his Canvas.</p>`; return; }
      const p = r.plane;
      body.innerHTML = `<div class="pad"><h2 class="voice-h">${esc(p.word)}</h2><p class="muted">${esc(r.definition || "")}</p>
        <div class="lbl">Generality (his A-118 score)</div><div class="bar"><i style="width:${Math.round(r.generality * 100)}%"></i></div>
        <div class="lbl">Segments: his 12 strongest ties</div><ul class="segs">${(p.segments || []).map(s => `<li><button class="chip" data-word="${esc(s)}">${esc(s)}</button></li>`).join("")}</ul>
        ${p.parent ? `<p>Nested inside <b>${esc(p.parent)}</b>.</p>` : ""}${p.group ? `<p>In intersecting set ${esc(p.group)}.</p>` : ""}${p.folded ? "<p>Folded (manifolded).</p>" : ""}
        <div class="lbl">What ECHO did with it</div><ul class="hist">${r.history.map(e => `<li>Turn ${e.turn}: ${esc(e.reason)}</li>`).join("") || "<li>Nothing recorded yet.</li>"}</ul>
        ${E.stage.offset[id] ? `<button class="btn" data-a="reset">Put it back where ECHO placed it</button>` : ""}</div>`;
      body.addEventListener("click", ev => {
        const c = ev.target.closest(".chip"); if (c) E.app.focusWord(c.dataset.word);
        if (ev.target.dataset.a === "reset") { delete E.stage.offset[id]; E.app.saveOffsets(); E.stage.render(); W.refresh(w.id); }
      });
    },
  });

  // ---- Governor: IDENTIFY, what he has learned, the kernel cycle ------------------------------------
  W.register("GOVERNOR", {
    title: "Governor \u05e8", icon: "\u05e8",
    async build(body, w) {
      if (!E.bridge.ready) return notReady(body);
      const r = await E.bridge.call("identify");
      const hist = r["A-101 history (successes, attempts)"] || {};
      body.innerHTML = `<div class="pad">${r.stuck ? `<p class="warn">His last two sessions were discarded by A-113, so A-101 keeps choosing the same activity. This is a known flaw in his kernel.</p>` : ""}
        ${kv("identity", esc(r.identity))}${kv("kernel", esc(r["kernel lines"]) + " lines")}${kv("lobby", `${esc(r["lobby words"])} words, ${esc(r["lobby ties"])} ties`)}
        ${kv("registry", `${esc(r["registry residents"])} canonical, ${esc(r["overlay residents"])} taught locally`)}
        ${kv("canvas", `${esc(r["canvas planes"])} planes, turn ${esc(r["recess turn"])}, session ${esc(r.session)}`)}
        ${kv("checkpoints", esc((r["last checkpoints"] || []).join(", ") || "none yet"))}
        <div class="lbl">What A-101 has learned about his activities</div>
        <table class="t"><tr><th>activity</th><th>succeeded</th><th>tried</th></tr>${Object.entries(hist).map(([k, v]) => `<tr><td>${esc(k)}</td><td>${v[0]}</td><td>${v[1]}</td></tr>`).join("") || "<tr><td colspan=3>Nothing anchored yet</td></tr>"}</table>
        <div class="prow"><button class="btn" data-a="cycle">Run a Governor cycle</button><button class="btn" data-a="refresh">Refresh</button></div><div class="pout"></div></div>`;
      body.addEventListener("click", async ev => {
        const a = ev.target.dataset.a;
        if (a === "refresh") W.refresh(w.id);
        if (a === "cycle") { const r2 = await E.bridge.call("handle", "cycle", "TEXT"); body.querySelector(".pout").innerHTML = (r2.outputs[0].rows || []).map(x => kv(x[0], esc(x[1]))).join(""); }
      });
    },
  });

  // ---- Matrices: browse any matrix and query it through the Governor ------------------------------
  W.register("MATRICES", {
    title: "Matrices and registries", icon: "\u25a6",
    async build(body, w) {
      if (!E.bridge.ready) return notReady(body);
      const list = await E.bridge.call("matrices");
      const st = w.binding || { mid: "lobby", start: 0 };
      body.innerHTML = `<div class="pad"><div class="prow"><select aria-label="Matrix">${list.map(m => `<option value="${m.id}" ${m.id === st.mid ? "selected" : ""}>${esc(m.name)} (${m.entries})</option>`).join("")}</select></div>
        <div class="lbl">Ask the Governor (EMEL or Python form)</div><div class="prow"><input type="text" class="f" value="|{dog:canine::cat:x}|" aria-label="Formula"><button class="btn" data-a="q">Open</button></div>
        <div class="qout small"></div><div class="lbl">Contents</div><div class="rows"></div><div class="prow"><button class="btn" data-a="prev">Previous</button><button class="btn" data-a="next">Next</button></div></div>`;
      const sel = body.querySelector("select"), rows = body.querySelector(".rows");
      const draw = async () => {
        const r = await E.bridge.call("browse", st.mid, st.start, 40);
        rows.innerHTML = `<p class="small muted">${r.start + 1}\u2013${Math.min(r.start + 40, r.total)} of ${r.total}</p><table class="t">${r.rows.map(x =>
          `<tr><td><button class="chip" data-word="${esc(x[0])}">${esc(x[0])}</button></td><td class="small">${esc(x[1])}</td><td class="small">${esc(x[2])}</td></tr>`).join("")}</table>`;
      };
      sel.onchange = () => { st.mid = sel.value; st.start = 0; draw(); };
      body.addEventListener("click", async ev => {
        const a = ev.target.dataset.a, c = ev.target.closest(".chip");
        if (c && st.mid !== "glyphs" && st.mid !== "hexagrams" && st.mid !== "algorithms") E.app.focusWord(c.dataset.word);
        if (a === "next") { st.start += 40; draw(); } if (a === "prev") { st.start = Math.max(0, st.start - 40); draw(); }
        if (a === "q") { const o = body.querySelector(".qout"); o.textContent = "\u2026"; try { o.innerHTML = E.forge.queryHTML(await E.bridge.call("query", st.mid, body.querySelector(".f").value)); } catch (e) { o.textContent = e.message; } }
      });
      draw();
    },
  });

  // ---- Recess log -----------------------------------------------------------------------------
  E.recessLog = [];
  W.register("RECESS_LOG", {
    title: "Recess log", icon: "\u21bb",
    build(body) {
      body.innerHTML = `<ul class="hist pad"></ul>`;
      const ul = body.querySelector("ul");
      ul.innerHTML = E.recessLog.slice(-120).reverse().map(e => `<li class="${e.ok ? "" : "muted"}">Turn ${e.turn} (session ${e.session}) ${esc(e.arm.toLowerCase())}: ${esc(e.reason)}${e.checkpoint ? ` <b class="${e.checkpoint.decision === "DISCARDED" ? "err" : "ok"}">A-113 ${esc(e.checkpoint.decision.toLowerCase())}</b>` : ""}</li>`).join("") || "<li>Start his Recess to see his turns here.</li>";
    },
  });

  // ---- Forge: describe a widget, ECHO composes it, the Governor validates it -------------------------
  W.register("FORGE", {
    title: "Forge", icon: "\u2692",
    build(body) {
      body.innerHTML = `<div class="pad"><p class="small muted">Describe a widget. ECHO composes it from registered parts; nothing generated is ever run as code.</p>
        <textarea rows="3" aria-label="Widget description" placeholder="a calculator that multiplies three numbers, a clock and notes, a kp index feed called Space Weather, explore dog, a query for glyphs, ask echo"></textarea>
        <div class="prow"><button class="btn primary" data-a="make">Forge it</button></div><div class="pout small"></div></div>`;
      body.querySelector("[data-a=make]").onclick = async () => {
        const d = body.querySelector("textarea").value.trim(); if (!d) { body.querySelector("textarea").focus(); return; }
        const o = body.querySelector(".pout"); o.textContent = "\u2026";
        try { const spec = await E.bridge.call("forge", d); const errs = E.forge.validate(spec);
          if (errs.length) { o.textContent = "Refused: " + errs.join("; "); return; }
          E.app.openForged(spec);
          o.textContent = `Built "${spec.title}" from ${spec.controls.length} parts.` + (spec.unrecognized.length ? ` Words I did not use: ${spec.unrecognized.join(", ")}.` : "");
        } catch (e) { o.textContent = e.message; }
      };
    },
  });

  // ---- Crawler + Cloudflare adapter -------------------------------------------------------------
  const C = E.crawler = { sources: {}, results: {}, worker: "https://echo-green-future.agi144348.workers.dev" };
  fetch("./data/geosensory_registry.json").then(r => r.json()).then(j => C.sources = j).catch(() => {});
  async function get(url, ms = 9000) {
    const ac = new AbortController(), t = setTimeout(() => ac.abort(), ms);
    try { const r = await fetch(url, { signal: ac.signal }); const text = await r.text(); return { ok: r.ok, status: r.status, text }; }
    catch (e) { return { ok: false, status: 0, error: e.name === "AbortError" ? "timed out" : "blocked by the browser (CORS) or offline" }; }
    finally { clearTimeout(t); }
  }
  function summarize(src, text) {
    let j; try { j = JSON.parse(text); } catch { return { json: false, text: "not JSON" }; }
    if (j.features) return { json: true, text: `${j.features.length} events` + (j.features[0] ? `, latest: ${j.features[0].properties.title || ""}` : "") };
    if (Array.isArray(j)) { const last = j[j.length - 1]; const f = (src.fields || []).filter(k => last && typeof last === "object" && k in last);
      return { json: true, text: `${j.length} rows; latest ` + (last && typeof last === "object" ? f.map(k => `${k}=${last[k]}`).join(", ") || JSON.stringify(last).slice(0, 120) : String(last).slice(0, 120)) }; }
    return { json: true, text: JSON.stringify(j).slice(0, 160) };
  }
  C.probe = async id => {
    const s = C.sources[id]; if (!s) return { id, verdict: "unknown source" };
    if (s.key_required) return { id, name: s.name, verdict: "needs an API key (skipped)" };
    const r = await get(s.url);
    const v = r.ok ? summarize(s, r.text) : null;
    return C.results[id] = { id, name: s.name, verdict: r.ok ? (v.json ? "live" : "reachable, not JSON") : (r.error || `HTTP ${r.status}`), detail: v ? v.text : "" };
  };
  C.sample = async id => { const r = await C.probe(id); return `${r.name || id}: ${r.verdict}${r.detail ? ". " + r.detail : ""}`; };
  W.register("CRAWLER", {
    title: "Crawler and Cloudflare", icon: "\u2601",
    build(body) {
      const ids = Object.keys(C.sources);
      body.innerHTML = `<div class="pad"><div class="lbl">Geosensory sources (${ids.length})</div><button class="btn" data-a="probe">Probe all live sources</button>
        <table class="t src">${ids.map(id => `<tr data-id="${id}"><td class="small">${esc(C.sources[id].name)}</td><td class="small v">${esc((C.results[id] || {}).verdict || "")}</td></tr>`).join("")}</table>
        <div class="lbl">ECHO's Cloudflare Worker</div><input type="url" class="wurl" value="${esc(C.worker)}" aria-label="Worker address">
        <div class="prow"><input type="text" class="wq" placeholder="word or search term" aria-label="Word"><button class="btn" data-a="health">Health</button><button class="btn" data-a="agent">Agent</button><button class="btn" data-a="ties">Ties</button><button class="btn" data-a="search">Search</button></div>
        <pre class="wout small"></pre><p class="small muted">Some sources refuse requests from a browser page (CORS). Those will show as blocked; they can be routed through the Worker later.</p></div>`;
      body.addEventListener("click", async ev => {
        const a = ev.target.dataset.a; if (!a) return;
        if (a === "probe") {
          ev.target.disabled = true;
          await Promise.all(ids.map(async id => { const tr = body.querySelector(`tr[data-id="${id}"] .v`); tr.textContent = "\u2026"; const r = await C.probe(id); tr.textContent = r.verdict + (r.detail ? ` \u2013 ${r.detail}` : ""); }));
          E.nve.set("crawl:last", C.results); ev.target.disabled = false; return;
        }
        C.worker = body.querySelector(".wurl").value.replace(/\/$/, ""); E.nve.set("worker-url", C.worker);
        const q = encodeURIComponent(body.querySelector(".wq").value.trim() || "echo");
        const path = a === "health" ? "/health" : a === "search" ? `/search?q=${q}` : `/${a}/${q}`;
        const o = body.querySelector(".wout"); o.textContent = "\u2026";
        const r = await get(C.worker + path);
        o.textContent = r.ok ? (() => { try { return JSON.stringify(JSON.parse(r.text), null, 1).slice(0, 3000); } catch { return r.text.slice(0, 3000); } })() : (r.error || `HTTP ${r.status}`);
      });
    },
  });

  // ---- Data: export, import, clear ------------------------------------------------------------
  W.register("DATA", {
    title: "Notebook data", icon: "\u21c5",
    build(body) {
      body.innerHTML = `<div class="pad"><p class="small muted">Everything ECHO has learned here is saved on this device. Export a copy to keep or move it.</p>
        <div class="prow"><button class="btn" data-a="export">Export notebook</button><button class="btn" data-a="import">Import</button></div>
        <div class="prow"><button class="btn" data-a="save-layout">Save layout</button><button class="btn" data-a="restore-layout">Restore layout</button></div>
        <div class="prow"><button class="btn danger" data-a="wipe">Clear this device's notebook</button></div></div>`;
      body.addEventListener("click", ev => { const a = ev.target.dataset.a; if (a) E.app.data(a); });
    },
  });
})(window.ECHO = window.ECHO || {});
