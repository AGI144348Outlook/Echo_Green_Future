/* Talk: the Notebook I/O dock. You write; ECHO answers through his audited pipeline in the worker. */
(function (E) {
  "use strict";
  const esc = t => E.stage.esc(t);
  const IO = E.io = { history: [], outEl: null, inputEl: null, emit };
  const coarse = matchMedia("(pointer: coarse)").matches;
  function html(e) {
    const who = e.actor === "user" ? "You" : e.actor === "echo" ? "\u05e8 ECHO" : "Notebook";
    let body;
    if (e.kind === "matrix" && Array.isArray(e.rows)) {
      const head = (e.columns || []).map(c => `<th>${esc(c)}</th>`).join("");
      body = `<div class="io-mtitle">${esc(e.text || "")}</div><div class="io-table"><table>${head ? `<thead><tr>${head}</tr></thead>` : ""}<tbody>${
        e.rows.map(r => "<tr>" + r.map(c => `<td>${esc(c)}</td>`).join("") + "</tr>").join("")}</tbody></table></div>`;
    } else body = `<div class="io-text${e.actor === "echo" && e.kind === "text" ? " voice" : ""}">${esc(e.text || "")}</div>`;
    const refs = [...new Set(e.refs || [])].filter(Boolean).slice(0, 10);
    const chips = refs.length ? `<div class="chips">${refs.map(r => `<button class="chip" data-word="${esc(r)}">${esc(r)}</button>`).join("")}</div>` : "";
    return `<div class="io-entry ${e.actor} k-${e.kind || "text"}"><div class="io-who">${who}</div>${body}${chips}</div>`;
  }
  function emit(e) {
    IO.history.push(e); if (IO.history.length > 300) IO.history.splice(0, IO.history.length - 300);
    if (IO.outEl && IO.outEl.isConnected) { IO.outEl.insertAdjacentHTML("beforeend", html(e)); IO.outEl.scrollTop = IO.outEl.scrollHeight; }
    E.app && E.app.persistIO();
  }
  E.widgets.register("IO_DOCK", {
    title: "Talk to ECHO", icon: "\u05e8",
    build(body) {
      body.classList.add("io");
      body.innerHTML = `<div class="io-out" aria-live="polite"></div><div class="io-in"><textarea rows="2" aria-label="Message to ECHO"
        placeholder="Talk to ECHO, or type help"></textarea><div class="io-actions"><button class="io-pick" type="button">+ Picked plane</button>
        <button class="io-send" type="button">Send</button></div></div>`;
      IO.outEl = body.querySelector(".io-out"); IO.inputEl = body.querySelector("textarea");
      IO.outEl.innerHTML = IO.history.map(html).join(""); IO.outEl.scrollTop = IO.outEl.scrollHeight;
      const ta = IO.inputEl, size = () => { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 120) + "px"; };
      const send = async () => {
        const text = ta.value.trim(); if (!text) { ta.focus(); return; }
        if (await E.app.send(text)) { ta.value = ""; size(); }
        ta.focus();
      };
      body.querySelector(".io-send").addEventListener("click", send);
      body.querySelector(".io-pick").addEventListener("click", () => {
        const id = E.stage.picked; if (!id) { E.app.toast("Tap a plane on the Canvas first"); ta.focus(); return; }
        const s = ta.selectionStart ?? ta.value.length, pre = ta.value.slice(0, s);
        ta.value = pre + (pre && !/\s$/.test(pre) ? " " : "") + id + ta.value.slice(ta.selectionEnd ?? s); ta.focus(); size();
      });
      ta.addEventListener("input", size);
      ta.addEventListener("keydown", ev => { if (ev.key === "Enter" && !ev.shiftKey && !coarse) { ev.preventDefault(); send(); } });
      IO.outEl.addEventListener("click", ev => { const c = ev.target.closest(".chip"); if (c) E.app.focusWord(c.dataset.word); });
    },
    onClose() { IO.outEl = null; IO.inputEl = null; },
  });
})(window.ECHO = window.ECHO || {});
