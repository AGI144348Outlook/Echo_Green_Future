/* The KSM Canvas: draws ECHO's knowledge planes from the operations his kernel emits.
   Nothing here decides anything. Your drags are a separate layer (offsets) that ECHO does not see. */
(function (E) {
  "use strict";
  const SEG = 12, TAU = Math.PI * 2, NS = "http://www.w3.org/2000/svg";
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const S = E.stage = { planes: {}, links: [], turn: 0, touched: [], freshLinks: [], offset: {}, picked: null,
    follow: true, overview: false, load, apply, render, center, onPick: null, esc };
  let svg, gP, gL, vb = { x: 0, y: 0, w: 1200, h: 900 }, vbT = null, raf = null;

  function load(c) {
    S.planes = c.planes || {}; S.links = c.links || []; S.turn = c.turn || 0; S.touched = []; S.freshLinks = [];
    gP && (gP.innerHTML = ""); render();
  }
  function apply(e) {
    S.touched = []; S.freshLinks = [];
    for (const o of e.ops) {
      const p = S.planes[o.id];
      if (o.op === "PRESENTIATE") S.planes[o.id] = { id: o.id, word: o.word, x: o.x, y: o.y, r: o.r, theta: o.theta, segments: o.segments,
        parent: null, folded: false, hidden: false, group: null };
      else if (o.op === "MOVE" && p) { p.x = o.x; p.y = o.y; }
      else if (o.op === "ROTATE" && p) p.theta = o.theta;
      else if (o.op === "SET_SIZE" && p) p.r = o.r;
      else if (o.op === "ALIGN") { const l = { a: o.a, b: o.b, sa: o.sa, sb: o.sb, kind: o.kind, turn: e.turn }; S.links.push(l); S.freshLinks.push(l); }
      else if (o.op === "SET_GROUP") o.members.forEach(m => S.planes[m] && (S.planes[m].group = o.group));
      else if (o.op === "CONTAIN" && p) p.parent = o.parent;
      else if (o.op === "MANIFOLD" && p) { p.folded = true; o.contents.forEach(c => S.planes[c] && (S.planes[c].hidden = true)); }
      else if (o.op === "UNFOLD" && p) { p.folded = false; Object.values(S.planes).forEach(c => { if (c.parent === o.id) c.hidden = false; }); }
      for (const k of [o.id, o.a, o.b]) if (k) S.touched.push(k);
    }
    if (S.links.length > 400) S.links.splice(0, S.links.length - 400);
    S.turn = e.turn; render();
  }
  const pos = p => { const o = S.offset[p.id] || { x: 0, y: 0 }; return { x: p.x + o.x, y: p.y + o.y }; };
  const segPt = (p, i) => { const a = p.theta + i * TAU / SEG, q = pos(p); return { x: q.x + Math.cos(a) * p.r, y: q.y + Math.sin(a) * p.r }; };

  function el(p) {
    let g = gP.querySelector(`[data-id="${CSS.escape(p.id)}"]`);
    if (g) return g;
    g = document.createElementNS(NS, "g"); g.setAttribute("class", "plane"); g.dataset.id = p.id;
    g.setAttribute("tabindex", "0"); g.setAttribute("role", "button"); g.setAttribute("aria-label", "Plane " + p.word);
    g.innerHTML = `<circle class="halo"/><circle class="disc"/><g class="dial"></g><text class="name" dy="4"></text><text class="badge"></text>`;
    gP.appendChild(g); bindPlane(g); return g;
  }

  function render() {
    if (!svg) return;
    const hot = new Set(S.touched), hotSeg = {};
    S.freshLinks.forEach(l => { hotSeg[l.a] = l.sa; hotSeg[l.b] = l.sb; });
    const vis = Object.values(S.planes).filter(p => !p.hidden).sort((a, b) => b.r - a.r), alive = new Set();
    for (const p of vis) {
      alive.add(p.id);
      const g = el(p), q = pos(p);
      g.style.transform = `translate(${q.x}px,${q.y}px)`;
      g.classList.toggle("set", !!p.group); g.classList.toggle("folded", !!p.folded); g.classList.toggle("inside", !!p.parent);
      g.classList.toggle("now", hot.has(p.id)); g.classList.toggle("picked", S.picked === p.id);
      g.querySelector(".disc").setAttribute("r", p.r); g.querySelector(".halo").setAttribute("r", p.r + 6);
      const nm = g.querySelector(".name"); nm.textContent = p.word; nm.setAttribute("y", p.r > 44 ? -p.r + 18 : 0);
      const kids = Object.values(S.planes).filter(k => k.parent === p.id).length;
      const bd = g.querySelector(".badge"); bd.textContent = p.folded ? `+${kids} folded` : ""; bd.setAttribute("y", 16);
      const dial = g.querySelector(".dial"); dial.style.transform = `rotate(${p.theta}rad)`;
      let inner = "";
      (p.segments || []).forEach((w, i) => {
        const a = i * TAU / SEG, c = Math.cos(a), sn = Math.sin(a), isHot = hotSeg[p.id] === w;
        inner += `<line class="tick${isHot ? " hot" : ""}" x1="${c * (p.r - 6)}" y1="${sn * (p.r - 6)}" x2="${c * p.r}" y2="${sn * p.r}"/>`;
        if (S.picked === p.id || isHot) {
          const wa = ((a + p.theta) % TAU + TAU) % TAU, flip = wa > Math.PI / 2 && wa < 3 * Math.PI / 2;
          const lx = c * (p.r + 8), ly = sn * (p.r + 8), deg = a * 180 / Math.PI + (flip ? 180 : 0);
          inner += `<text class="seglabel${isHot ? " hot" : ""}" x="${lx}" y="${ly}" text-anchor="${flip ? "end" : "start"}" dominant-baseline="middle" transform="rotate(${deg} ${lx} ${ly})">${esc(w)}</text>`;
        }
      });
      if (dial.dataset.key !== inner) { dial.innerHTML = inner; dial.dataset.key = inner; }
    }
    gP.querySelectorAll(".plane").forEach(g => { if (!alive.has(g.dataset.id)) g.remove(); });
    let links = "";
    for (const l of S.links) {
      const A = S.planes[l.a], B = S.planes[l.b];
      if (!A || !B || A.hidden || B.hidden) continue;
      const pa = segPt(A, Math.max(0, (A.segments || []).indexOf(l.sa))), pb = segPt(B, Math.max(0, (B.segments || []).indexOf(l.sb)));
      const fresh = S.freshLinks.includes(l), op = fresh ? 1 : Math.max(0.12, 0.5 - (S.turn - l.turn) * 0.04);
      links += `<path class="link${fresh ? " fresh" : ""}" style="opacity:${op}" d="M${pa.x},${pa.y} L${pb.x},${pb.y}"/>`;
    }
    gL.innerHTML = links;
    const empty = document.getElementById("empty-hint"); if (empty) empty.hidden = vis.length > 0;
    if (S.follow) {
      const focus = new Set(hot); S.freshLinks.forEach(l => { focus.add(l.a); focus.add(l.b); });
      [...focus].forEach(id => { const p = S.planes[id]; if (p && p.parent) focus.add(p.parent); });
      const list = S.overview || !focus.size ? vis : vis.filter(p => focus.has(p.id));
      fit(list.length ? list : vis, S.overview ? 360 : 460);
    }
  }
  function fit(list, minW) {
    if (!list.length) return;
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    list.forEach(p => { const q = pos(p); x0 = Math.min(x0, q.x - p.r - 40); y0 = Math.min(y0, q.y - p.r - 30); x1 = Math.max(x1, q.x + p.r + 40); y1 = Math.max(y1, q.y + p.r + 30); });
    const r = svg.getBoundingClientRect(), asp = r.width / Math.max(r.height, 1);
    let w = Math.max(x1 - x0, minW), h = Math.max(y1 - y0, 260);
    if (w / h < asp) w = h * asp; else h = w / asp;
    vbT = { x: (x0 + x1) / 2 - w / 2, y: (y0 + y1) / 2 - h / 2, w, h }; tween();
  }
  function tween() {
    if (raf) return;
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const step = () => {
      raf = null; if (!vbT) return;
      let done = true;
      for (const k of ["x", "y", "w", "h"]) { const d = vbT[k] - vb[k]; if (Math.abs(d) > 0.5) { vb[k] += d * (reduce ? 1 : 0.14); done = false; } else vb[k] = vbT[k]; }
      svg.setAttribute("viewBox", `${vb.x} ${vb.y} ${vb.w} ${vb.h}`);
      if (!done) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
  }
  function center(id) {
    const p = S.planes[id]; if (!p) return false;
    S.follow = false; document.getElementById("follow").hidden = false;
    const q = pos(p); vbT = { x: q.x - vb.w / 2, y: q.y - vb.h / 2, w: vb.w, h: vb.h }; tween(); return true;
  }
  function svgPt(ev) { const r = svg.getBoundingClientRect(); return { x: vb.x + (ev.clientX - r.left) / r.width * vb.w, y: vb.y + (ev.clientY - r.top) / r.height * vb.h }; }
  function bindPlane(g) {
    let d = null;
    g.addEventListener("pointerdown", ev => { ev.stopPropagation(); d = { id: g.dataset.id, p0: svgPt(ev), o: { ...(S.offset[g.dataset.id] || { x: 0, y: 0 }) }, moved: false }; g.setPointerCapture(ev.pointerId); });
    g.addEventListener("pointermove", ev => {
      if (!d) return; const p = svgPt(ev), dx = p.x - d.p0.x, dy = p.y - d.p0.y;
      if (!d.moved && Math.hypot(dx, dy) < vb.w / 120) return;
      d.moved = true; g.style.transition = "none"; S.offset[d.id] = { x: d.o.x + dx, y: d.o.y + dy }; S.follow = false; render();
    });
    const end = () => { if (!d) return; g.style.transition = ""; const id = d.id, moved = d.moved; d = null;
      if (moved) E.app && E.app.movedPlane(id); else pick(id); };
    g.addEventListener("pointerup", end); g.addEventListener("pointercancel", () => { d = null; g.style.transition = ""; });
    g.addEventListener("keydown", ev => { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); pick(g.dataset.id); } });
  }
  function pick(id) { S.picked = id; render(); S.onPick && S.onPick(id); }
  function manual(v) { S.follow = false; vbT = null; vb = v; svg.setAttribute("viewBox", `${vb.x} ${vb.y} ${vb.w} ${vb.h}`); document.getElementById("follow").hidden = false; }

  function init() {
    svg = document.getElementById("chart"); gP = document.getElementById("planes"); gL = document.getElementById("links");
    const ptrs = new Map(); let pan = null, pinch = null;
    svg.addEventListener("pointerdown", ev => {
      ptrs.set(ev.pointerId, ev); svg.setPointerCapture(ev.pointerId);
      if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; pinch = { d: Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY), vb: { ...vb } }; pan = null; }
      else pan = { x: ev.clientX, y: ev.clientY, vb: { ...vb } };
    });
    svg.addEventListener("pointermove", ev => {
      if (!ptrs.has(ev.pointerId)) return; ptrs.set(ev.pointerId, ev);
      const r = svg.getBoundingClientRect();
      if (pinch && ptrs.size >= 2) { const [a, b] = [...ptrs.values()]; const k = pinch.d / Math.max(20, Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY));
        manual({ x: pinch.vb.x + pinch.vb.w * (1 - k) / 2, y: pinch.vb.y + pinch.vb.h * (1 - k) / 2, w: pinch.vb.w * k, h: pinch.vb.h * k }); return; }
      if (pan && Math.abs(ev.clientX - pan.x) + Math.abs(ev.clientY - pan.y) > 4)
        manual({ ...pan.vb, x: pan.vb.x - (ev.clientX - pan.x) / r.width * pan.vb.w, y: pan.vb.y - (ev.clientY - pan.y) / r.height * pan.vb.h });
    });
    const end = ev => { ptrs.delete(ev.pointerId); if (ptrs.size < 2) pinch = null; if (!ptrs.size) pan = null; };
    svg.addEventListener("pointerup", end); svg.addEventListener("pointercancel", end);
    svg.addEventListener("wheel", ev => { ev.preventDefault(); const k = ev.deltaY > 0 ? 1.12 : 1 / 1.12, p = svgPt(ev);
      manual({ x: p.x - (p.x - vb.x) * k, y: p.y - (p.y - vb.y) * k, w: vb.w * k, h: vb.h * k }); }, { passive: false });
    document.getElementById("follow").onclick = () => { S.follow = true; document.getElementById("follow").hidden = true; render(); };
    document.getElementById("overview").onclick = ev => { S.overview = !S.overview; S.follow = true; document.getElementById("follow").hidden = true;
      ev.currentTarget.textContent = S.overview ? "Follow his moves" : "Show all"; render(); };
    window.addEventListener("resize", () => S.follow && render());
  }
  S.init = init;
})(window.ECHO = window.ECHO || {});
