/* ECHO Notebook host: boots ECHO's worker, runs his Canvas Recess continuously, and saves what he learns. */
(function (E) {
  "use strict";
  const $ = s => document.querySelector(s), W = E.widgets, B = E.bridge, S = E.stage, IO = E.io;
  const TB = 52;
  const A = E.app = { send, focusWord, toast, persistIO, movedPlane, saveOffsets, openForged, data, inspect, saveSoon,
    recess: { on: false, speed: 1, timer: null, sinceSave: 0 } };

  // ---- persistence ---------------------------------------------------------------------------
  let ioT, layT;
  function persistIO() { clearTimeout(ioT); ioT = setTimeout(() => E.nve.set("io", IO.history.slice(-200)), 500); }
  function saveOffsets() { E.nve.set("offsets", S.offset); }
  let svT; function saveSoon() { clearTimeout(svT); svT = setTimeout(saveRuntime, 1500); }
  async function saveRuntime() { if (!B.ready) return; try { E.nve.set("runtime", await B.call("save")); E.nve.set("recesslog", E.recessLog.slice(-400)); } catch (e) { console.warn(e); } }
  W.onChange = () => { clearTimeout(layT); layT = setTimeout(() => E.nve.set("layout:auto", W.serialize()), 300); };

  // ---- ECHO's continuous Recess ------------------------------------------------------------------
  function setRecess(on) {
    A.recess.on = on; $("#recess").textContent = on ? "Pause Recess" : "Start Recess";
    $("#recess").setAttribute("aria-pressed", String(on)); E.nve.set("recess-on", on);
    clearTimeout(A.recess.timer); if (on) tick();
  }
  async function tick() {
    if (!A.recess.on) return;
    if (B.ready && document.visibilityState === "visible") {
      try {
        const entries = await B.call("recess", 1);
        for (const e of entries) {
          S.apply(e);
          E.recessLog.push({ turn: e.turn, session: e.session, arm: e.arm, ok: e.ok, reason: e.reason, checkpoint: e.checkpoint });
          e.say.forEach(s => IO.emit({ actor: "echo", kind: "text", text: s.english, refs: [] }));
          if (e.checkpoint) IO.emit({ actor: "system", kind: "status", text: `End of session ${e.checkpoint.session}: A-113 ${e.checkpoint.decision.toLowerCase()}. ${e.checkpoint.reason}` });
        }
        $("#turn").textContent = `Turn ${S.turn}`;
        if (W.items.has("recesslog")) W.refresh("recesslog");
        if (++A.recess.sinceSave >= 10 || entries.some(e => e.checkpoint)) { A.recess.sinceSave = 0; saveRuntime(); }
      } catch (e) { toast("Recess paused: " + e.message); setRecess(false); return; }
    }
    A.recess.timer = setTimeout(tick, 2200 / A.recess.speed);
  }

  // ---- talking ------------------------------------------------------------------------------------
  async function send(text) {
    if (!B.ready) { toast("ECHO is " + (B.status === "error" ? "offline" : "still waking up")); return false; }
    IO.emit({ actor: "user", kind: "text", text });
    try {
      const r = await B.call("handle", text, "TEXT");
      r.outputs.forEach(o => IO.emit(o));
      if (r.ops && r.ops.length) { S.apply({ turn: S.turn, ops: r.ops }); saveRuntime(); }
      if (r.widget) { const errs = E.forge.validate(r.widget); errs.length ? IO.emit({ actor: "system", kind: "error", text: "Refused: " + errs.join("; ") }) : openForged(r.widget); }
      if (/^(teach|suggest|add|place)\b/i.test(text)) saveRuntime();
    } catch (e) { IO.emit({ actor: "system", kind: "error", text: e.message }); }
    return true;
  }
  async function suggest(word) {
    if (!B.ready) { toast("ECHO is still waking up"); return; }
    IO.emit({ actor: "user", kind: "text", text: "suggest " + word });
    const r = await B.call("suggest", word);
    IO.emit({ actor: "echo", kind: r.accepted ? "status" : "text", text: r.reason, refs: r.accepted ? [word] : [] });
    if (r.ops.length) { S.apply({ turn: S.turn, ops: r.ops }); saveRuntime(); }
  }
  function focusWord(w) {
    w = String(w || "").toLowerCase();
    if (S.planes[w]) { S.picked = w; S.center(w); S.render(); inspect(w); }
    else send("resolve " + w);
  }
  function inspect(id) {
    const small = innerWidth < 700;
    W.dispatch({ op: "OPEN_WIDGET", spec: { id: "inspector", type: "INSPECTOR", binding: { id }, x: small ? 8 : innerWidth - 700, y: TB + 8, w: Math.min(330, innerWidth - 16), h: 420 } });
    W.refresh("inspector");
  }
  function movedPlane() { saveOffsets(); }
  function openForged(spec) {
    const id = "forged:" + Date.now().toString(36);
    W.dispatch({ op: "OPEN_WIDGET", spec: { id, type: "FORGED", binding: { spec }, x: 20, y: TB + 20, w: Math.min(340, innerWidth - 16), h: 360 } });
  }

  // ---- data ------------------------------------------------------------------------------------------
  async function data(a) {
    if (a === "save-layout") { await E.nve.set("layout:saved", W.serialize()); toast("Layout saved"); }
    if (a === "restore-layout") { const l = await E.nve.get("layout:saved"); if (l) { W.restore(l); toast("Layout restored"); } else toast("No saved layout yet"); }
    if (a === "export") {
      const payload = { format: "echo-notebook/0.3", exported: new Date().toISOString(), runtime: B.ready ? await B.call("save") : await E.nve.get("runtime"),
        offsets: S.offset, io: IO.history.slice(-200), layout: W.serialize(), recesslog: E.recessLog.slice(-400) };
      const a2 = document.createElement("a"); a2.href = URL.createObjectURL(new Blob([JSON.stringify(payload)], { type: "application/json" }));
      a2.download = `echo-notebook-${new Date().toISOString().slice(0, 10)}.json`; document.body.appendChild(a2); a2.click(); a2.remove(); toast("Notebook exported");
    }
    if (a === "import") {
      const inp = document.createElement("input"); inp.type = "file"; inp.accept = ".json,application/json";
      inp.onchange = async () => { try { const d = JSON.parse(await inp.files[0].text()); if (!d.runtime) throw new Error("not an ECHO notebook");
        await E.nve.set("runtime", d.runtime); await E.nve.set("offsets", d.offsets || {}); await E.nve.set("io", d.io || []); await E.nve.set("recesslog", d.recesslog || []);
        if (d.layout) await E.nve.set("layout:auto", d.layout); location.reload(); } catch (e) { toast("Import failed: " + e.message); } };
      inp.click();
    }
    if (a === "wipe" && confirm("Clear this device's notebook, including everything ECHO learned here? Export first if you want a copy.")) { await E.nve.clear(); location.reload(); }
  }

  let tt; function toast(m) { const t = $("#toast"); t.textContent = m; t.hidden = false; clearTimeout(tt); tt = setTimeout(() => t.hidden = true, 2600); }

  // ---- chrome ------------------------------------------------------------------------------------------
  function open(type) {
    const small = innerWidth < 700, x = small ? 8 : 16, w = Math.min(360, innerWidth - 16), h = Math.min(480, innerHeight - TB - 30);
    const specs = { IO_DOCK: { id: "io", docked: small, x: innerWidth - 400, y: TB + 12, w: 388, h: innerHeight - TB - 24 },
      GOVERNOR: { id: "governor" }, MATRICES: { id: "matrices" }, MAPS: { id: "maps" }, RECESS_LOG: { id: "recesslog" }, FORGE: { id: "forge" }, CRAWLER: { id: "crawler" }, DATA: { id: "data" } };
    const s = specs[type]; if (!s) return;
    W.dispatch({ op: "OPEN_WIDGET", spec: { type, x, y: TB + 12, w, h, ...s } });
    if (type !== "IO_DOCK") W.refresh(s.id);
  }
  function bind() {
    $("#recess").onclick = () => setRecess(!A.recess.on);
    $("#study").onclick = () => E.study.set(!E.study.on);
    $("#speed").onchange = ev => { A.recess.speed = +ev.target.value; };
    const dlg = $("#suggest-dialog"), inp = $("#suggest-input");
    const openD = () => { dlg.hidden = false; $("#backdrop").hidden = false; inp.value = ""; inp.focus(); };
    const closeD = () => { dlg.hidden = true; $("#backdrop").hidden = true; inp.blur(); };
    $("#suggest").onclick = openD; $("#suggest-cancel").onclick = closeD; $("#backdrop").onclick = () => { closeD(); closeMenu(); };
    $("#suggest-form").onsubmit = ev => { ev.preventDefault(); const w = inp.value.trim(); if (!w) { inp.focus(); return; } closeD(); suggest(w); };
    const menu = $("#menu");
    const closeMenu = () => { menu.hidden = true; $("#btn-menu").setAttribute("aria-expanded", "false"); };
    $("#btn-menu").onclick = () => { menu.hidden = !menu.hidden; $("#btn-menu").setAttribute("aria-expanded", String(!menu.hidden)); };
    document.addEventListener("pointerdown", ev => { if (!menu.hidden && !menu.contains(ev.target) && !ev.target.closest("#btn-menu")) closeMenu(); });
    menu.onclick = ev => { const b = ev.target.closest("button[data-cmd]"); if (!b) return; closeMenu(); const c = b.dataset.cmd;
      if (c === "save-layout" || c === "restore-layout") data(c); else open(c); };
    $("#rt-pill").onclick = () => open("GOVERNOR");
    document.addEventListener("keydown", ev => { if (ev.key === "Escape") { if (!dlg.hidden) closeD(); else closeMenu(); } });
    document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") saveRuntime(); });
    B.events.addEventListener("status", () => {
      const p = $("#rt-pill"); p.dataset.state = B.status;
      $("#rt-text").textContent = B.status === "ready" ? "ECHO online" : B.status === "error" ? "ECHO offline" : "Waking";
      p.title = B.detail; $("#boot-note").textContent = B.status === "ready" ? "" : B.detail;
      if (W.items.has("governor")) W.refresh("governor");
    });
    S.onPick = id => inspect(id);
  }

  async function init() {
    S.init(); bind();
    const [layout, io, offsets, runtime, rlog, recOn, wurl, studyOn] = await Promise.all(
      ["layout:auto", "io", "offsets", "runtime", "recesslog", "recess-on", "worker-url", "study-on"].map(k => E.nve.get(k)));
    if (Array.isArray(io)) IO.history = io;
    S.offset = offsets || {}; E.recessLog = rlog || [];
    if (wurl) E.crawler.worker = wurl;
    if (Array.isArray(layout) && layout.length) W.restore(layout); else open("IO_DOCK");
    if (!IO.history.length) IO.emit({ actor: "system", kind: "status", text: "ECHO is waking up. When he is online, start his Recess to watch him place planes on his own, talk to him below, or suggest a word he can accept or decline." });
    try {
      const r = await B.start(runtime || {});
      S.load(r.canvas); $("#turn").textContent = `Turn ${S.turn}`;
      const dl = $("#words"); dl.innerHTML = (r.words || []).map(w => `<option value="${S.esc(w)}">`).join("");
      IO.emit({ actor: "echo", kind: "status", text: `\u05e8 ECHO online: kernel ${r.identity["kernel lines"]} lines, Lobby ${r.identity["lobby words"]} words and ${r.identity["lobby ties"]} ties, ${r.identity["canvas planes"]} planes on his Canvas${runtime ? " (restored from this device)" : ""}. Type help.` });
      ["governor", "matrices", "inspector"].forEach(id => W.items.has(id) && W.refresh(id));
      if (recOn) setRecess(true);
      E.study.start(studyOn);
    } catch (e) {
      IO.emit({ actor: "system", kind: "error", text: `ECHO could not start: ${e.message}. He needs a connection the first time, and the page must be served over http(s).` });
    }
    if ("serviceWorker" in navigator && (location.protocol === "https:" || ["localhost", "127.0.0.1"].includes(location.hostname)))
      navigator.serviceWorker.register("./sw.js").catch(() => {});
  }
  document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", init) : init();
})(window.ECHO = window.ECHO || {});
