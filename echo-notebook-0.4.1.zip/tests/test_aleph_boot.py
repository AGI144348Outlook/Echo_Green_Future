import copy, pytest
from echo.aleph_boot import (World, boot, boot_by_relocation, BootError, ALL27, FINALS, STANDARD, h,
    WALK, lift, seat, forward, backward, Walker)

def upto(n):
    w = World(); steps = [lambda w: w.instantiate("001", "DNS"), lambda w: w.seed("001", "PRESENTIATE"),
        lambda w: w.instantiate("001", "א"), lambda w: w.presentiate("001", "DSL", "א"),
        lambda w: w.instantiate("001", "ר"), lambda w: w.presentiate("001", "001", "ר")]
    for s in steps[:n]: s(w)
    return w

def test_27_glyphs_with_correct_finals():
    assert len(ALL27) == 27 and len(set(ALL27)) == 27 and len(STANDARD) == 22
    assert FINALS == ["ך", "ם", "ן", "ף", "ץ"] and "ל" not in FINALS

def test_full_boot_passes_alg_002():
    ok, checks = boot().alg_002()
    assert ok, checks

def test_relocation_scheme_leaves_24():
    w = upto(6); w.instantiate("ר-alg-001", "ם")
    assert 27 - len(w.matrices) == 24

def test_relocation_scheme_still_boots():
    assert boot_by_relocation().alg_002()[0]

# ---- the % walk ----------------------------------------------------------------------------
STATES = [(k, L) for L in WALK for k in ("at", "lifted")]

def test_walk_order_and_count():
    assert WALK[0] == "א" and WALK[-2:] == ["ת", "ם"] and "ר" not in WALK
    assert WALK[-6:-2] == ["ך", "ן", "ף", "ץ"] and len(WALK) - 1 == 25 and len(set(WALK)) == 26

def test_lift_and_seat_are_each_involutions():
    assert all(lift(lift(s)) == s for s in STATES)
    assert all(seat(seat(s)) == s for s in STATES)

def test_one_mirror_alone_does_not_advance():
    s = ("at", "א")
    assert lift(lift(s)) == s                      # applying the same % twice returns to א

def test_two_mirrors_advance_and_reverse_order_goes_back():
    for L in WALK[1:-1]:
        s = ("at", L)
        assert forward(s)[1] == WALK[WALK.index(L) + 1]
        assert backward(forward(s)) == s and forward(backward(s)) == s

def test_full_walk_boots_and_passes_alg_002():
    w = boot(); ok, checks = w.alg_002()
    assert ok, checks
    assert w.walker.path == WALK and w.records["DSL"]["origin"] == "א" and w.records["DSL"]["location"] == "ם"

def test_walk_log_uses_the_notation():
    w = boot()
    first = next(e for e in w.log if e["step"][0] == "walk")
    assert first["notation"] == ["(ר001)%(DSLא)=א/(DSL)", "(ר001)%{א/(DSL)}=(DSLב)"]

def test_walk_needs_executive_authority():
    w = upto(5); w_ = Walker.__new__(Walker); w_.w = w; w_.state = ("at", "א"); w_.path = ["א"]
    with pytest.raises(BootError, match="no executive authority"): w_.step()

def test_backward_step_never_creates_folders():
    w = upto(6); wk = Walker(w); wk.step(); wk.step(); n = len(w.matrices)
    wk.step("backward"); assert len(w.matrices) == n and w.records["DSL"]["location"] == WALK[1]

def test_cannot_walk_past_either_end():
    w = upto(6); wk = Walker(w)
    with pytest.raises(BootError, match="end"): wk.step("backward")
    wk.run()
    with pytest.raises(BootError, match="end"): wk.step("forward")

def test_permit_enforces_order():
    w = World()
    with pytest.raises(BootError, match="permit 003 allows"): w.instantiate("001", "א")

def test_001_cannot_act_beyond_permit():
    w = upto(6)
    with pytest.raises(BootError, match="used up"): w.instantiate("001", "ם")

def test_no_executive_before_presentiation_into_resh():
    w = upto(5)
    with pytest.raises(BootError, match="no executive authority"): w.instantiate("ר-alg-001", "ם")

def test_presentiation_keeps_identity_and_authority_comes_from_locus():
    w = upto(6)
    assert w.presences[("001", "ר")]["identity"] == w.records["001"]["content_hash"]
    assert w.presences[("001", "ר")]["authority"] == "executive"
    assert w.presences[("DSL", "א")]["authority"] == "local"

def test_dsl_has_its_own_lineage_separate_from_requester():
    w = upto(4)
    d = w.records["DSL"]
    assert d["requested_by"] == "001" and d["lineage"] != w.records["001"]["lineage"] and d["content_hash"] == h(d["content"])

def test_relocation_into_missing_matrix_rolls_back():
    w = upto(6); before = copy.deepcopy((w.matrices, w.records, w.presences))
    with pytest.raises(BootError, match="does not exist"): w.relocate("ר-alg-001", "DSL", "ם")
    assert (w.matrices, w.records, w.presences) == before

def test_failure_mid_relocation_rolls_back():
    w = upto(6); w.instantiate("ר-alg-001", "ם"); before = copy.deepcopy((w.matrices, w.records, w.presences))
    with pytest.raises(BootError, match="simulated"): w.relocate("ר-alg-001", "DSL", "ם", fail_after_remove=True)
    assert (w.matrices, w.records, w.presences) == before and "DSL" in w.matrices["א"]["records"]

def test_origin_invariant_location_changes():
    w = boot_by_relocation(); d = w.records["DSL"]
    assert d["origin"] == "א" and d["location"] == "ם"

def test_tampering_is_detected():
    w = boot(); w.records["DSL"]["content"]["operators"]["%"]["meaning"] = "changed"
    ok, checks = w.alg_002()
    assert not ok and not checks["DSL contents match their hash"]
    w2 = boot(); w2.log[3]["actor"] = "someone else"
    assert not w2.alg_002()[1]["log hash chain intact"]

def test_dns_holds_only_presentiation_at_boot():
    w = upto(2)
    assert list(w.dns["primitives"]) == ["PRESENTIATE"]
