import math, random, pytest
from fractions import Fraction as Fr
from echo.language.projective import (INF, Permille, neg, inv, div, mul, add, sub, theta, from_theta, reflect,
    rotation_between, cross, close, SPACES, Line, parallel, distance, great_circle, meet, arcs, circumference, evaluate, show)
from echo.language.gov_index import Matrix, Governor
from echo.language.index_pattern import parse
from echo.operators.orbit import is_involution

PTS = [Fr(0), Fr(1), Fr(-1), Fr(2), Fr(1, 3), Fr(-5, 7), INF]

def test_neg_and_inv_are_involutions():
    assert is_involution(neg, PTS) and is_involution(inv, PTS)

def test_fixed_points_and_the_zero_infinity_swap():
    assert [p for p in PTS if neg(p) == p] == [Fr(0), INF]
    assert [p for p in PTS if inv(p) == p] == [Fr(1), Fr(-1)]
    assert inv(0) == INF and inv(INF) == 0

def test_numbers_sit_on_a_circle():
    assert theta(0) == 0 and theta(INF) == math.pi and abs(theta(1) - math.pi / 2) < 1e-12
    for p in PTS[:-1]:
        assert abs(theta(neg(p)) - (-theta(p))) < 1e-12                                     # %neg: theta -> -theta
        assert abs(math.remainder(theta(inv(p)) - (math.pi - theta(p)), 2 * math.pi)) < 1e-9   # %inv: theta -> pi - theta

def test_two_mirrors_make_a_half_turn():
    f = lambda x: inv(neg(x))                       # x -> -1/x
    assert f(0) == INF and f(INF) == 0 and f(1) == -1 and f(-1) == 1
    assert all(f(p) != p for p in PTS)              # no fixed point on the line: a pure turn
    assert abs(abs(rotation_between(neg, inv)) - math.pi) < 1e-9

def test_order_of_two_mirrors_sets_direction():
    a, b = 0.4, 1.1
    fwd = rotation_between(reflect(b), reflect(a)); back = rotation_between(reflect(a), reflect(b))
    assert abs(fwd - 2 * (a - b)) < 1e-9 and abs(back + fwd) < 1e-9

def test_indeterminate_forms_are_permille():
    assert isinstance(div(0, 0), Permille) and isinstance(div(INF, INF), Permille)
    assert isinstance(mul(0, INF), Permille) and isinstance(sub(INF, INF), Permille)
    assert div(1, 0) == INF and div(0, 5) == 0 and div(3, INF) == 0

def test_blow_up_resolves_by_direction():
    assert div(0, 0).along(2) == 2 and div(INF, INF).along(Fr(-1, 3)) == Fr(-1, 3)

def test_permille_narrows_meaning_candidates():
    slot = Permille("meaning", ["dog", "cat", "oak", "pine"])
    s1, b1 = slot.narrow(lambda w: w in ("dog", "cat"))
    s2, b2 = s1.narrow(lambda w: w == "dog")
    assert b1 == 1.0 and b2 == 1.0 and s2 == "dog"

def test_cross_ratio_survives_both_mirrors():
    random.seed(5)
    for _ in range(200):
        a, b, c, d = random.sample([Fr(n, m) for n in range(-9, 10) for m in (1, 2, 3)], 4)
        cr = cross(a, b, c, d)
        assert cross(neg(a), neg(b), neg(c), neg(d)) == cr
        if 0 not in (a, b, c, d): assert cross(inv(a), inv(b), inv(c), inv(d)) == cr

def test_infinity_over_infinity_is_not_one_but_closure_is_a_unit():
    assert not div(INF, INF) == 1
    assert repr(close(SPACES["plane"])) == "S2" and repr(close(SPACES["space"])) == "S3"
    assert SPACES["line"].card == SPACES["plane"].card == SPACES["space"].card
    assert [SPACES[k].dim for k in ("line", "plane", "space")] == [1, 2, 3]

def test_parallels_share_their_ideal_point_while_distance_varies():
    L = Line(0.7, 0.0)
    for t in range(12):
        d = 5 * abs(math.sin(t / 2))                 # oscillating distance
        M = parallel(L, d)
        assert M.ideal() == L.ideal() and abs(distance(L, M) - d) < 1e-12

def test_great_circles_always_bisect_each_other():
    random.seed(7)
    for _ in range(300):
        A = great_circle([random.uniform(-1, 1) for _ in range(3)]); B = great_circle([random.uniform(-1, 1) for _ in range(3)])
        p, q = meet(A, B)
        assert abs(sum(x * y for x, y in zip(p, q)) + 1) < 1e-9          # the two meeting points are opposite
        x, y = arcs(A, B); assert abs(x - math.pi) < 1e-9 and abs(y - math.pi) < 1e-9
    assert circumference() == 2 * math.pi

def test_governor_refuses_order_on_the_circle():
    P1 = Matrix("projective line", PTS, lambda w: None, order=None, rel=lambda a, b: div(b, a), algebra="diff")
    v = Governor(P1).validate(parse("|{(a<b):(c>d)::(e<d):(f>g)}|"))
    assert v["status"] == "FAIL" and "no order" in v["errors"][0]

@pytest.mark.parametrize("src,want", [("0/0", "‰(0/0)"), ("∞/∞", "‰(∞/∞)"), ("%inv(0)", "∞"), ("%inv(%inv(3))", "3"),
    ("%neg(%inv(2))", "-1/2"), ("along(0/0, 2)", "2"), ("0·∞", "‰(0·∞)"), ("◯(plane)", "S2"), ("cross(0, 1, ∞, 2)", "1/2")])
def test_dsl_evaluates(src, want):
    assert show(evaluate(src)) == want

@pytest.mark.parametrize("bad", ["__import__('os')", "inv.__class__", "open('x')", "[1,2]"])
def test_dsl_refuses_code(bad):
    with pytest.raises((ValueError, SyntaxError)): evaluate(bad)
